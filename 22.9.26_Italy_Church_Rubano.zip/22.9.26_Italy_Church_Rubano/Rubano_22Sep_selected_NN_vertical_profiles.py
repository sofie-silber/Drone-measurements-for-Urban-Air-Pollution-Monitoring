#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Rubano/Bosco 22 Sep 2026: selected Mandria NN + PM formula comparisons.

Only the user's own flight CSVs and Mandria calibration sources are read.
The model families are exactly those selected in the user's calibration summary:
  CO: NN ReLU without pressure
  NO2: NN Tanh without pressure
  O3: NN GELU and NN Tanh without pressure
  PM2.5/PM10: LR and MLR with relative humidity (device-specific).

Gas NN models are fitted from the user's original Mandria reference pairs, with
chronological day train/validation/test splits and 30-second training means.
No surrogate from unbenannt10.py is falsely relabeled as a selected NN.
Optional historic surrogate *formulas* are displayed only in separate, clearly
labeled diagnostic figures (see ADD_LEGACY_FORMULA_COMPARISON below).

Outputs per DOCUMENTED flight (Church Rubano & Roundabout Bosco):
  - O3 vertical profiles: X = O3 ppb, Y = pressure-derived relative height,
    BLUE GELU / PURPLE Tanh; solid ascent / dashed descent; BOTH stations.
  - T and RH vertical profiles immediately underneath O3.
  - CO, NO2 height profiles (same ascent/descent and station means).
  - stacked time series of CO, NO2, O3, PM2.5, PM10, T, p, RH and altitude,
    with ground_basic and ground_screen at the same time in every available panel.
  - tabular hourly/flight segment statistics and independent Mandria test RMSE.
  - OPC flights: PM2.5 & PM10 with both ground stations and OPC; GPS-relative
    height profiles only where actual GPS altitude is available.

CAUTION: The Mandria training dates are *after* this 22-Sep flight; applying
30-second-trained gas models to individual raw rows is exploratory. A second,
30-second-bin version of the O3 height profile is exported for comparison.
PM models were validated on DAILY MEANS, not on individual flight samples.
Historical test RMSE is reported as model metadata, NOT pointwise uncertainty.

RUN: Place this script wherever convenient and press F5 in Spyder.
Expected folder layout is set below; adapt if necessary.
Dependencies: numpy, pandas, matplotlib, scikit-learn, scipy, torch, xlrd,
              and the user's calibration_paris_english.py file.
"""
from __future__ import annotations

import importlib.util
import json
import math
import re
import sys
from pathlib import Path
from datetime import date

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from scipy.special import erf
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# ================ CONFIGURATION: THE USER'S OWN FOLDERS =======================
HOME = Path(r'C:\Users\xy-84\Desktop\Master\Thesis')
BACKGROUND = HOME / 'Background_Data_Paris'
FLIGHT_DIR = BACKGROUND / '22.9.26_Italy_Church_Rubano'
MANDRIA_RAW = BACKGROUND / 'Raw data calibration Mandria'
MANDRIA_REFERENCE = BACKGROUND / 'Calibrated comparison data Mandria'
CALIBRATION_SCRIPT = BACKGROUND / 'Calibration Lothstrasse' / 'calibration_paris_english.py'
# Other known location: BACKGROUND / 'calibration_paris_english.py'
LEGACY_SCRIPT = FLIGHT_DIR / 'unbenannt10.py'  # optional; your old formulas
ADD_LEGACY_FORMULA_COMPARISON = True

OUTPUT_DIR = FLIGHT_DIR / 'results_selected_PyTorch_profiles_22Sep'
EPOCHS = 100                  # Original Mandria PyTorch training setting
SEED = 42
HEIGHT_BIN_M = 5             # descriptive height bins; NOT input time resolution
USE_ORIGINAL_ROWS = True     # exploratory; a 30s-binned comparison also exported
LOCAL_TZ = 'Europe/Rome'
CAMPAIGN_DAY = date(2026, 9, 22)

GAS_SELECTION = {
    'CO': ['NN_relu_without_pressure'],
    'NO2': ['NN_tanh_without_pressure'],
    'O3': ['NN_gelu_without_pressure', 'NN_tanh_without_pressure'],
}
PM_SELECTION = ['LR', 'MLR_RH']
WINDOWS = [
    ('church_Rubano_gas_5m', 'Church Rubano', 'gas_drone', '12:09:44', '12:17:40'),
    ('roundabout_Bosco_gas_5m', 'Roundabout Bosco', 'gas_drone', '13:25:05', '13:32:05'),
    ('church_Rubano_opc_5m', 'Church Rubano', 'opc_drone', '11:37:20', '11:42:35'),
    ('roundabout_Bosco_opc_5m', 'Roundabout Bosco', 'opc_drone', '13:13:20', '13:20:43'),
]
INSTRUMENTS = ('gas_drone','ground_basic','ground_screen','opc_drone')
DEVICE_COLORS = {'gas_drone':'#15915b', 'opc_drone':'#7350a2',
                 'ground_basic':'#347dba', 'ground_screen':'#dd8a24'}
DIRECTION_COLORS = {'Ascent':'#2475b7', 'Descent':'#e1832f'}
MODEL_COLORS = {'NN_gelu_without_pressure':'#147ab8',
                'NN_tanh_without_pressure':'#884aaf'}
DIRECTION_STYLES = {'Ascent':'-', 'Descent':'--'}
UNITS = {'CO':'ppm', 'NO2':'ppb','O3':'ppb','PM2.5':'µg/m³',
         'PM10':'µg/m³','T':'°C','p':'hPa','RH':'%'}
RAW_FEATURES = ['CO_raw','NO2_raw','O3_raw','T','RH','p']
# ============================================================================


def announce(msg): print(msg, flush=True)


def load_module(path, name):
    if not path.is_file(): raise FileNotFoundError(f'Required Python file: {path}')
    spec = importlib.util.spec_from_file_location(name, str(path))
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def find_calibration_script():
    options = [CALIBRATION_SCRIPT, BACKGROUND / 'calibration_paris_english.py',
               FLIGHT_DIR / 'calibration_paris_english.py',
               Path(__file__).parent / 'calibration_paris_english.py']
    for p in options:
        if p.is_file(): return p
    raise FileNotFoundError('calibration_paris_english.py missing. Specify CALIBRATION_SCRIPT.')


def choose_source(folder, instrument):
    if not folder.is_dir():
        raise FileNotFoundError(f'Original Mandria folder missing: {folder}')
    entries = [p for p in folder.iterdir() if p.is_file()]
    matches = [p for p in entries if p.suffix.lower() == '.csv'
               and instrument in p.name.lower()]
    if instrument == 'thermo_reference':
        matches = [p for p in entries if p.suffix.lower() == '.csv'
                   and 'thermo_reference' in p.name.lower()]
    if instrument == 'pm_reference':
        matches = [p for p in entries if p.suffix.lower() in ('.xls','.xlsx')
                   and 'pm10' in p.name.lower() and ('pm2' in p.name.lower() or 'pm2.5' in p.name.lower())]
    if len(matches) != 1:
        raise FileNotFoundError(f'Expected exactly one {instrument} source in {folder}; found {[p.name for p in matches]}')
    return matches[0]


def mandria_sources(cal):
    mapping = {k: cal.Source(str(choose_source(MANDRIA_RAW,k))) for k in INSTRUMENTS}
    mapping['thermo_reference'] = cal.Source(str(choose_source(MANDRIA_REFERENCE,'thermo_reference')))
    mapping['pm_reference'] = cal.Source(str(choose_source(MANDRIA_REFERENCE,'pm_reference')))
    for name, source in mapping.items(): announce(f'[MANDRIA] {name}: {source.basename}')
    return mapping


def cache_signature(source_paths):
    return {k: {'size': p.stat().st_size, 'mtime_ns': p.stat().st_mtime_ns, 'path':str(p)}
            for k,p in source_paths.items()}


def nn_predict(model, array):
    """Run saved original PyTorch-trained weights with PyTorch on CPU.

    No alternative NumPy neural network and no re-training with another engine.
    """
    import torch
    from torch.nn import functional as F
    arr = np.asarray(array, dtype=np.float64)
    if arr.ndim != 2 or arr.shape[1] != len(model['features']):
        raise ValueError('Incorrect number of neural-network input features')
    arr = (arr - np.asarray(model['input_mean'])) / np.asarray(model['input_scale'])
    with torch.no_grad():
        x = torch.as_tensor(arr, dtype=torch.float32, device='cpu')
        W1 = torch.as_tensor(np.asarray(model['weight_hidden']), dtype=torch.float32)
        b1 = torch.as_tensor(np.asarray(model['bias_hidden']), dtype=torch.float32)
        W2 = torch.as_tensor(np.asarray(model['weight_out']), dtype=torch.float32)
        b2 = torch.as_tensor(np.asarray(model['bias_out']), dtype=torch.float32)
        hidden = F.linear(x, W1, b1)
        activation = model['activation']
        if activation == 'gelu': hidden = F.gelu(hidden)
        elif activation == 'tanh': hidden = torch.tanh(hidden)
        elif activation == 'relu': hidden = F.relu(hidden)
        else: raise ValueError('Unsupported PyTorch activation: '+str(activation))
        out = F.linear(hidden, W2, b2).flatten()
        return out.cpu().numpy().astype(float) * float(model['target_std']) + float(model['target_mean'])


def train_nn_exact(tr, va, model_name):
    """Original calibration_paris_english.build_neural architecture & optimization."""
    try:
        import torch
        from torch import nn
        from torch.nn import functional as F
    except Exception as exc:
        raise RuntimeError('PyTorch could not be imported. Run the matching START_Rubano_with_Anaconda.py launcher in Spyder; it uses your existing Anaconda base Python without changing Spyder settings.') from exc
    torch.manual_seed(SEED)
    torch.set_num_threads(2)
    from sklearn.preprocessing import StandardScaler
    activation = model_name.split('_')[1]
    features = RAW_FEATURES[:-1]
    sx=StandardScaler().fit(tr[features].to_numpy(float))
    xtr=sx.transform(tr[features].to_numpy(float)).astype('float32')
    xva=sx.transform(va[features].to_numpy(float)).astype('float32')
    ytr=tr['target'].to_numpy(float)
    yva=va['target'].to_numpy(float)
    ym,ys=float(ytr.mean()),float(ytr.std())
    if ys<1e-10:raise ValueError(f'Zero target variance in {model_name}')
    yt=((ytr-ym)/ys).astype('float32'); yv=((yva-ym)/ys).astype('float32')
    class Net(nn.Module):
        def __init__(self):
            super().__init__()
            self.hid=nn.Linear(len(features),8)
            self.out=nn.Linear(8,1)
        def forward(self,x):
            x=self.hid(x)
            x={'tanh':torch.tanh,'relu':F.relu,'gelu':F.gelu}[activation](x)
            return self.out(x).flatten()
    net=Net()
    opt=torch.optim.Adam(net.parameters(),lr=.001)
    a=torch.from_numpy(xtr);b=torch.from_numpy(yt)
    av=torch.from_numpy(xva);bv=torch.from_numpy(yv)
    gen=torch.Generator().manual_seed(SEED)
    best=None;best_loss=float('inf');best_epoch=0;stale=0
    for epoch in range(1,EPOCHS+1):
        net.train()
        for idx in torch.randperm(len(a),generator=gen).split(512):
            opt.zero_grad()
            loss=F.mse_loss(net(a[idx]),b[idx]);loss.backward();opt.step()
        net.eval()
        with torch.no_grad():score=float(F.mse_loss(net(av),bv))
        if score<best_loss-1.e-6:
            best_loss=score;best_epoch=epoch;stale=0
            best={k:v.detach().clone() for k,v in net.state_dict().items()}
        else:
            stale+=1
            if stale>=16:break
    net.load_state_dict(best)
    return {'input_mean':sx.mean_.copy(),'input_scale':sx.scale_.copy(),
            'weight_hidden':net.hid.weight.detach().numpy().copy(),
            'bias_hidden':net.hid.bias.detach().numpy().copy(),
            'weight_out':net.out.weight.detach().numpy().copy(),
            'bias_out':net.out.bias.detach().numpy().copy(),
            'target_mean':ym,'target_std':ys,'activation':activation,
            'features':features,'best_epoch':best_epoch,
            'train_min':tr[features].min().to_numpy(float),
            'train_max':tr[features].max().to_numpy(float)}


def save_nn(path, model):
    path.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(path,**model)


def read_nn(path):
    with np.load(path,allow_pickle=False) as a:
        d={k:a[k] for k in a.files}
    for k in ('activation',):d[k]=str(d[k].item())
    for k in ('target_mean','target_std'):d[k]=float(d[k])
    d['features']=[str(k) for k in d['features']]
    d['best_epoch']=int(d['best_epoch'])
    return d


def model_label(name):
    if name.startswith('NN_'):
        return 'NN '+name.split('_')[1].upper()+' (no p)'
    return 'LR' if name=='LR' else 'MLR + RH'


def calibrate_from_mandria():
    """Return instrument-specific fitted model objects and independent test metrics."""
    cal=load_module(find_calibration_script(),'mandria_user_calibration')
    sources=mandria_sources(cal)
    signature=cache_signature({k:Path(v.member) for k,v in sources.items()})
    import torch
    signature.update({'epochs':EPOCHS,'seed':SEED,'protocol':'30s day-disjoint 60/20/20',
                      'training_backend':'PyTorch','torch_version':torch.__version__})
    meta_path=OUTPUT_DIR/'mandria_training'/'manifest.json'
    current=None
    if meta_path.is_file():
        try:current=json.loads(meta_path.read_text(encoding='utf-8'))
        except Exception:pass
    models={};metrics=[]
    have_cache = current is not None and current.get('input_signature')==signature
    if not have_cache: announce('[TRAIN] Input sources changed or no previous cache: refitting selected models.')
    else: announce('[CACHE] Reusing Mandria-selected fits from unchanged original files.')

    # The user's original daily-coverage rules and independent chronological split.
    need_fit=False
    for inst in INSTRUMENTS:
        pols = list(GAS_SELECTION) if inst!='opc_drone' else []
        for gas in pols:
            for method in GAS_SELECTION[gas]:
                if not (OUTPUT_DIR/'mandria_training'/f'{inst}_{gas}_{method}.npz').is_file():need_fit=True
        if inst in ('opc_drone','ground_basic','ground_screen'):
            for gas in ('PM2.5','PM10'):
                for method in PM_SELECTION:
                    if not (OUTPUT_DIR/'mandria_training'/f'{inst}_{gas}_{method}.json').is_file():need_fit=True
    if have_cache and not need_fit:
        for inst in INSTRUMENTS:
            for gas,methods in GAS_SELECTION.items():
                if inst=='opc_drone':continue
                for method in methods:
                    models[(inst,gas,method)]=read_nn(OUTPUT_DIR/'mandria_training'/f'{inst}_{gas}_{method}.npz')
            if inst!='gas_drone':
                for gas in ('PM2.5','PM10'):
                    for method in PM_SELECTION:
                        models[(inst,gas,method)]=json.loads((OUTPUT_DIR/'mandria_training'/f'{inst}_{gas}_{method}.json').read_text())
        metrics=pd.read_csv(OUTPUT_DIR/'mandria_training'/'independent_test_metrics.csv').to_dict('records')
        return models,pd.DataFrame(metrics)

    raw={k:cal.read_sensor_binned(sources[k]) for k in INSTRUMENTS}
    raw=cal.attach_meteo(raw)
    gas_reference=cal.read_reference_gases(sources['thermo_reference'])
    pm_reference=cal.read_reference_pm(sources['pm_reference'])
    for inst in INSTRUMENTS:
        if inst != 'opc_drone':
            for gas,methods in GAS_SELECTION.items():
                paired,_=cal.usable_gas_days(raw[inst],gas_reference,gas,inst)
                if paired.empty: raise RuntimeError(f'No Mandria reference pairs: {inst} {gas}')
                split=cal.chronological_day_split(paired)
                for method in methods:
                    announce(f'[FIT] {inst} {gas} {model_label(method)}')
                    obj=train_nn_exact(split['train'],split['validation'],method)
                    models[(inst,gas,method)]=obj
                    save_nn(OUTPUT_DIR/'mandria_training'/f'{inst}_{gas}_{method}.npz',obj)
                    v=split['test'];p=nn_predict(obj,v[obj['features']].to_numpy(float))
                    metrics.append({'instrument':inst,'pollutant':gas,'method':method,
                                    'test_RMSE':np.sqrt(mean_squared_error(v.target,p)),
                                    'test_R2':r2_score(v.target,p),'n_test':len(v),
                                    'test_unit':UNITS[gas],
                                    'interpretation':'Mandria held-out days; not Sep22 field accuracy'})
        if inst != 'gas_drone':
            for gas in ('PM2.5','PM10'):
                paired,_=cal.usable_pm_days(raw[inst],pm_reference,gas.replace('.','_'),inst)
                if paired.empty: raise RuntimeError(f'No Mandria PM daily reference pairs: {inst} {gas}')
                split=cal.chronological_day_split(paired)
                for method in PM_SELECTION:
                    feats=['PM_raw'] if method=='LR' else ['PM_raw','RH']
                    train=split['train'];val=split['validation'];test=split['test']
                    # Same features and ordinary least squares as selected calibration.py
                    lr=LinearRegression().fit(train[feats].to_numpy(float),train.target.to_numpy(float))
                    obj={'features':feats,'intercept':float(lr.intercept_),
                         'coefficients':[float(v) for v in lr.coef_]}
                    models[(inst,gas,method)]=obj
                    p=lr.predict(test[feats].to_numpy(float))
                    metrics.append({'instrument':inst,'pollutant':gas,'method':method,
                                    'test_RMSE':np.sqrt(mean_squared_error(test.target,p)),
                                    'test_R2':r2_score(test.target,p),'n_test':len(test),
                                    'test_unit':UNITS[gas],
                                    'interpretation':'Mandria DAILY held-out means; not sample-level accuracy'})
                    (OUTPUT_DIR/'mandria_training'/f'{inst}_{gas}_{method}.json').write_text(
                        json.dumps(obj,indent=2),encoding='utf-8')
    m=pd.DataFrame(metrics)
    m.to_csv(OUTPUT_DIR/'mandria_training'/'independent_test_metrics.csv',index=False)
    meta_path.write_text(json.dumps({'input_signature':signature,'models':[list(k) for k in models],
                                    'note':'Trained on original Mandria sources; Sep22 is earlier than training period'},
                                   indent=2),encoding='utf-8')
    return models,m


def read_flights():
    if not FLIGHT_DIR.is_dir():raise FileNotFoundError(f'Flight data folder missing: {FLIGHT_DIR}')
    all_data={}
    for instrument in INSTRUMENTS:
        files=sorted(p for p in FLIGHT_DIR.iterdir()
                     if p.is_file() and p.suffix.lower()=='.csv' and p.name.lower().startswith(instrument+'_22.09.2026'))
        if not files:raise FileNotFoundError(f'Missing original flight files for {instrument}: {FLIGHT_DIR}')
        frames=[]
        for file in files:
            df=pd.read_csv(file,low_memory=False)
            for col in ('gps_date','gps_time_utc'):
                if col not in df:raise KeyError(f'{file.name} missing {col}')
            timestamps=pd.to_datetime(df['gps_date'].astype('string').str.strip()+' '+
                                       df['gps_time_utc'].astype('string').str.strip(),
                                       errors='coerce',utc=True,format='mixed')
            good=timestamps.dt.year.eq(2026)
            df=df.loc[good].copy()
            df['time_utc']=timestamps.loc[good].to_numpy()
            df['time_utc']=pd.to_datetime(df['time_utc'],utc=True)
            df['time_local']=df['time_utc'].dt.tz_convert(LOCAL_TZ)
            df=df.loc[df['time_local'].dt.date==CAMPAIGN_DAY].copy()
            df['source_file']=file.name
            for c in df.columns.difference(['source_file','gps_date','gps_time_utc','time_utc','time_local']):
                df[c]=pd.to_numeric(df[c],errors='coerce')
            frames.append(df)
            announce(f'[FLIGHT] {file.name}: {len(df)} rows on 22 Sep')
        all_data[instrument]=pd.concat(frames,ignore_index=True).sort_values('time_local')
    return all_data


def bounded_weather(df):
    d=df.copy()
    for orig,new,lo,hi in [('temp_c','T',-40,65),('humidity_percent','RH',0,100),
                           ('pressure_hpa','p',870,1085)]:
        d[new]=pd.to_numeric(d.get(orig,np.nan),errors='coerce')
        d[new]=d[new].where(d[new].between(lo,hi))
    return d


def input_columns_30s(frame):
    """The original Mandria inputs: O3_raw = MQ131 ADC, NOT volts."""
    if frame.empty:return pd.DataFrame(columns=RAW_FEATURES)
    f=frame.set_index('time_local').sort_index().copy()
    out=pd.DataFrame(index=f.index)
    mapping={'CO_raw':'mics_reducing_ohm','NO2_raw':'mics_oxidising_ohm',
             'O3_raw':'mq131_raw','T':'temp_c','RH':'humidity_percent','p':'pressure_hpa'}
    for dest,source in mapping.items():
        out[dest]=pd.to_numeric(f[source],errors='coerce') if source in f else np.nan
    out['O3_raw']=out['O3_raw'].where(out['O3_raw'].between(1,4094))
    for col in ('CO_raw','NO2_raw'):out[col]=out[col].where(out[col]>=0)
    for col,lo,hi in [('T',-40,65),('RH',0,100),('p',870,1085)]:
        out[col]=out[col].where(out[col].between(lo,hi))
    return out


def annotate_location(df):
    if df.empty:return df
    d=df.copy()
    d['site']=np.where(d['time_local'].dt.hour < 13,'Church Rubano','Roundabout Bosco')
    return d


def apply_models(all_data,models):
    """Build 30-second inferences and exploratory original-row inferences."""
    out={}
    source_raw={k: input_columns_30s(df) for k,df in all_data.items()}
    source_30={k:f.resample('30s').mean() for k,f in source_raw.items()}
    # As in original user's calibration: basic weather can supplement screen for
    # MODEL INPUT ONLY, without overwriting displayed measured T, RH or p.
    for col in ('T','RH','p'):
        source_30['ground_screen'][col] = (source_30['ground_screen'][col].combine_first(
                                         source_30['ground_basic'][col]))
    # user source 'unbenannt10.py' also specifies PM optional RH donor from ground.
    for instrument,df in all_data.items():
        d=bounded_weather(df).copy()
        d['site']=np.where(d['time_local'].dt.hour < 13,'Church Rubano','Roundabout Bosco')
        raw=source_raw[instrument]
        binned=source_30[instrument]
        binned_time=d['time_local'].dt.floor('30s')
        for gas,methods in GAS_SELECTION.items():
            if instrument=='opc_drone':continue
            for method in methods:
                model=models[(instrument,gas,method)]
                feats=model['features']
                fitted=pd.Series(np.nan,index=binned.index,dtype=float)
                valid=binned[feats].notna().all(axis=1)
                if valid.any():fitted.loc[valid]=nn_predict(model,binned.loc[valid,feats].to_numpy(float))
                d[f'{gas}__{method}__30s']=binned_time.map(fitted).to_numpy()
                if 'train_min' in model and 'train_max' in model:
                    inside=(binned[feats].ge(model['train_min']).all(axis=1) &
                            binned[feats].le(model['train_max']).all(axis=1))
                    d[f'{gas}__{method}__outside_training_range_30s']=(
                        ~binned_time.map(inside).fillna(False)).to_numpy()
                # Exploratory per-row network use, not 1-second validated.
                x=raw.reset_index(drop=True)[feats].copy()  # keep exact row order; raw timestamps may repeat
                if instrument=='ground_screen':
                    for c in ('T','RH'):
                        x[c]=x[c].combine_first(pd.Series(binned_time.map(binned[c]).to_numpy()))
                p=np.full(len(d),np.nan)
                ok=x.notna().all(axis=1)
                if ok.any():p[ok.to_numpy()]=nn_predict(model,x.loc[ok].to_numpy(float))
                d[f'{gas}__{method}__row']=p
        if instrument != 'gas_drone':
            for gas,original_col in [('PM2.5','pm2_5_ug_m3'),('PM10','pm10_ug_m3')]:
                for method in PM_SELECTION:
                    model=models[(instrument,gas,method)]
                    vals=pd.DataFrame({'PM_raw':pd.to_numeric(d.get(original_col,np.nan),errors='coerce'),
                                       'RH':d['RH']})
                    if 'RH' in model['features']:
                        # Only for model input: donor values from basic station.
                        if instrument in ('opc_drone','ground_screen'):
                            donor=source_30['ground_basic']['RH']
                            vals['RH']=vals['RH'].fillna(pd.Series(binned_time.map(donor).to_numpy()))
                    v=vals[model['features']]
                    pred=np.full(len(d),np.nan)
                    valid=v.notna().all(axis=1)
                    if valid.any():
                        pred[valid.to_numpy()]=model['intercept']+v.loc[valid].to_numpy(float)@np.asarray(model['coefficients'])
                    d[f'{gas}__{method}__row']=pred
        out[instrument]=d
    return out


def local_bounds(start,end):
    return (pd.Timestamp(f'{CAMPAIGN_DAY} {start}',tz=LOCAL_TZ),
            pd.Timestamp(f'{CAMPAIGN_DAY} {end}',tz=LOCAL_TZ))


def select_window(df,start,end,site):
    a,b=local_bounds(start,end)
    return df.loc[df['time_local'].between(a,b)&df['site'].eq(site)].copy()


def calculate_relative_altitude(df):
    """User's original dry-air hypsometric approach; initial stable 5-s pressure."""
    d=df.sort_values('time_local').copy()
    d['relative_altitude_m']=np.nan
    p=pd.to_numeric(d['p'],errors='coerce')
    T=pd.to_numeric(d['T'],errors='coerce')
    if not p.notna().any(): return d
    elapsed=(d['time_local']-d['time_local'].iloc[0]).dt.total_seconds()
    candidates=[]
    for offset in np.arange(0,16,1):
        values=p.loc[elapsed.between(offset,offset+5,inclusive='left')].dropna()
        if len(values)>=3:candidates.append((float(values.std(ddof=1)),float(values.median())))
    p0=min(candidates,key=lambda x:x[0])[1] if candidates else float(p.head(10).median())
    if not np.isfinite(p0) or p0<=0:return d
    d['reference_p0_hpa']=p0
    valid=(p>0)&T.between(-40,65)
    d.loc[valid,'relative_altitude_m']=(287.05*(T[valid]+273.15)/9.80665*np.log(p0/p[valid]))
    return d


def calculate_opc_height(df):
    d=df.sort_values('time_local').copy()
    d['relative_altitude_m']=np.nan
    z=pd.to_numeric(d.get('gps_alt_m',np.nan),errors='coerce')
    z=z.where(z.between(-100,3000))
    if z.notna().sum()>=5:
        d['relative_altitude_m']=z-z.dropna().head(5).median()
        d['height_source']='relative GPS altitude'
    elif d['p'].notna().sum()>=5:
        d=calculate_relative_altitude(d)
        d['height_source']='pressure-derived relative altitude'
    else:d['height_source']='height unavailable'
    return d


def add_direction(df):
    d=df.copy()
    z=pd.to_numeric(d['relative_altitude_m'],errors='coerce')
    if z.notna().sum()<3:
        d['direction']='Unknown';return d
    max_pos=z.idxmax()
    peak_time=d.loc[max_pos,'time_local']
    d['direction']=np.where(d['time_local']<=peak_time,'Ascent','Descent')
    return d


def choose_col(df,pol,method,mode='row'):
    col=f'{pol}__{method}__{mode}'
    return col if col in df else None


def show_plot(fig,path):
    path.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(path.with_suffix('.png'),dpi=210,bbox_inches='tight')
    fig.savefig(path.with_suffix('.pdf'),bbox_inches='tight')
    plt.close(fig)


def label_axes(ax):
    ax.grid(alpha=.2,linewidth=.6)
    ax.spines[['top','right']].set_visible(False)


def height_lines(ax, flight, site, pol, method, ground, resolution='row', show_ground=True):
    """Plot ascent/descent separately; shared height axis & ground mean lines."""
    col=choose_col(flight,pol,method,resolution)
    if not col:return
    for direct in ('Ascent','Descent'):
        sub=flight.loc[flight['direction']==direct].copy()
        valid=pd.to_numeric(sub[col],errors='coerce').notna() & sub['relative_altitude_m'].notna()
        sub=sub.loc[valid].copy()
        if sub.empty:continue
        sub['height_bin_m']=(sub['relative_altitude_m']/HEIGHT_BIN_M).round()*HEIGHT_BIN_M
        sub=sub.groupby('height_bin_m')[col].agg(['mean','count']).reset_index().sort_values('height_bin_m')
        # Model = color; ascent/descent = solid/dashed. Both dimensions are visible.
        color = MODEL_COLORS.get(method, DIRECTION_COLORS[direct])
        ax.plot(sub['mean'],sub['height_bin_m'],
                color=color, linestyle=DIRECTION_STYLES[direct],
                lw=2.0, marker='o' if direct=='Ascent' else 's', markersize=3,
                label=f'{model_label(method)} | {direct}')
    if show_ground:
        for inst in ('ground_basic','ground_screen'):
            g=ground.get(inst)
            if g is None or g.empty:continue
            colg=choose_col(g,pol,method,resolution)
            if colg is None:continue
            avg=pd.to_numeric(g[colg],errors='coerce').mean()
            if np.isfinite(avg):
                # Thin dotted markers = station means, not altitude-resolved data.
                ax.axvline(avg, color=DEVICE_COLORS[inst],
                           linestyle=':' if 'gelu' in method else '-.',
                           alpha=.72,lw=1.1,
                           label=f'{inst.replace("_"," ").title()} {model_label(method)} mean: {avg:.2f} ppb')
    ax.set_xlabel(f'{pol} ({UNITS[pol]})')
    ax.set_ylabel('Pressure-derived relative altitude (m)')
    label_axes(ax)


def add_weather_height(ax,flight,ground,key):
    for direct in ('Ascent','Descent'):
        sub=flight.loc[(flight['direction']==direct)&flight['relative_altitude_m'].notna(),['relative_altitude_m',key]].dropna()
        if sub.empty:continue
        sub=sub.copy()
        sub['height_bin_m']=(sub.relative_altitude_m/HEIGHT_BIN_M).round()*HEIGHT_BIN_M
        agg=sub.groupby('height_bin_m')[key].mean().sort_index()
        ax.plot(agg.to_numpy(),agg.index.to_numpy(),color=DIRECTION_COLORS[direct],
                marker='o',markersize=2.4,lw=1.8,label=direct)
    for inst in ('ground_basic','ground_screen'):
        g=ground.get(inst)
        if g is None or g.empty:continue
        val=pd.to_numeric(g[key],errors='coerce').mean()
        if np.isfinite(val):
            ax.axvline(val,color=DEVICE_COLORS[inst],ls=':',lw=1.4,
                       label=f'{inst.replace("_"," ").title()} mean')
    ax.set_xlabel(f'{key} ({UNITS[key]})');label_axes(ax)


def plot_o3_height_weather(flight,ground,label,dest,resolution='row'):
    if flight['relative_altitude_m'].notna().sum()<5:return
    fig=plt.figure(figsize=(12.8,11.0))
    grid=fig.add_gridspec(2,2,height_ratios=[1.5,1],hspace=.53,wspace=.25)
    ax_o=fig.add_subplot(grid[0,:])
    ax_t=fig.add_subplot(grid[1,0],sharey=ax_o)
    ax_rh=fig.add_subplot(grid[1,1],sharey=ax_o)
    for method in GAS_SELECTION['O3']:
        height_lines(ax_o,flight,label,'O3',method,ground,resolution=resolution)
    ax_o.set_title('Ozone: PyTorch NN GELU (blue) and NN Tanh (purple)\nSolid = ascent, dashed = descent')
    add_weather_height(ax_t,flight,ground,'T');ax_t.set_title('Temperature (raw)')
    add_weather_height(ax_rh,flight,ground,'RH');ax_rh.set_title('Humidity (raw)')
    ax_t.set_ylabel('Pressure-derived relative altitude (m)')
    for ax in (ax_o,ax_t,ax_rh):
        if ax is ax_o:
            ax.legend(fontsize=7.1,loc='upper center',bbox_to_anchor=(.5,-.13),ncol=2,frameon=True)
        else: ax.legend(fontsize=7.8,loc='best')
    fig.suptitle(label+' | O3 height profile, T and RH | '+
                 ('raw-row NN predictions (exploratory)' if resolution=='row' else '30s model predictions'),fontsize=14)
    fig.text(.02,.012,'Models trained/evaluated on 30s means after this flight. Ground means are time-matched, not altitude profiles.',fontsize=8)
    fig.subplots_adjust(left=.085,right=.98,bottom=.08,top=.87)
    show_plot(fig,dest)


def plot_gas_height(flight,ground,pol,label,dest,resolution='row'):
    if flight['relative_altitude_m'].notna().sum()<5:return
    fig,ax=plt.subplots(figsize=(8.6,7))
    height_lines(ax,flight,label,pol,GAS_SELECTION[pol][0],ground,resolution=resolution)
    ax.legend(fontsize=8)
    ax.set_title(f'{label}: {pol} vs pressure-derived relative altitude')
    fig.text(.03,.02,'Exploratory transfer of Mandria calibration; station means are not height-resolved.',fontsize=8)
    fig.tight_layout(rect=(0,.035,1,1));show_plot(fig,dest)


def plot_opc_height(flight,ground,pol,label,dest):
    if flight['relative_altitude_m'].notna().sum()<5:return
    fig,ax=plt.subplots(figsize=(9,7))
    for method in PM_SELECTION:
        col=choose_col(flight,pol,method)
        if col is None:continue
        for direct in ('Ascent','Descent'):
            sub=flight.loc[flight.direction==direct,['relative_altitude_m',col]].dropna()
            if sub.empty:continue
            sub=sub.copy();sub['zbin']=(sub.relative_altitude_m/HEIGHT_BIN_M).round()*HEIGHT_BIN_M
            a=sub.groupby('zbin')[col].mean()
            ax.plot(a.values,a.index,color=DIRECTION_COLORS[direct],
                    linestyle='--' if method=='MLR_RH' else '-',
                    label=f'{model_label(method)} – {direct}')
        for inst in ('ground_basic','ground_screen'):
            g=ground.get(inst)
            if g is None or g.empty:continue
            colg=choose_col(g,pol,method)
            if colg is None:continue
            val=pd.to_numeric(g[colg],errors='coerce').mean()
            if np.isfinite(val):ax.axvline(val,ls=':',lw=1.5,color=DEVICE_COLORS[inst],
                                          label=f'{inst} {model_label(method)} mean')
    ax.set_xlabel(f'{pol} ({UNITS[pol]})');ax.set_ylabel('Relative altitude (m)')
    ax.set_title(f'{label}: exploratory {pol} height profile (daily-mean PM calibration)')
    ax.legend(fontsize=7);label_axes(ax);show_plot(fig,dest)


def plot_full_time(flight,ground,other_drone,label,fly_inst,dest):
    vars=['CO','NO2','O3','PM2.5','PM10','T','p','RH','relative_altitude_m']
    data={fly_inst:flight,**ground}
    if other_drone is not None and not other_drone.empty:
        data[('opc_drone' if fly_inst=='gas_drone' else 'gas_drone')]=other_drone
    fig,axs=plt.subplots(len(vars),1,figsize=(16,19),sharex=True)
    for ax,pol in zip(axs,vars):
        for inst,frame in data.items():
            if frame is None or frame.empty:continue
            if pol=='relative_altitude_m':
                if inst!=fly_inst:continue
                columns=[('relative_altitude_m','Measured height estimate')]
            elif pol in ('T','p','RH'):
                columns=[(pol,'raw')]
            elif pol in ('CO','NO2','O3'):
                if inst=='opc_drone':continue
                columns=[(f'{pol}__{method}__30s',model_label(method)) for method in GAS_SELECTION[pol]]
            else:
                if inst=='gas_drone':continue
                columns=[(f'{pol}__{method}__row',model_label(method)) for method in PM_SELECTION]
            for col,model_name in columns:
                if col not in frame:continue
                y=pd.to_numeric(frame[col],errors='coerce')
                if y.notna().sum()<2:continue
                # Do not hide model pathologies in the exported CSV; negatives
                # remain visible in plot as out-of-range diagnostics where present.
                ax.plot(frame.time_local,y,color=DEVICE_COLORS[inst],
                        linestyle='--' if 'Tanh' in model_name or 'MLR' in model_name else '-',
                        lw=1.3,alpha=.88,label=f'{inst.replace("_"," ")} | {model_name}')
        ax.set_ylabel(f'{pol} ({UNITS.get(pol,"m")})' if pol!='relative_altitude_m' else 'Height (m)')
        label_axes(ax)
        if ax.get_legend_handles_labels()[0]:ax.legend(loc='upper left',fontsize=7,ncol=3)
    axs[-1].xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S',tz=LOCAL_TZ))
    axs[-1].set_xlabel('Local time in Italy (CEST)')
    fig.suptitle(f'{label} | All measurements and ground stations | {fly_inst}',fontsize=16)
    fig.text(.02,.01,'Gas lines: 30s-trained NNs; PM lines: models calibrated against daily reference means. T, p, RH: raw measurements. No simultaneous local reference available.',fontsize=8)
    fig.tight_layout(rect=(0,.025,1,.975));show_plot(fig,dest)


def plot_legacy_formula_comparison(flight,label,old,ground):
    """Historic 6-input formulas are NOT the selected no-pressure NN networks."""
    if flight.empty or 'O3__NN_gelu_without_pressure__30s' not in flight:return
    raw=flight.set_index('time_local').sort_index()
    numeric=pd.DataFrame(index=raw.index)
    numeric['CO_raw']=pd.to_numeric(raw['mics_reducing_ohm'],errors='coerce')
    numeric['NO2_raw']=pd.to_numeric(raw['mics_oxidising_ohm'],errors='coerce')
    numeric['O3_raw']=pd.to_numeric(raw['mq131_raw'],errors='coerce')/4095*3.3
    for src,dest in [('temp_c','T'),('pressure_hpa','p'),('humidity_percent','RH')]:
        numeric[dest]=pd.to_numeric(raw[src],errors='coerce')
    numeric=numeric.resample('30s').mean()[['CO_raw','NO2_raw','O3_raw','T','p','RH']]
    curves={}
    for variant in ('0','15'):
        valid=numeric.notna().all(axis=1)
        vals=pd.Series(np.nan,index=numeric.index)
        if valid.any():
            vals.loc[valid]=old.predict_surrogate('O3',variant,numeric.loc[valid])
        curves[f'Historic 6-input surrogate {variant} interactions']=vals
    selected=flight.groupby(flight.time_local.dt.floor('30s'))[
        ['O3__NN_gelu_without_pressure__30s','O3__NN_tanh_without_pressure__30s']].mean()
    fig,ax=plt.subplots(figsize=(12.8,5.1))
    for name,col in [('Selected NN GELU (no pressure)','O3__NN_gelu_without_pressure__30s'),
                     ('Selected NN Tanh (no pressure)','O3__NN_tanh_without_pressure__30s')]:
        ax.plot(selected.index,selected[col],lw=2,label=name)
    for name,values in curves.items():ax.plot(values.index,values,ls=':',lw=1.5,label=name)
    # Same time window: BOTH ground stations are shown in this diagnostic too.
    for inst,g in ground.items():
        if g is None or g.empty:continue
        ground_col='O3__NN_gelu_without_pressure__30s'
        if ground_col in g:
            ax.plot(g.time_local,g[ground_col],color=DEVICE_COLORS[inst],lw=1.25,
                    alpha=.75,label=f'{inst.replace("_"," ").title()} – selected GELU')
    ax.set_ylabel('O3 (ppb)');ax.set_xlabel('Local time (CEST)')
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S',tz=LOCAL_TZ))
    ax.set_title(f'{label}: selected NNs vs earlier surrogate FORMULAS (different model families)')
    ax.legend(fontsize=8);label_axes(ax);show_plot(fig,OUTPUT_DIR/label.replace(' ','_')/'historic_formula_diagnostics')


def station_stats(flight,ground,label,inst_name):
    allrows=[]
    for inst,df in [(inst_name,flight),*ground.items()]:
        if df is None or df.empty:continue
        for pol in ('CO','NO2','O3','PM2.5','PM10','T','p','RH'):
            if pol in ('T','p','RH'):
                methods=['raw'];col_fn=lambda _m:pol
            elif pol in GAS_SELECTION:
                methods=GAS_SELECTION[pol];col_fn=lambda m:f'{pol}__{m}__30s'
            else:
                methods=PM_SELECTION;col_fn=lambda m:f'{pol}__{m}__row'
            for method in methods:
                col=col_fn(method)
                if col not in df:continue
                s=pd.to_numeric(df[col],errors='coerce').dropna()
                if s.empty:continue
                allrows.append({'flight':label,'instrument':inst,'pollutant':pol,
                                'model':method,'N':len(s),'mean':float(s.mean()),
                                'SD_temporal_variability':float(s.std()) if len(s)>1 else np.nan,
                                'min':float(s.min()),'max':float(s.max()),'unit':UNITS[pol]})
    return allrows


def main():
    OUTPUT_DIR.mkdir(parents=True,exist_ok=True)
    import torch
    announce('PyTorch backend: '+torch.__version__+' | python '+sys.executable)
    announce('Calibration source: only the user\'s original Mandria and flight files')
    announce('Selected models: CO ReLU, NO2 Tanh, O3 GELU + Tanh without p; PM LR + MLR(RH)')
    models,metrics=calibrate_from_mandria()
    data=apply_models(read_flights(),models)
    allstats=[]
    old=None
    if ADD_LEGACY_FORMULA_COMPARISON and LEGACY_SCRIPT.is_file():
        try:
            import os
            os.environ['PADUA_BASE_DIR']=str(FLIGHT_DIR)
            old=load_module(LEGACY_SCRIPT,'user_legacy_rubano_formula_source')
            announce('[FORMULAS] Read original user-supplied surrogate formulas from unbenannt10.py')
        except Exception as exc:
            announce(f'[FORMULAS] Optional legacy surrogates not available: {exc}')
    for name,site,fly_inst,start,end in WINDOWS:
        flyer=select_window(data[fly_inst],start,end,site)
        if flyer.empty:
            announce(f'[SKIP] Missing flight data: {name}');continue
        flyer=(calculate_relative_altitude(flyer) if fly_inst=='gas_drone'
               else calculate_opc_height(flyer))
        flyer=add_direction(flyer)
        subdir=OUTPUT_DIR/name;subdir.mkdir(parents=True,exist_ok=True)
        ground={g:select_window(data[g],start,end,site) for g in ('ground_basic','ground_screen')}
        other=select_window(data['opc_drone' if fly_inst=='gas_drone' else 'gas_drone'],
                            start,end,site)
        flyer.to_csv(subdir/'flight_predictions_with_height.csv',index=False)
        for g,df in ground.items():df.to_csv(subdir/f'{g}_matched.csv',index=False)
        allstats.extend(station_stats(flyer,ground,name,fly_inst))
        plot_full_time(flyer,ground,other,name,fly_inst,subdir/'all_variables_with_ground_stations')
        if fly_inst=='gas_drone':
            plot_o3_height_weather(flyer,ground,name,subdir/'O3_height_T_RH_selected_GELU_Tanh_1s_exploratory')
            # Show legitimate 30-second NN time resolution as a second figure.
            temp=flyer.copy()
            temp['time_bin']=temp.time_local.dt.floor('30s')
            for method in GAS_SELECTION['O3']:
                base=f'O3__{method}__30s'
                temp[f'O3__{method}__row']=temp[base]
            plot_o3_height_weather(temp,ground,name,subdir/'O3_height_T_RH_selected_GELU_Tanh_30s',resolution='30s')
            for pol in ('NO2','CO'):
                plot_gas_height(flyer,ground,pol,name,subdir/f'{pol}_height_profile')
            if old:plot_legacy_formula_comparison(flyer,name,old,ground)
        else:
            for pol in ('PM2.5','PM10'):
                plot_opc_height(flyer,ground,pol,name,subdir/f'{pol.replace(".","_")}_OPC_ground_height')
        announce(f'[OUTPUT] {name}: {len(flyer)} rows, ground basic {len(ground["ground_basic"])}, ground screen {len(ground["ground_screen"])}')
    pd.DataFrame(allstats).to_csv(OUTPUT_DIR/'flight_and_ground_statistics.csv',index=False)
    metrics.to_csv(OUTPUT_DIR/'mandria_historical_test_RMSE.csv',index=False)
    formulas=[]
    for (inst,pol,method),obj in models.items():
        if pol not in ('PM2.5','PM10'):continue
        coeffs=obj['coefficients'];parts=[f'{obj["intercept"]:.8g}']
        for coef,feature in zip(coeffs,obj['features']):parts.append(f'({coef:.8g}) * {feature}')
        formulas.append({'instrument':inst,'pollutant':pol,'method':method,
                         'equation':f'{pol} = '+' + '.join(parts),'unit':UNITS[pol],
                         'validation':'MANDRIA daily reference; field profile exploratory'})
    pd.DataFrame(formulas).to_csv(OUTPUT_DIR/'fitted_PM_formulas.csv',index=False)
    (OUTPUT_DIR/'READ_ME.txt').write_text(
        'All inputs are the user\'s own CSV/XLS files.\n'
        'Gas NN: TRAINED and PREDICTED with PyTorch on 30s means, day-disjoint train/val/test.\n'
        '22 Sep models applied before their training period and at raw-row level (exploratory).\n'
        'PM formulas trained on Mandria daily means (not sample-level validated).\n'
        'RMSE tables are historic Mandria test errors, not local flight uncertainty.\n'
        'Two ground stations always appear wherever their data are available.\n',encoding='utf-8')
    announce('\nFINISHED: '+str(OUTPUT_DIR))


if __name__=='__main__':main()
# %%

