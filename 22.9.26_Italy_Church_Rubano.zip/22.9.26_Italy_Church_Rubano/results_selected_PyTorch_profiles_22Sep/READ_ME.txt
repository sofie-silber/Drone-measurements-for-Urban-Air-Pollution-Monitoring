All inputs are the user's own CSV/XLS files.
Gas NN: TRAINED and PREDICTED with PyTorch on 30s means, day-disjoint train/val/test.
22 Sep models applied before their training period and at raw-row level (exploratory).
PM formulas trained on Mandria daily means (not sample-level validated).
RMSE tables are historic Mandria test errors, not local flight uncertainty.
Two ground stations always appear wherever their data are available.
