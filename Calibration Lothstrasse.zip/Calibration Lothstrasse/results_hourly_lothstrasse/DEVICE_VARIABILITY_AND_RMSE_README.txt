Lothstrasse hourly reference comparison

Official station screenshot values: plotted without uncertainty/error bars.
Device error bars: +/- 1 standard deviation of available 1-second
calibrated predictions within each eligible clock hour.
This indicates short-term temporal variability, NOT sensor accuracy,
instrument uncertainty, standard error or a confidence interval.

RMSE is computed from the paired eligible full-hour model and station means.
It is not the error bar on each point.
Station gas values in ug/m3 are converted to ppb at LfU reference
conditions (20 C, 1013 hPa). LMU-weather alternative is exported only
as an exploratory sensitivity analysis.
LfU reference conditions: https://www.lfu.bayern.de/luft/immissionsmessungen/messwertarchiv/doc/wichtige_hinweise_zu_den_daten.pdf
