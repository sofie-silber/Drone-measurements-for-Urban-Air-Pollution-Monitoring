#!/usr/bin/env python3
"""LMU MIM01 historical minute weather export: all variables in current-conditions display.

Station: LMU Meteorological Institute, Theresienstrasse 37, Munich.
Period: 2026-11-14 13:30 to 20:05 Europe/Berlin (CET, UTC+1).

Run in Spyder with F5. Requires: requests, pandas, numpy (matplotlib optional).
Original API responses are archived next to the output for traceability.
"""

from pathlib import Path
import json
import math
import re
import warnings

import numpy as np
import pandas as pd
import requests

# --------- SETTINGS: CHANGE THESE IF NEEDED ---------
START_LOCAL = "2026-11-14 13:30:00"
END_LOCAL = "2026-11-14 20:05:00"
LOCAL_TZ = "Europe/Berlin"
STATION = "MIM01"
STATION_ELEVATION_M = 517.0  # approximate station elevation for sea-level pressure estimate
OUTPUT_DIR = Path.home() / "Desktop" / "Master" / "Thesis" / "Background_Data_Paris" / "LMU_Weather"
API_ROOT = "https://www.meteo.physik.uni-muenchen.de/request-beta/data/"
MISSING_SENTINEL = 9.969209968386869e36

# All directly queryable quantities shown in the LMU current-conditions panel.
VARIABLES = {
    "air_temperature_2m": "Air temperature 2 m",
    "air_temperature_30m": "Air temperature 30 m",
    "relative_humidity_2m": "Relative humidity 2 m",
    "relative_humidity_30m": "Relative humidity 30 m",
    "wet_bulb_temperature_2m": "Wet-bulb temperature 2 m",
    "wet_bulb_temperature_30m": "Wet-bulb temperature 30 m",
    "wind_speed_30m": "Wind speed 30 m",
    "wind_from_direction_30m": "Wind direction 30 m",
    "air_pressure": "Station air pressure",
    "precipitation_amount": "Precipitation amount",
    "parsivel_precipitation_type": "Precipitation type (code)",
    "downwelling_shortwave_flux": "Global solar radiation",
    "diffuse_downwelling_flux": "Diffuse solar radiation",
    "downwelling_longwave_flux": "Atmospheric longwave radiation",
    "duration_of_sunshine_percent_of_minute": "Sunshine fraction of minute",
    "uv_index": "UV index",
}

# The following are derived, not explicitly exposed under these names by the API:
# dew point, sea-level pressure, current precipitation rate, cumulative daily
# precipitation, cumulative sunshine duration.


def _find_key_tree(obj, key, depth=0):
    """Find the first value of a key anywhere in a JSON object."""
    if depth > 9:
        return None
    if isinstance(obj, dict):
        if key in obj:
            return obj[key]
        for child in obj.values():
            result = _find_key_tree(child, key, depth + 1)
            if result is not None:
                return result
    elif isinstance(obj, list) and len(obj) < 10000:
        # Avoid searching every element of long homogeneous time series.
        for child in obj[:3]:
            if isinstance(child, (dict, list)):
                result = _find_key_tree(child, key, depth + 1)
                if result is not None:
                    return result
    return None


def _unwrap_values(value):
    """Handle common API representations: list or {values: [...]} etc."""
    if isinstance(value, dict):
        for key in ("values", "value", "data", "observations", "measurements"):
            if key in value:
                return _unwrap_values(value[key])
        return None
    if isinstance(value, (tuple, list)):
        return value
    return None


def _timestamps(values):
    s = pd.Series(values)
    if s.empty:
        return pd.to_datetime(s, utc=True)
    num = pd.to_numeric(s, errors="coerce")
    if num.notna().sum() >= 0.9 * len(s):
        typical = num.abs().median()
        if typical > 1e17:
            unit = "ns"
        elif typical > 1e14:
            unit = "us"
        elif typical > 1e11:
            unit = "ms"
        else:
            unit = "s"
        return pd.to_datetime(num, unit=unit, utc=True, errors="coerce")
    # Time values sent as formatted strings are assumed UTC, according to API documentation.
    return pd.to_datetime(s, utc=True, errors="coerce", format="mixed")


def parse_variable(payload, variable):
    """Extract time + value from supported common JSON layouts.

    If the API uses a different format, the original JSON is preserved and a
    clear error shows the top-level keys instead of silently fabricating data.
    """
    # Layout A: lists of row records, either at top-level or under station/data.
    lists_to_check = []
    if isinstance(payload, list):
        lists_to_check.append(payload)
    for k in (STATION, "data", "results", "observations", "measurements"):
        x = _find_key_tree(payload, k)
        if isinstance(x, list):
            lists_to_check.append(x)
    for records in lists_to_check:
        if not records or not isinstance(records[0], dict):
            continue
        df = pd.DataFrame(records)
        time_key = next((k for k in ("time", "timestamp", "datetime", "date") if k in df), None)
        value_key = variable if variable in df else None
        if value_key is None and "value" in df:
            if "variable" in df:
                df = df[df["variable"].eq(variable)]
            value_key = "value"
        if time_key and value_key:
            return pd.DataFrame({"timestamp": _timestamps(df[time_key].to_numpy()),
                                 variable: pd.to_numeric(df[value_key], errors="coerce").to_numpy()})

    # Layout B: shared 'time' list plus per-variable list, nested or flat.
    val = _find_key_tree(payload, variable)
    numbers = _unwrap_values(val)
    if numbers is None and isinstance(val, dict):
        numbers = _unwrap_values(val)
    for key in ("time", "timestamp", "timestamps", "datetime", "date"):
        times = _unwrap_values(_find_key_tree(payload, key))
        if times is not None and numbers is not None and len(times) == len(numbers):
            # Accept scalar values or dictionaries with a value field.
            data = [p.get("value", np.nan) if isinstance(p, dict) else p for p in numbers]
            return pd.DataFrame({"timestamp": _timestamps(times).to_numpy(),
                                 variable: pd.to_numeric(pd.Series(data), errors="coerce").to_numpy()})

    # Layout C: list pairs [timestamp, measurement].
    if numbers and isinstance(numbers[0], (list, tuple)) and len(numbers[0]) >= 2:
        return pd.DataFrame({"timestamp": _timestamps([r[0] for r in numbers]).to_numpy(),
                             variable: pd.to_numeric(pd.Series([r[1] for r in numbers]), errors="coerce").to_numpy()})

    keys = list(payload)[:20] if isinstance(payload, dict) else type(payload).__name__
    raise ValueError(f"Could not interpret JSON layout for {variable}; top-level keys: {keys}")


def temperature_c(s):
    s = pd.to_numeric(s, errors="coerce")
    median = s.median()
    if pd.notna(median) and median > 180:  # Kelvin to Celsius
        return s - 273.15
    return s  # already Celsius (or no valid data)


def rh_pct(s):
    s = pd.to_numeric(s, errors="coerce")
    median = s.median()
    if pd.notna(median) and 0 <= median <= 1.0 and s.max() <= 1.05:
        return s * 100
    return s


def dew_point_c(temp_c, humidity_pct):
    """Magnus approximation for water vapor over liquid water."""
    r = humidity_pct.where((humidity_pct > 0) & (humidity_pct <= 100))
    a, b = 17.625, 243.04
    with np.errstate(divide="ignore", invalid="ignore"):
        gamma = np.log(r / 100.0) + a * temp_c / (b + temp_c)
        return b * gamma / (a - gamma)


def fetch_one(session, variable, begin_utc, end_utc, archive):
    # The API expects these four fields in the URL PATH (not a ?query string).
    fmt = lambda ts: ts.strftime("%Y-%m-%dT%H-%M-%S")
    url = (API_ROOT + f"var={variable}&station={STATION}"
           f"&start={fmt(begin_utc)}&end={fmt(end_utc)}")
    response = session.get(url, timeout=90)
    response.raise_for_status()
    payload = response.json()
    (archive / f"{variable}.json").write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    data = parse_variable(payload, variable)
    data["timestamp"] = pd.to_datetime(data["timestamp"], utc=True, errors="coerce")
    data[variable] = pd.to_numeric(data[variable], errors="coerce")
    data.loc[data[variable].abs() > 1e30, variable] = np.nan  # API fill value
    data = data.dropna(subset=["timestamp"]).sort_values("timestamp")
    data = data.set_index("timestamp")[[variable]]
    # Standardize the native series to minute resolution; no gap interpolation.
    if variable == "parsivel_precipitation_type":
        return data.resample("1min").last()
    return data.resample("1min").mean()


def make_plot(df, out_dir):
    try:
        import matplotlib.pyplot as plt
        panels = [
            (["air_temperature_2m_C", "air_temperature_30m_C"], "Air temperature (°C)"),
            (["relative_humidity_2m_pct", "relative_humidity_30m_pct"], "Relative humidity (%)"),
            (["wind_speed_30m_m_s"], "Wind speed (m/s)"),
            (["station_pressure_hPa"], "Station pressure (hPa)"),
            (["global_radiation_W_m2", "diffuse_radiation_W_m2", "atmospheric_longwave_W_m2"], "Radiation (W/m²)"),
        ]
        fig, axes = plt.subplots(len(panels), 1, figsize=(13, 12), sharex=True)
        xs = pd.to_datetime(df["time_local"].str.slice(0, 19))
        for ax, (columns, title) in zip(axes, panels):
            for col in columns:
                if col in df and df[col].notna().any():
                    ax.plot(xs, df[col], label=col, lw=1)
            ax.set_ylabel(title)
            ax.grid(alpha=0.25)
            ax.legend(loc="best", fontsize=8)
        axes[-1].set_xlabel("Time (Munich, CET)")
        fig.suptitle("LMU MIM01 – Weather measurements, 14 November 2026")
        fig.tight_layout()
        fig.savefig(out_dir / "LMU_weather_timeseries.png", dpi=160)
        plt.close(fig)
    except ImportError:
        print("Matplotlib is not installed; skipping time-series figure.")


def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    archive = OUTPUT_DIR / "original_api_json"
    archive.mkdir(exist_ok=True)

    begin = pd.Timestamp(START_LOCAL, tz=LOCAL_TZ).tz_convert("UTC")
    end = pd.Timestamp(END_LOCAL, tz=LOCAL_TZ).tz_convert("UTC")
    # Query all variables since 00:00 UTC so daily totals can be computed.
    day_start = begin.normalize()
    full_times = pd.date_range(day_start, end, freq="1min", tz="UTC")
    raw = pd.DataFrame(index=full_times)

    print(f"Station: {STATION} (LMU, Theresienstrasse 37, Munich)")
    print(f"Requested local interval: {START_LOCAL} to {END_LOCAL} ({LOCAL_TZ})")
    print(f"UTC interval: {begin} to {end}")
    session = requests.Session()
    errors = {}
    for var in VARIABLES:
        try:
            result = fetch_one(session, var, day_start, end, archive)
            raw[var] = result[var].reindex(full_times)
            print(f"Downloaded {var}: {raw[var].notna().sum()} minute values")
        except Exception as e:
            raw[var] = np.nan
            errors[var] = f"{type(e).__name__}: {e}"
            print(f"WARNING - {var}: {errors[var]}")

    if not any(raw[v].notna().any() for v in VARIABLES):
        raise RuntimeError("No weather measurements were downloaded. Check internet access and API. "
                           f"Problems: {errors}")

    result = pd.DataFrame(index=raw.index)
    for h in ("2m", "30m"):
        result[f"air_temperature_{h}_C"] = temperature_c(raw[f"air_temperature_{h}"])
        result[f"relative_humidity_{h}_pct"] = rh_pct(raw[f"relative_humidity_{h}"])
        result[f"wet_bulb_temperature_{h}_C"] = temperature_c(raw[f"wet_bulb_temperature_{h}"])
        result[f"dew_point_{h}_C_calculated"] = dew_point_c(
            result[f"air_temperature_{h}_C"], result[f"relative_humidity_{h}_pct"])

    result["wind_speed_30m_m_s"] = raw["wind_speed_30m"]
    result["wind_from_direction_30m_deg"] = raw["wind_from_direction_30m"]

    station_pressure = raw["air_pressure"]
    if pd.notna(station_pressure.median()) and station_pressure.median() > 20000:
        station_pressure = station_pressure / 100.0  # Pa -> hPa
    result["station_pressure_hPa"] = station_pressure
    # Approximate hypsometric reduction to sea level using measured air temperature
    # at 30 m and a 6.5 K/km standard lapse rate for the 517m height difference.
    Tmean_K = result["air_temperature_30m_C"] + 273.15 + 0.0065 * STATION_ELEVATION_M / 2
    result["sea_level_pressure_hPa_estimated"] = station_pressure * np.exp(
        (9.80665 * STATION_ELEVATION_M) / (287.05 * Tmean_K))

    result["precipitation_amount_per_minute_mm_assumed"] = raw["precipitation_amount"]
    result["precipitation_rate_mm_h_estimated"] = raw["precipitation_amount"] * 60
    result["precipitation_since_00UTC_mm_estimated"] = raw["precipitation_amount"].cumsum()
    result["precipitation_type_raw_code"] = raw["parsivel_precipitation_type"]

    result["global_radiation_W_m2"] = raw["downwelling_shortwave_flux"]
    result["diffuse_radiation_W_m2"] = raw["diffuse_downwelling_flux"]
    result["atmospheric_longwave_W_m2"] = raw["downwelling_longwave_flux"]
    result["uv_index"] = raw["uv_index"]

    sunshine = raw["duration_of_sunshine_percent_of_minute"]
    # The variable explicitly specifies percentage of a minute (0...100%).
    # Do not guess fraction-versus-percent from the observed maximum: a cloudy
    # day may have values below 1%, which would otherwise be misinterpreted.
    sunshine_fraction = sunshine / 100.0
    result["sunshine_percent_of_minute"] = sunshine_fraction * 100
    result["sunshine_minutes_since_00UTC_estimated"] = sunshine_fraction.cumsum()

    # Keep only the requested local window (inclusive).
    result = result.loc[begin:end].copy()
    result.insert(0, "time_utc", result.index.strftime("%Y-%m-%d %H:%M:%S UTC"))
    result.insert(1, "time_local", result.index.tz_convert(LOCAL_TZ).strftime("%Y-%m-%d %H:%M:%S %Z"))

    csv_path = OUTPUT_DIR / "LMU_MIM01_all_weather_2026-11-14_1330-2005.csv"
    result.to_csv(csv_path, index=False, encoding="utf-8-sig", float_format="%.5f")
    completeness = pd.DataFrame({"variable": result.columns[2:],
                                 "n_valid": [int(result[c].notna().sum()) for c in result.columns[2:]],
                                 "n_minutes": len(result)})
    completeness.to_csv(OUTPUT_DIR / "LMU_weather_data_availability.csv", index=False)
    (OUTPUT_DIR / "download_warnings.json").write_text(
        json.dumps(errors, indent=2, ensure_ascii=False), encoding="utf-8")
    make_plot(result.reset_index(drop=True), OUTPUT_DIR)

    print("\nWeather CSV saved to:", csv_path)
    print(f"Time rows: {len(result)} | Columns: {len(result.columns)}")
    if errors:
        print(f"{len(errors)} variable(s) unavailable or returned an unrecognized format. See download_warnings.json")
    print("Important: LMU reports a known high-temperature bias in 2026 at 2 m.")
    print("Derived dew points and sea-level pressure are estimates, not direct LMU API variables.")
    print("Precipitation rate and totals assume precipitation_amount is mm per minute; confirm API units.")
    print("Credit: Meteorological Institute, LMU Munich (MIM01).")


if __name__ == "__main__":
    main()
