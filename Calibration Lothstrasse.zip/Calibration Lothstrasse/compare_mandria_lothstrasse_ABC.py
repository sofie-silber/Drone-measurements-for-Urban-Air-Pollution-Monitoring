#!/usr/bin/env python3
"""Compare instrument-specific Mandria neural calibration transfer A/B/C.

A: Mandria-only network (unchanged after training).
B: Fine-tune ONLY the final linear layer of A on Lothstrasse hourly labels.
C: NEW network trained from scratch using Mandria 30-s reference pairs PLUS
   Lothstrasse hourly reference labels (hourly-mean prediction loss).

Scientific design:
  * No hourly target is duplicated as a fictitious per-second label.
  * Leave-one-hour-out (LOHO) evaluation for B and C, with exactly the same
    withheld hourly reference point used to evaluate A.
  * Mandria chronological TRAIN/VALIDATION/TEST days kept separate. Neither
    the Mandria test days nor the held-out Lothstrasse hour enter training.
  * Final B/C networks trained using ALL eligible winter hours are exported for
    subsequent exploratory use ONLY; their fit to those hours is not independent.
  * Calibration uses NO2 and O3 only: CO has no Lothstrasse reference; PM2.5
    uses daily-reference linear models, NOT one of the selected gas NNs.

Run in Spyder: place this file beside calibration_paris_english.py and
lothstrasse_hourly_calibration.py in the Calibration Lothstrasse folder, press F5.
All console text and figures are in English.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
import os
import random
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

try:
    import torch
    from torch import nn
    from torch.nn import functional as F
except ImportError as exc:
    raise ImportError(
        "PyTorch is required. In the Spyder IPython console run: %pip install torch"
    ) from exc

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
try:
    import calibration_paris_english as cal
    import lothstrasse_hourly_calibration as loth
except ImportError as exc:
    raise ImportError(
        "Put calibration_paris_english.py and lothstrasse_hourly_calibration.py "
        "in the same folder as compare_mandria_lothstrasse_ABC.py."
    ) from exc

# -------- OPTIONS -----------------------------------------------------------
OUTPUT_DIR = loth.FIELD_ROOT / 'results_transfer_learning_ABC'
FEATURES = ['CO_raw', 'NO2_raw', 'O3_raw', 'T', 'RH']  # NO PRESSURE
MODELS = {'NO2': ('tanh',), 'O3': ('gelu', 'tanh')}
INSTRUMENTS = loth.GAS_INSTRUMENTS
# Mandria calibration gas concentration units must be checked at the source.
# The Lothstrasse published mass units are converted to ppb at LfU reference
# conditions (20 C, 1013 hPa), never by blindly using local ambient weather.
MANDRIA_GAS_REFERENCE_UNIT = 'ppb'  # MUST match original Mandria reference data
SEED = int(os.getenv('ABC_SEED', '42'))
A_EPOCHS = int(os.getenv('ABC_A_EPOCHS', '100'))
B_EPOCHS = int(os.getenv('ABC_B_EPOCHS', '45'))
C_EPOCHS = int(os.getenv('ABC_C_EPOCHS', '70'))
B_LR = float(os.getenv('ABC_B_LR', '0.0003'))
C_LR = float(os.getenv('ABC_C_LR', '0.001'))
B_ANCHOR_LAMBDA = 0.03  # penalize changes to output layer vs A weights
C_WINTER_LOSS_WEIGHT = 1.0  # hourly-loss weight relative to Mandria MSE
TRAIN_SAMPLES_PER_WINTER_HOUR = int(os.getenv('ABC_TRAIN_SAMPLES_HOUR', '480'))
MIN_FIELD_COVERAGE = 0.90  # 3240 actual valid 1-s values out of 3600
MIN_WINTER_HOURS = 4       # no defensible fold training with fewer than 3 other hours
MAKE_ALL_SECOND_OUTPUTS = True
# ---------------------------------------------------------------------------


def log(message):
    print(message, flush=True)


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(2)


def source_fingerprint(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for buf in iter(lambda: f.read(2**20), b''):
            h.update(buf)
    return h.hexdigest()


class SmallNet(nn.Module):
    """Exact hidden-layer layout used in calibration_paris_english.build_neural."""
    def __init__(self, activation, nfeatures=5):
        super().__init__()
        self.activation = activation
        self.hid = nn.Linear(nfeatures, 8)
        self.out = nn.Linear(8, 1)

    def forward(self, x):
        x = self.hid(x)
        if self.activation == 'gelu':
            x = F.gelu(x)
        elif self.activation == 'tanh':
            x = torch.tanh(x)
        elif self.activation == 'relu':
            x = F.relu(x)
        else:
            raise ValueError(f'Unknown activation: {self.activation}')
        return self.out(x).flatten()


@dataclass
class Calibration:
    net: nn.Module
    scaler: StandardScaler
    target_mean: float
    target_std: float
    activation: str
    label: str

    def predict(self, x, batch_size=8192):
        values = np.asarray(x, dtype=float)
        if len(values) == 0:
            return np.empty(0)
        a = self.scaler.transform(values).astype('float32')
        out = []
        self.net.eval()
        with torch.no_grad():
            for i in range(0, len(a), batch_size):
                y = self.net(torch.from_numpy(a[i:i + batch_size]))
                out.append(y.cpu().numpy().astype('float64'))
        return np.concatenate(out) * self.target_std + self.target_mean

    def clone(self, label):
        n = SmallNet(self.activation)
        n.load_state_dict(copy.deepcopy(self.net.state_dict()))
        return Calibration(n, self.scaler, self.target_mean,
                           self.target_std, self.activation, label)


def transform_tensors(model, table):
    xx = model.scaler.transform(table[FEATURES].to_numpy(float)).astype('float32')
    return torch.from_numpy(xx)


def mandria_scaler(train, activation):
    sx = StandardScaler().fit(train[FEATURES].to_numpy(float))
    y = train['target'].to_numpy(float)
    mean, std = float(y.mean()), float(y.std())
    if std < 1e-10:
        raise ValueError('Mandria training reference has zero variance.')
    return Calibration(SmallNet(activation), sx, mean, std, activation, 'A')


def train_model_A(splits, activation):
    """Mandria-only model: same optimizer, learning rate, split, and early stop."""
    set_seed(SEED)
    tr, va = splits['train'], splits['validation']
    model = mandria_scaler(tr, activation)
    a, av = transform_tensors(model, tr), transform_tensors(model, va)
    y = torch.as_tensor(((tr.target.to_numpy(float) - model.target_mean)
                         / model.target_std).astype('float32'))
    yv = torch.as_tensor(((va.target.to_numpy(float) - model.target_mean)
                          / model.target_std).astype('float32'))
    optim = torch.optim.Adam(model.net.parameters(), lr=0.001)
    rnd = torch.Generator().manual_seed(SEED)
    best = None
    best_val = float('inf')
    best_epoch, stale = 0, 0
    for epoch in range(1, A_EPOCHS + 1):
        model.net.train()
        for indices in torch.randperm(len(a), generator=rnd).split(512):
            optim.zero_grad()
            loss = F.mse_loss(model.net(a[indices]), y[indices])
            loss.backward()
            optim.step()
        model.net.eval()
        with torch.no_grad():
            val_loss = float(F.mse_loss(model.net(av), yv))
        if val_loss < best_val - 1e-6:
            best_val, best_epoch, stale = val_loss, epoch, 0
            best = copy.deepcopy(model.net.state_dict())
        else:
            stale += 1
            if stale >= 16:
                break
    model.net.load_state_dict(best)
    model.net.eval()
    return model, best_epoch


def get_hourly_reference(pollutant):
    if MANDRIA_GAS_REFERENCE_UNIT != 'ppb':
        raise ValueError('This comparison requires Mandria target units confirmed as ppb. '
                         'Check MANDRIA_GAS_REFERENCE_UNIT and conversion before training.')
    out = {}
    for end_hour, ug in loth.STATION_HOURLY[pollutant].items():
        if not 15 <= end_hour <= 20:  # skip partial initial 13:25-14:00 interval
            continue
        endpoint = pd.Timestamp(f'{loth.MEASUREMENT_DATE} {end_hour:02d}:00', tz=loth.LOCAL_TZ)
        ppb = float(loth.ugm3_to_ppb(ug, pollutant,
                                    loth.LFU_REFERENCE_T_C,
                                    loth.LFU_REFERENCE_PRESSURE_HPA))
        out[endpoint] = {'station_ug_m3': float(ug), 'station_ppb': ppb}
    return out


def select_winter_hours(frame, pollutant):
    reference = get_hourly_reference(pollutant)
    result = []
    for local_end, ref in reference.items():
        utc_start = (local_end - pd.Timedelta(hours=1)).tz_convert('UTC')
        utc_end = local_end.tz_convert('UTC')
        period = frame.loc[(frame.index >= utc_start) & (frame.index < utc_end)]
        if any(c not in period.columns for c in FEATURES):
            missing = [c for c in FEATURES if c not in period]
            raise ValueError(f'Missing winter input columns: {missing}')
        ok = np.isfinite(period[FEATURES].to_numpy(float)).all(axis=1)
        valid = period.loc[ok]
        coverage = len(valid) / 3600.0
        if coverage < MIN_FIELD_COVERAGE:
            log(f'[COVERAGE] {pollutant} {local_end:%H:%M}: excluded '
                f'({len(valid)}/3600 seconds = {coverage:.1%})')
            continue
        result.append({'end': local_end, 'x_full': valid[FEATURES].to_numpy(float),
                       'n_seconds': len(valid), 'coverage': coverage,
                       **ref})
    return result


def subsample_hours(hourlist, base_model, seed=SEED):
    """Deterministic sub-sampling WITHIN each hour for efficient weak labels."""
    rnd = np.random.default_rng(seed)
    groups = []
    for hr in hourlist:
        x = hr['x_full']
        count = min(len(x), TRAIN_SAMPLES_PER_WINTER_HOUR)
        chosen = np.sort(rnd.choice(len(x), size=count, replace=False))
        scaled = base_model.scaler.transform(x[chosen]).astype('float32')
        label_normalized = np.float32((hr['station_ppb'] - base_model.target_mean)
                                       / base_model.target_std)
        groups.append((torch.from_numpy(scaled), torch.tensor(label_normalized)))
    return groups


def winter_hourly_loss(net, groups):
    if not groups:
        raise ValueError('No winter hours available for hourly supervision')
    return torch.stack([(net(x).mean() - label).square() for x, label in groups]).mean()


def train_model_B(base, hourlist):
    """Fine-tune last layer; optimizer only sees means of hourly predictions."""
    set_seed(SEED + 10)
    result = base.clone('B')
    for p in result.net.hid.parameters():
        p.requires_grad_(False)
    start = [p.detach().clone() for p in result.net.out.parameters()]
    optim = torch.optim.Adam(result.net.out.parameters(), lr=B_LR)
    groups = subsample_hours(hourlist, result, seed=SEED + 11)
    for _ in range(B_EPOCHS):
        result.net.train()
        optim.zero_grad()
        hour_loss = winter_hourly_loss(result.net, groups)
        penalty = sum((p - initial).square().sum() for p, initial in
                      zip(result.net.out.parameters(), start))
        loss = hour_loss + B_ANCHOR_LAMBDA * penalty
        loss.backward()
        optim.step()
    for p in result.net.hid.parameters():
        p.requires_grad_(True)
    result.net.eval()
    return result


def train_model_C(splits, hours, base):
    """New network from random initialization: Mandria + winter hour loss."""
    set_seed(SEED + 20)
    model = Calibration(SmallNet(base.activation), base.scaler, base.target_mean,
                        base.target_std, base.activation, 'C')
    train = splits['train']
    x = transform_tensors(model, train)
    y = torch.from_numpy(((train.target.to_numpy(float) - model.target_mean)
                          / model.target_std).astype('float32'))
    groups = subsample_hours(hours, model, seed=SEED + 21)
    optim = torch.optim.Adam(model.net.parameters(), lr=C_LR)
    rand = torch.Generator().manual_seed(SEED + 20)
    for epoch in range(C_EPOCHS):
        model.net.train()
        permutation = torch.randperm(len(x), generator=rand)
        # Original Mandria regression pairs remain the dominant training set;
        # repeated group-mean losses bring the distinct winter label information.
        for idx in permutation.split(512):
            optim.zero_grad()
            loss_m = F.mse_loss(model.net(x[idx]), y[idx])
            loss_w = winter_hourly_loss(model.net, groups)
            loss = loss_m + C_WINTER_LOSS_WEIGHT * loss_w
            loss.backward()
            optim.step()
    model.net.eval()
    return model


def compute_metrics(y, yhat):
    y = np.asarray(y, float); p = np.asarray(yhat, float)
    good = np.isfinite(y) & np.isfinite(p)
    y, p = y[good], p[good]
    if len(y) == 0:
        return {'n': 0, 'rmse': np.nan, 'mae': np.nan, 'bias': np.nan,
                'pearson_r': np.nan, 'r2': np.nan}
    return {'n': int(len(y)),
            'rmse': float(np.sqrt(np.mean((p-y)**2))),
            'mae': float(np.mean(np.abs(p-y))),
            'bias': float(np.mean(p-y)),
            'pearson_r': float(np.corrcoef(y,p)[0,1]) if len(y)>2 and
                np.std(y)>1e-9 and np.std(p)>1e-9 else np.nan,
            'r2': float(r2_score(y,p)) if len(y)>1 else np.nan}


def save_weights(model, outpath, source, hours):
    outpath.parent.mkdir(exist_ok=True, parents=True)
    torch.save(model.net.state_dict(), outpath)
    meta = {'instrument': source[0], 'pollutant': source[1],
            'architecture': 'Linear(5,8) + ' + model.activation + ' + Linear(8,1)',
            'model': model.label, 'inputs_order': FEATURES,
            'input_mean': model.scaler.mean_.tolist(),
            'input_scale': model.scaler.scale_.tolist(),
            'target_mean': model.target_mean, 'target_std': model.target_std,
            'training_winter_hours': [str(h['end']) for h in hours],
            'weights_file': outpath.name, 'torch_version': torch.__version__,
            'reference_unit': 'ppb (must be verified against Mandria source)' }
    outpath.with_suffix('.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')


def model_predictions_for_hour(model, hour):
    p = model.predict(hour['x_full'])
    return float(p.mean()), float(p.std(ddof=1)) if len(p)>1 else np.nan, int((p < 0).sum())


def plot_hourly(rows, instrument, pollutant, activation, destination):
    data = pd.DataFrame(rows)
    if data.empty:
        return
    fig, ax = plt.subplots(figsize=(10.5, 5.6))
    hours = sorted(data['hour_ending_local'].unique())
    ref = data.drop_duplicates('hour_ending_local').set_index('hour_ending_local')
    ax.plot(pd.to_datetime(hours), ref.loc[hours, 'station_ppb'].to_numpy(),
            'ks--', lw=1.7, label='Official Lothstrasse station (ppb)')
    for m in ('A', 'B', 'C'):
        d = data[data['model'] == m].sort_values('hour_ending_local')
        if d.empty: continue
        metrics = compute_metrics(d['station_ppb'], d['predicted_hourly_mean_ppb'])
        ax.errorbar(pd.to_datetime(d['hour_ending_local']), d['predicted_hourly_mean_ppb'],
                    yerr=d['within_hour_sd_ppb'], marker='o', capsize=2.5, lw=1.25,
                    label=f'{m} | LOHO RMSE={metrics["rmse"]:.2f} ppb')
    ax.set_title(f'{instrument} – {pollutant} NN {activation.upper()}: A vs B vs C')
    ax.set_xlabel('Local hour ending (Europe/Berlin, CET)')
    ax.set_ylabel('Concentration (ppb)')
    ax.grid(alpha=0.2)
    ax.legend(fontsize=8, loc='best')
    ax.tick_params(axis='x', rotation=30)
    fig.text(0.01, 0.01,
             'A: Mandria only; B: last-layer fine-tuning; C: joint training. '
             'B/C predictions are leave-one-hour-out. Error bars: within-hour sensor variability, '
             'NOT instrument uncertainty. Station has no error bars.', fontsize=7.5)
    fig.tight_layout(rect=(0, 0.04, 1, 1))
    fig.savefig(destination, dpi=170)
    plt.close(fig)


def plot_summary(metrics, out):
    if metrics.empty:
        return
    for pollutant, d in metrics.groupby('pollutant'):
        fig, ax = plt.subplots(figsize=(10.5, 5.6))
        names = sorted(d['instrument_model'].unique())
        xs = np.arange(len(names))
        width = 0.26
        for i, m in enumerate(('A','B','C')):
            lookup = d[d['model']==m].set_index('instrument_model')['rmse']
            vals = [lookup.get(k, np.nan) for k in names]
            ax.bar(xs + (i-1)*width, vals, width, label=m)
        ax.set_xticks(xs)
        ax.set_xticklabels(names, rotation=25, ha='right')
        ax.set_ylabel('Leave-one-hour-out RMSE (ppb)')
        ax.set_title(f'{pollutant}: hourly reference comparison across models')
        ax.grid(axis='y', alpha=0.2)
        ax.legend()
        fig.tight_layout()
        fig.savefig(out / f'{pollutant}_ABC_LOHO_RMSE.png', dpi=170)
        plt.close(fig)


def save_excel_tables(destination, tables):
    """Convenience workbook; CSVs remain the canonical machine-readable files."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.utils import get_column_letter
    except ImportError:
        log('[INFO] openpyxl missing: skipping Excel workbook, CSV files are available.')
        return
    wb = Workbook()
    wb.remove(wb.active)
    for name, df in tables.items():
        ws = wb.create_sheet(name[:31])
        cols = list(df.columns)
        ws.append(cols)
        for row in df.itertuples(index=False, name=None):
            ws.append([str(v) if isinstance(v, (pd.Timestamp, np.datetime64)) else
                       (None if pd.isna(v) else v) for v in row])
        ws.freeze_panes = 'A2'
        ws.auto_filter.ref = ws.dimensions
        for cell in ws[1]:
            cell.fill = PatternFill('solid', fgColor='203A53')
            cell.font = Font(color='FFFFFF', bold=True)
            cell.alignment = Alignment(wrap_text=True)
        ws.row_dimensions[1].height = 33
        for j, col in enumerate(cols, 1):
            width = min(42, max(13, len(str(col)) + 2))
            ws.column_dimensions[get_column_letter(j)].width = width
    wb.save(destination)


def main():
    set_seed(SEED)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    (OUTPUT_DIR / 'plots').mkdir(exist_ok=True)
    (OUTPUT_DIR / 'weights').mkdir(exist_ok=True)
    (OUTPUT_DIR / 'calibrated_1s_final').mkdir(exist_ok=True)

    log('[INPUT] Reading original Mandria calibration data...')
    sources = loth.discover_mandria_sources(cal)
    mandria = {k: cal.read_sensor_binned(sources[k]) for k in loth.INSTRUMENTS}
    mandria = cal.attach_meteo(mandria)
    ref = cal.read_reference_gases(sources['thermo_reference'])

    log('[INPUT] Reading Lothstrasse November raw data...')
    field_sources = loth.discover_field_sources(cal)
    field = {k: loth.read_field_second(src, cal) for k, src in field_sources.items()}
    field = loth.transfer_colocated_meteo(field)

    # Provenance: record exact input files, including ZIP member names.
    paths = [loth.ORIGINAL_RAW_ZIP]
    paths.extend(src.archive if src.archive is not None else Path(src.member)
                 for src in sources.values())
    unique_paths = sorted({str(p) for p in paths if Path(p).is_file()})
    input_manifest = [{'path': p, 'sha256': source_fingerprint(Path(p))}
                      for p in unique_paths]
    (OUTPUT_DIR / 'input_file_manifest.json').write_text(
        json.dumps(input_manifest, indent=2), encoding='utf-8')

    hourly_rows, mandria_rows, summary_rows, final_fit_rows = [], [], [], []
    fold_diagnostics=[]
    total_started = time.time()
    for instrument in INSTRUMENTS:
        for pol, activations in MODELS.items():
            mandria_table, coverage = cal.usable_gas_days(mandria[instrument], ref, pol, instrument)
            if mandria_table.empty:
                raise RuntimeError(f'No paired original Mandria data: {instrument} {pol}')
            splits = cal.chronological_day_split(mandria_table)
            winter = select_winter_hours(field[instrument], pol)
            if len(winter) < MIN_WINTER_HOURS:
                log(f'[SKIP] {instrument}/{pol}: only {len(winter)} sufficiently covered '
                    'winter hours; cannot safely compare A/B/C.')
                continue
            for act in activations:
                label = f'{instrument}_{pol}_{act}'
                log(f'[MODEL] {label}: {len(winter)} eligible winter reference hours')
                A, best_epoch = train_model_A(splits, act)
                # A remains constant throughout the winter evaluation.
                for hold in range(len(winter)):
                    trainhours = winter[:hold] + winter[hold+1:]
                    leftout = winter[hold]
                    B = train_model_B(A, trainhours)
                    C = train_model_C(splits, trainhours, A)
                    fold_diagnostics.append({
                        'instrument': instrument, 'pollutant': pol, 'activation':act,
                        'held_out_hour': str(leftout['end']),
                        'fit_hours': '; '.join(str(h['end']) for h in trainhours),
                        'A_mandria_best_epoch': best_epoch,
                        'B_epochs': B_EPOCHS, 'C_epochs': C_EPOCHS})
                    for variant, model in [('A', A), ('B', B), ('C', C)]:
                        avg, sd, nneg = model_predictions_for_hour(model, leftout)
                        hourly_rows.append({
                            'instrument': instrument, 'pollutant': pol,
                            'activation': act, 'instrument_model': label,
                            'model': variant,
                            'hour_ending_local': leftout['end'].strftime('%Y-%m-%d %H:%M'),
                            'station_ug_m3': leftout['station_ug_m3'],
                            'station_ppb': leftout['station_ppb'],
                            'predicted_hourly_mean_ppb': avg,
                            'within_hour_sd_ppb': sd,
                            'n_valid_seconds': leftout['n_seconds'],
                            'coverage_percent': leftout['coverage']*100,
                            'negative_predictions_seconds': nneg,
                            'held_out_hour_used_in_fit': False,
                            'is_out_of_sample_winter': True,
                            'prediction_error_ppb': avg - leftout['station_ppb']})
                    log(f'  [LOHO] Held out {leftout["end"]:%H:%M} completed')
                # Out-of-sample Mandria TEST and winter-fitted models.
                # Final B/C models are fitted on ALL winter hours solely to
                # provide an exploratory calibrated series for subsequent use.
                final_models = {'A': A,
                                'B': train_model_B(A, winter),
                                'C': train_model_C(splits, winter, A)}
                for variant, model in final_models.items():
                    y_true = splits['test'].target.to_numpy(float)
                    y_pred = model.predict(splits['test'][FEATURES].to_numpy(float))
                    mandria_rows.append({'instrument': instrument,'pollutant':pol,
                                         'activation':act,'model':variant,
                                         'split':'Mandria held-out test days',
                                         **compute_metrics(y_true, y_pred)})
                    save_weights(model, OUTPUT_DIR / 'weights' / f'{label}_{variant}.pt',
                                 (instrument, pol), [] if variant=='A' else winter)
                    if MAKE_ALL_SECOND_OUTPUTS:
                        input_frame = field[instrument][FEATURES]
                        valid = np.isfinite(input_frame.to_numpy(float)).all(axis=1)
                        values = np.full(len(input_frame), np.nan)
                        if valid.any():
                            values[valid] = model.predict(input_frame.loc[valid].to_numpy(float))
                        fpath = OUTPUT_DIR / 'calibrated_1s_final' / f'{label}_{variant}.csv'
                        df = pd.DataFrame({'time_utc': input_frame.index.astype(str),
                                           'time_local': input_frame.index.tz_convert(loth.LOCAL_TZ).astype(str),
                                           'prediction_ppb': values})
                        df.to_csv(fpath, index=False)
                    for hour in winter:
                        mean, sd, neg = model_predictions_for_hour(model, hour)
                        final_fit_rows.append({'instrument':instrument,'pollutant':pol,
                            'activation':act,'model':variant,
                            'hour_ending_local':str(hour['end']),
                            'station_ppb':hour['station_ppb'],
                            'predicted_hourly_mean_ppb':mean,
                            'negative_predictions_seconds':neg,
                            'WARNING':'In-sample winter fit for B/C; not independent validation'})
                log(f'[DONE] {label}')

    out_hours = pd.DataFrame(hourly_rows)
    if out_hours.empty:
        raise RuntimeError('No evaluation rows; verify weather, sensor coverage, and reference hours.')
    for (inst, pol, activation), chunk in out_hours.groupby(['instrument','pollutant','activation']):
        plot_hourly(chunk.to_dict('records'), inst, pol, activation,
                    OUTPUT_DIR / 'plots' / f'{inst}_{pol}_{activation}_ABC.png')
        for variant, subset in chunk.groupby('model'):
            d = compute_metrics(subset.station_ppb, subset.predicted_hourly_mean_ppb)
            summary_rows.append({'instrument':inst,'pollutant':pol,
                                 'activation':activation, 'instrument_model':f'{inst}_{pol}_{activation}',
                                 'model':variant, 'evaluation':'winter LOHO 1 held-out hour per fold',
                                 **d})
    summary = pd.DataFrame(summary_rows)
    plot_summary(summary, OUTPUT_DIR / 'plots')
    out_hours.to_csv(OUTPUT_DIR / 'winter_leave_one_hour_out_predictions.csv', index=False)
    summary.to_csv(OUTPUT_DIR / 'model_ABC_winter_LOHO_metrics.csv', index=False)
    pd.DataFrame(mandria_rows).to_csv(OUTPUT_DIR / 'mandria_held_out_test_metrics.csv', index=False)
    pd.DataFrame(final_fit_rows).to_csv(OUTPUT_DIR / 'full_winter_fit_predictions_NOT_test.csv', index=False)
    pd.DataFrame(fold_diagnostics).to_csv(OUTPUT_DIR / 'fold_training_provenance.csv', index=False)

    best = summary.loc[summary.groupby(['instrument','pollutant','activation'])['rmse'].idxmin()]
    best.to_csv(OUTPUT_DIR / 'provisional_best_models_LOHO.csv', index=False)
    save_excel_tables(OUTPUT_DIR / 'ABC_model_comparison.xlsx', {
        'Winter LOHO Metrics': summary,
        'Held-Out Hours': out_hours,
        'Mandria Test': pd.DataFrame(mandria_rows),
        'Final In Sample': pd.DataFrame(final_fit_rows),
        'Provisional Ranking': best
    })
    parameters = {'seed':SEED,'A_epochs_max':A_EPOCHS,'B_epochs':B_EPOCHS,
                  'C_epochs':C_EPOCHS,'B_learning_rate':B_LR,'C_learning_rate':C_LR,
                  'B_last_layer_only':True,'B_anchor_lambda':B_ANCHOR_LAMBDA,
                  'C_winter_hour_loss_weight':C_WINTER_LOSS_WEIGHT,
                  'C_new_random_initialization':True,
                  'min_coverage':MIN_FIELD_COVERAGE,
                  'train_samples_per_winter_hour':TRAIN_SAMPLES_PER_WINTER_HOUR,
                  'reference_ugm3_to_ppb':'LfU gas reporting conditions 20C and 1013hPa',
                  'Mandria_reference_units_assumed':MANDRIA_GAS_REFERENCE_UNIT,
                  'instrument_specific_models':True,
                  'evaluation':'leave-one-winter-hour-out; 1 day only',
                  'not_independent_validation':'All hours from one winter day. The hourly results cannot establish generalization to other winter days.',
                  'weather_note':'No LMU weather is needed for this model A/B/C exercise; T and RH are from the device / colocated donor.',
                  'elapsed_seconds':round(time.time()-total_started, 1),
                  'packages':{'torch':torch.__version__, 'pandas':pd.__version__, 'numpy':np.__version__}}
    (OUTPUT_DIR / 'run_settings.json').write_text(json.dumps(parameters, indent=2), encoding='utf-8')
    log('\n[RESULTS] A/B/C model comparison complete.')
    log(summary[['instrument','pollutant','activation','model','n','rmse','mae','bias']].to_string(index=False))
    log(f'\n[OUTPUT] {OUTPUT_DIR}')
    log('[CAUTION] Winter LOHO is internal same-day cross-validation, NOT proof of winter generalization.')

if __name__ == '__main__':
    main()
