#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Lothstrasse winter co-location, 14 Nov 2026: RMSE and aligned two-panel plots.

Input files:
 - Raw_data.zip (or extracted Raw_data folder): gas_drone, ground_basic,
   ground_screen, opc_drone
 - Original Mandria reference files for fitting (not the Lothstrasse data)
 - Dokumentation.docx, pages 14-16: manually transcribed published station values
 - LMU MIM01 weather: measured 30 m air temperature and station pressure
 - LfU reference conditions: 20 Celsius and 1013 hPa for official mass values
 - No station measurement-uncertainty estimates are assumed or plotted

Station hourly label H denotes measurements in [H-1, H), Munich local time.
Output CSVs, English-language plots and source/methodology metadata.

Run in Spyder using F5 after placing this script and calibration_paris_english.py
in C:/Users/xy-84/Desktop/Master/Thesis/Background_Data_Paris/Calibration Lothstrasse

Dependency: pandas numpy scipy matplotlib scikit-learn torch xlrd openpyxl requests
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import zipfile
import warnings
from datetime import date
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# --------------------------------------------------------------------------
# CONFIGURATION: edit these paths only if you use different directories.
# --------------------------------------------------------------------------
DATA_ROOT = Path(os.getenv("LOTH_DATA_ROOT", r"C:\Users\xy-84\Desktop\Master\Thesis\Background_Data_Paris"))
FIELD_ROOT = DATA_ROOT / "Calibration Lothstrasse"
ORIGINAL_RAW_ZIP = FIELD_ROOT / "Raw_data.zip"
OUTPUT = FIELD_ROOT / "results_hourly_lothstrasse"

# Optional explicit path to the ORIGINAL MANDRIA CALIBRATION ZIP, not Raw_data.zip!
# Example: MANDRIA_ZIP = DATA_ROOT / "Mandria_original_data.zip"
MANDRIA_ZIP = Path(os.environ["MANDRIA_CALIBRATION_ZIP"]) if os.getenv("MANDRIA_CALIBRATION_ZIP") else None

LOCAL_TZ = "Europe/Berlin"
MEASUREMENT_DATE = "2026-11-14"
START_LOCAL = "2026-11-14 13:25:00"
END_LOCAL = "2026-11-14 20:05:00"  # exclusive
MIN_HOURLY_COVERAGE = 0.90  # >= 90% of ALL 3600 seconds, NOT just measured window
NN_EPOCHS = int(os.getenv("LOTH_EPOCHS", "100"))
SEED = 42

# Confirm original Mandria gas reference units before publication. Gas NN predictions
# have the SAME units as the reference data used for training; do NOT blindly convert
# them a second time. The existing Mandria workflow used ppb as its working assumption.
GAS_REFERENCE_UNITS = {"NO2": "ppb", "O3": "ppb"}
MOLAR_MASS_G_MOL = {"NO2": 46.0055, "O3": 47.9982, "CO": 28.0101}
IDEAL_GAS_R = 8.314462618  # J mol-1 K-1
MIN_WEATHER_COVERAGE = 0.90

# Station gas concentrations are published in mass units at LfU reference
# conditions (20 deg C, 1013 hPa). Use them for the official comparison.
# Keep the earlier, weather-dependent conversion only as a sensitivity analysis.
STATION_GAS_CONVERSION_MODE = "lfu_reference"  # or "lmu_weather_exploratory"
LFU_REFERENCE_T_C = 20.0
LFU_REFERENCE_PRESSURE_HPA = 1013.0

LFU_STATION_SOURCE = "https://www.lfu.bayern.de/luft/immissionsmessungen/doc/lueb_dokumentation/aktiv/01_Oberbayern/10_muenchen_lothstrasse.pdf"
LFU_ARCHIVE_SOURCE = "https://www.lfu.bayern.de/luft/immissionsmessungen/messwertarchiv/doc/wichtige_hinweise_zu_den_daten.pdf"
# Weather supplied by LMU MIM01 at Theresienstrasse 37, NOT by the official
# environmental station at Lothstrasse. Use measured station pressure, not
# sea-level-reduced pressure, and the preferred 30 m temperature.
WEATHER_CSV = Path(os.environ["LOTH_WEATHER_CSV"]) if os.getenv("LOTH_WEATHER_CSV") else None
AUTO_DOWNLOAD_WEATHER = True  # only if no weather CSV was found
REQUIRE_LMU_2M = True  # do not silently omit the requested 2m station curve

GAS_INSTRUMENTS = ("gas_drone", "ground_basic", "ground_screen")
PM_INSTRUMENTS = ("ground_basic", "ground_screen", "opc_drone")
INSTRUMENTS = ("gas_drone", "ground_basic", "ground_screen", "opc_drone")
GAS_MODELS = {"NO2": ("NN_tanh_without_pressure",),
              "O3": ("NN_gelu_without_pressure", "NN_tanh_without_pressure")}
PM_MODELS = {"PM2_5": ("LR", "MLR_RH")}
GAS_INPUTS = ("CO_raw", "NO2_raw", "O3_raw", "T", "RH")

# Meteorological sensors located side by side, as confirmed by operator.
# The SAME meteorological provenance is used in training and application.
METEO_PROVIDER = {"ground_screen": "ground_basic", "opc_drone": "gas_drone"}

# ORIGINAL STATION TABLES transcribed from Dokumentation.docx screenshots:
# p14 NO2, p15 PM2.5, p16 O3, all in ug/m3. 20:00 on p15 is NOT shown!
# Keys are the reported END-OF-HOUR labels (e.g. 20:00 = 19:00-20:00).
STATION_HOURLY = {
    "NO2": {14: 7, 15: 8, 16: 9, 17: 13, 18: 19, 19: 20, 20: 23},
    "PM2_5": {14: 3, 15: 4, 16: 5, 17: 8, 18: 11, 19: 14},
    "O3": {14: 60, 15: 59, 16: 53, 17: 45, 18: 36, 19: 35, 20: 32},
}
STATION_PAGES = {"NO2": 14, "PM2_5": 15, "O3": 16}


def log(*args):
    print(*args, flush=True)


def resolve_cal_module():
    """Import the companion calibration code even when Spyder uses another cwd."""
    home = Path(__file__).resolve().parent
    if str(home) not in sys.path:
        sys.path.insert(0, str(home))
    try:
        import calibration_paris_english as cal
    except ImportError as e:
        raise FileNotFoundError(
            "Required companion file calibration_paris_english.py was not found "
            f"beside {Path(__file__).name}. Put both scripts in the same folder."
        ) from e
    return cal


def discover_field_sources(cal):
    """Pick raw November data from Lothstrasse only; ZIP or extracted files."""
    found = {}
    if ORIGINAL_RAW_ZIP.is_file():
        with zipfile.ZipFile(ORIGINAL_RAW_ZIP) as z:
            for member in z.namelist():
                kind = cal.classify(member)
                if kind in INSTRUMENTS:
                    if kind in found:
                        raise RuntimeError(f"Duplicate instrument {kind} in {ORIGINAL_RAW_ZIP}")
                    found[kind] = cal.Source(member, ORIGINAL_RAW_ZIP)
    else:
        for base in (FIELD_ROOT / "Raw_data", FIELD_ROOT):
            if not base.is_dir():
                continue
            for path in base.iterdir():
                if path.is_file():
                    kind = cal.classify(path.name)
                    if kind in INSTRUMENTS and kind not in found:
                        found[kind] = cal.Source(str(path))
    missing = set(INSTRUMENTS) - set(found)
    if missing:
        raise FileNotFoundError("Lothstrasse raw CSV files missing: " + ", ".join(sorted(missing))
                                + f". Expected ZIP at {ORIGINAL_RAW_ZIP} or Raw_data directory")
    return found


def discover_mandria_sources(cal):
    """Only select a complete original calibration archive or unambiguous extracted files.

    CRITICAL: never train on data from the Lothstrasse campaign or Graz campaign.
    """
    required = set(INSTRUMENTS) | {"thermo_reference", "pm_reference"}
    if MANDRIA_ZIP is not None:
        archives = [MANDRIA_ZIP]
    else:
        archives = [p for p in DATA_ROOT.rglob("*.zip")
                    if not any(k in str(p.parent).lower() for k in
                               ("calibration lothstrasse", "graz campaign", "results_"))]
    complete = []
    for path in archives:
        if not path.is_file():
            continue
        try:
            with zipfile.ZipFile(path) as z:
                names = {cal.classify(member): member for member in z.namelist()
                         if cal.classify(member) in required}
        except zipfile.BadZipFile:
            continue
        if required.issubset(names):
            complete.append((path, names))
    if len(complete) == 1:
        p, names = complete[0]
        log(f"[CALIBRATION] Original Mandria archive: {p}")
        return {k: cal.Source(names[k], p) for k in required}
    if len(complete) > 1:
        raise RuntimeError("Multiple candidate Mandria archives found: "
                           + "; ".join(str(p) for p, _ in complete)
                           + ". Set MANDRIA_CALIBRATION_ZIP explicitly.")
    if MANDRIA_ZIP is not None:
        raise FileNotFoundError(f"Explicit Mandria ZIP does not contain all {sorted(required)}: {MANDRIA_ZIP}")

    # Fallback: uniquely named extracted ORIGINAL files outside campaigns.
    files = {k: [] for k in required}
    for p in DATA_ROOT.rglob("*"):
        if not p.is_file() or p.suffix.lower() not in (".csv", ".xls", ".xlsx"):
            continue
        if any(k in str(p.parent).lower() for k in
               ("calibration lothstrasse", "graz campaign", "results_", "test_")):
            continue
        k = cal.classify(p.name)
        if k in files:
            files[k].append(p)
    if not all(len(v) == 1 for v in files.values()):
        detail = "; ".join(f"{k}: {len(v)} matches" for k, v in files.items())
        raise FileNotFoundError(
            "Original Mandria calibration sources not uniquely found: " + detail + ". "
            "Place the original archive under Background_Data_Paris and set "
            "MANDRIA_CALIBRATION_ZIP near the top of this script. NEVER use Raw_data.zip "
            "from Lothstrasse as calibration training data."
        )
    log("[CALIBRATION] Using uniquely identifiable extracted Mandria sources")
    return {k: cal.Source(str(v[0])) for k, v in files.items()}


def read_field_second(src, cal):
    """Load raw data, require real 2026-11-14 GPS/UTC timestamps.

    Drop early GPS initialization glitches; duplicate UTC seconds are averaged,
    missing observations remain missing (no invented interpolation).
    """
    with src.open() as handle:
        raw = pd.read_csv(handle, encoding="utf-8-sig", low_memory=False)
    raw.columns = raw.columns.str.strip()
    mandatory = {"gps_date", "gps_time_utc"}
    if not mandatory.issubset(raw):
        raise ValueError(f"Missing GPS UTC timestamp columns in {src.label()}")
    strings = raw["gps_date"].astype("string") + " " + raw["gps_time_utc"].astype("string")
    times = pd.to_datetime(strings, utc=True, errors="coerce", format="mixed")
    valid = times.dt.strftime("%Y-%m-%d").eq(MEASUREMENT_DATE).fillna(False)
    start = pd.Timestamp(START_LOCAL, tz=LOCAL_TZ).tz_convert("UTC")
    end = pd.Timestamp(END_LOCAL, tz=LOCAL_TZ).tz_convert("UTC")
    valid &= (times >= start) & (times < end)
    selected = raw.loc[valid].copy()
    times = times.loc[valid]
    if len(selected) == 0:
        raise ValueError(f"No real UTC measurements found within {START_LOCAL}–{END_LOCAL} in {src.label()}")
    idx = pd.DatetimeIndex(times, name="time_utc")
    data = pd.DataFrame(index=idx)
    for source, target in cal.RAW_MAP.items():
        if source in selected:
            data[target] = pd.to_numeric(selected[source].to_numpy(), errors="coerce")
    # Always preserve the original meteorology, even where co-located donors are used.
    data = data.rename(columns={"T": "measured_T", "RH": "measured_RH", "p": "measured_p"})
    for field in ("measured_T", "measured_RH", "measured_p"):
        if field in data:
            bounds = {"measured_T": (-40, 65), "measured_RH": (0, 100),
                      "measured_p": (870, 1085)}[field]
            data[field] = data[field].where(data[field].between(*bounds))
    for field in ("CO_raw", "NO2_raw", "PM2_5_raw", "PM10_raw"):
        if field in data:
            data[field] = data[field].where(data[field] >= 0)
    if "O3_raw" in data:
        data["O3_raw"] = data["O3_raw"].where(data["O3_raw"].between(1, 4094))
    if "sps30_ok" in selected:
        data["sps30_ok"] = pd.to_numeric(selected["sps30_ok"].to_numpy(), errors="coerce")
    # For input PM, values with an explicit not-OK SPS30 flag are invalid.
    if "sps30_ok" in data:
        data["PM2_5_raw"] = data["PM2_5_raw"].where(data["sps30_ok"] == 1)
    data = data.sort_index()
    if data.index.has_duplicates:
        dup = int(data.index.duplicated().sum())
        log(f"[INFO] {src.basename}: {dup} duplicate timestamps averaged")
        data = data.groupby(level=0).mean(numeric_only=True)
    # bin into exact UTC seconds; do not resample across missing seconds to create data.
    data = data.resample("1s").mean()
    data["T"] = data["measured_T"] if "measured_T" in data else np.nan
    data["RH"] = data["measured_RH"] if "measured_RH" in data else np.nan
    data["p"] = data["measured_p"] if "measured_p" in data else np.nan
    data.index.name = "time_utc"
    log(f"[FIELD] {src.basename}: {len(selected):,} selected rows, "
        f"{len(data):,} UTC-second bins, "
        f"{data.select_dtypes('number').notna().any(axis=1).sum():,} seconds with data")
    return data


def transfer_colocated_meteo(field):
    """Use meteo from same co-location groups as original Mandria calibration."""
    for target, donor in METEO_PROVIDER.items():
        for name in ("T", "RH", "p"):
            # The donor sensors log asynchronously. Nearest neighbor within 3s.
            provider = field[donor][[name]].dropna().sort_index()
            if provider.empty:
                raise ValueError(f"Missing donor {name}: {donor} -> {target}")
            dest = field[target].reset_index().sort_values("time_utc")
            source = provider.rename(columns={name: "donor_value"}).reset_index().sort_values("time_utc")
            matched = pd.merge_asof(dest[["time_utc"]], source,
                                    on="time_utc", direction="nearest", tolerance=pd.Timedelta(seconds=3))
            field[target][name] = matched["donor_value"].to_numpy()
        log(f"[METEO] {target} uses T, RH, p from co-located {donor}")
    return field


def load_station_reference():
    """Manual exact transcription of screenshots, not values derived from graph bars."""
    rows = []
    for pollutant, lookup in STATION_HOURLY.items():
        for hour, value in lookup.items():
            end = pd.Timestamp(f"{MEASUREMENT_DATE} {hour:02d}:00", tz=LOCAL_TZ)
            rows.append({"pollutant": pollutant, "interval_start_local": str(end - pd.Timedelta(hours=1)),
                         "interval_end_local": str(end), "hour_label_local": end.strftime("%Y-%m-%d %H:%M"),
                         "station_value_ug_m3": float(value),
                         "station_source_file": "Dokumentation.docx",
                         "station_source_page": STATION_PAGES[pollutant],
                         "hour_definition": "end-of-hour label; measurement interval [end-1h, end)"})
    return pd.DataFrame(rows).sort_values(["pollutant", "hour_label_local"]).reset_index(drop=True)


def ugm3_to_ppb(values, pollutant, temperature_c, pressure_hpa):
    """Ideal gas: ppb = (ug/m3)*1000*R*T_K/(M_gmol*p_Pa)."""
    c = np.asarray(values, dtype=float)
    t = np.asarray(temperature_c, dtype=float) + 273.15
    p_pa = np.asarray(pressure_hpa, dtype=float) * 100.0
    with np.errstate(invalid="ignore", divide="ignore"):
        factor = 1000 * IDEAL_GAS_R * t / (MOLAR_MASS_G_MOL[pollutant] * p_pa)
        out = c * factor
    return np.where(np.isfinite(p_pa) & (p_pa > 0) & (t > 0), out, np.nan)


def ugm3_to_ppm(values, pollutant, temperature_c, pressure_hpa):
    """Useful for CO when a mass-concentration reference is available."""
    return ugm3_to_ppb(values, pollutant, temperature_c, pressure_hpa) / 1000.0


def _weather_csv_candidates():
    if WEATHER_CSV is not None:
        return [WEATHER_CSV]
    candidate_dirs = (DATA_ROOT / "LMU_Weather", FIELD_ROOT / "LMU_Weather", FIELD_ROOT)
    matches = []
    for folder in candidate_dirs:
        if folder.is_dir():
            matches.extend(sorted(folder.glob("LMU_MIM01_all_weather_2026-11-14*.csv")))
            matches.extend(sorted(folder.glob("LMU_MIM01_weather_for_conversion.csv")))
    return list(dict.fromkeys(matches))


def _download_weather_using_original_module():
    """Download measured LMU 2m and 30m temperatures and station pressure.

    The source API is queried through the original user-supplied downloader.
    2m temperature may be affected by LMU's documented positive bias in 2026.
    """
    try:
        import requests
        import download_lmu_weather_all as lmu
    except ImportError as exc:
        raise RuntimeError(
            "Missing LMU weather data. Run download_lmu_weather_all.py first, "
            "or put it beside this script and install requests."
        ) from exc
    begin = pd.Timestamp(MEASUREMENT_DATE + " 13:00:00", tz=LOCAL_TZ).tz_convert("UTC")
    end = pd.Timestamp(END_LOCAL, tz=LOCAL_TZ).tz_convert("UTC")
    archive = OUTPUT / "lmumim01_original_api_json"
    archive.mkdir(parents=True, exist_ok=True)
    grid = pd.date_range(begin, end, freq="1min", tz="UTC")
    weather = pd.DataFrame(index=grid)
    errors = []
    with requests.Session() as session:
        for variable in ("air_temperature_2m", "air_temperature_30m", "air_pressure"):
            try:
                frame = lmu.fetch_one(session, variable, begin, end, archive)
                weather[variable] = frame[variable].reindex(grid)
                log(f"[LMU] Downloaded {variable}: {weather[variable].notna().sum()} minutes")
            except Exception as exc:
                weather[variable] = np.nan
                errors.append(f"{variable}: {type(exc).__name__}: {exc}")
    if errors:
        log("[LMU WARNING] " + "; ".join(errors))
    if not weather["air_temperature_30m"].notna().any() or not weather["air_pressure"].notna().any():
        raise RuntimeError("LMU 30m temperature or pressure unavailable. "
                           "Download the official CSV using download_lmu_weather_all.py.")
    press = weather["air_pressure"]
    if press.median() > 20000:
        press = press / 100.0
    out = pd.DataFrame({
        "time_utc": weather.index,
        "air_temperature_2m_C": lmu.temperature_c(weather["air_temperature_2m"]).to_numpy(),
        "air_temperature_30m_C": lmu.temperature_c(weather["air_temperature_30m"]).to_numpy(),
        "station_pressure_hPa": press.to_numpy(),
    })
    outpath = FIELD_ROOT / "LMU_MIM01_weather_for_conversion.csv"
    outpath.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(outpath, index=False)
    log(f"[LMU] Archived weather at {outpath}")
    return outpath


def load_weather_minute():
    """Load original LMU weather (2m, 30m, actual pressure) without interpolation."""
    paths = [p for p in _weather_csv_candidates() if p.is_file()]
    if not paths:
        if not AUTO_DOWNLOAD_WEATHER:
            raise FileNotFoundError("LMU weather CSV missing. Run download_lmu_weather_all.py first.")
        paths = [_download_weather_using_original_module()]
    errors = []
    for path in paths:
        try:
            raw = pd.read_csv(path, sep=None, engine="python", encoding="utf-8-sig")
            if not {"time_utc", "air_temperature_30m_C", "station_pressure_hPa"}.issubset(raw.columns):
                raise ValueError(f"Mandatory columns missing. Available: {raw.columns.tolist()}")
            timestamp = pd.to_datetime(raw["time_utc"].astype(str).str.replace(" UTC", "", regex=False),
                                       utc=True, errors="coerce")
            met = pd.DataFrame(index=pd.DatetimeIndex(timestamp, name="time_utc"))
            for level in ("2m", "30m"):
                col = f"air_temperature_{level}_C"
                if col in raw:
                    met[f"temperature_{level}_C"] = pd.to_numeric(raw[col].to_numpy(), errors="coerce")
                else:
                    met[f"temperature_{level}_C"] = np.nan
            met["pressure_hPa"] = pd.to_numeric(raw["station_pressure_hPa"].to_numpy(), errors="coerce")
            met = met.replace([np.inf, -np.inf], np.nan)
            for level in ("2m", "30m"):
                c = f"temperature_{level}_C"
                met[c] = met[c].where(met[c].between(-50, 60))
            met["pressure_hPa"] = met.pressure_hPa.where(met.pressure_hPa.between(700, 1100))
            met = met.loc[met.index.notna()].groupby(level=0).mean().sort_index().resample("1min").mean()
            # Legacy names retained for existing results and comparisons.
            met["temperature_C"] = met["temperature_30m_C"]
            for pol in ("NO2", "O3", "CO"):
                for level in ("2m", "30m"):
                    met[f"ppb_per_ugm3_{pol}_{level}"] = ugm3_to_ppb(
                        np.ones(len(met)), pol,
                        met[f"temperature_{level}_C"].to_numpy(),
                        met.pressure_hPa.to_numpy())
                met[f"ppb_per_ugm3_{pol}"] = met[f"ppb_per_ugm3_{pol}_30m"]
            if not (met.temperature_C.notna() & met.pressure_hPa.notna()).any():
                raise ValueError("No valid paired 30m temperature and station-pressure measurements")
            log(f"[LMU] Weather source: {path}")
            for level in ("2m", "30m"):
                valid = (met[f"temperature_{level}_C"].notna() & met.pressure_hPa.notna())
                log(f"[LMU] {level}: {int(valid.sum())} paired minutes")
            if not met["temperature_2m_C"].notna().any():
                if REQUIRE_LMU_2M:
                    raise ValueError("LMU 2m temperature is missing in the weather CSV. "
                        "Run download_lmu_weather_all.py again to obtain both 2m and 30m values, "
                        "or set REQUIRE_LMU_2M=False to allow incomplete plots.")
                log("[LMU WARNING] 2m temperature missing; the 2m scenario will not be plotted")
            return met, path
        except Exception as exc:
            errors.append(f"{path}: {exc}")
    raise RuntimeError("No valid LMU weather file: " + "; ".join(errors))


def make_hourly_weather(met):
    """Compute hourly mean T/p and mean conversion factor from valid minute values."""
    start = pd.Timestamp(START_LOCAL, tz=LOCAL_TZ)
    end = pd.Timestamp(END_LOCAL, tz=LOCAL_TZ)
    labels = pd.date_range(start.floor("h") + pd.Timedelta(hours=1),
                           end.ceil("h"), freq="h", tz=LOCAL_TZ)
    rows=[]
    for label in labels:
        lo, hi = (label - pd.Timedelta(hours=1)).tz_convert("UTC"), label.tz_convert("UTC")
        m = met.loc[(met.index >= lo) & (met.index < hi)]
        paired = m.dropna(subset=["temperature_C", "pressure_hPa"])
        n = len(paired)
        record = {"hour_label_local":label.strftime("%Y-%m-%d %H:%M"),
                  "weather_valid_minutes":n,"weather_coverage_pct_full_hour":100*n/60,
                  "weather_temperature_30m_C":float(paired.temperature_C.mean()) if n else np.nan,
                  "weather_station_pressure_hPa":float(paired.pressure_hPa.mean()) if n else np.nan,
                  "weather_conversion_valid": n >= 60*MIN_WEATHER_COVERAGE}
        for pol in ("NO2", "O3", "CO"):
            factor = float(paired[f"ppb_per_ugm3_{pol}"].mean()) if n else np.nan
            record[f"ppb_per_ugm3_{pol}"] = factor if record["weather_conversion_valid"] else np.nan
        rows.append(record)
    return pd.DataFrame(rows)


def add_station_converted_units(station, hourly_weather):
    """Convert gas mass values with documented LfU reference conditions.

    Keep the 30m LMU-weather conversion in separate columns for sensitivity
    analysis. No station uncertainty is estimated or plotted.
    """
    if STATION_GAS_CONVERSION_MODE not in ("lfu_reference", "lmu_weather_exploratory"):
        raise ValueError("Unsupported STATION_GAS_CONVERSION_MODE: " + STATION_GAS_CONVERSION_MODE)
    weather = hourly_weather.set_index("hour_label_local")
    rows=[]
    for _, rec in station.iterrows():
        d = rec.to_dict()
        w = weather.loc[rec.hour_label_local].to_dict() if rec.hour_label_local in weather.index else {}
        d.update(w)
        pol = rec.pollutant
        mass = float(rec.station_value_ug_m3)
        if pol in ("NO2", "O3"):
            f_lfu = float(ugm3_to_ppb(1.0, pol, LFU_REFERENCE_T_C, LFU_REFERENCE_PRESSURE_HPA))
            f_lmu = d.get(f"ppb_per_ugm3_{pol}", np.nan)
            d["station_hourly_mean_ppb_lfu_reference"] = mass * f_lfu
            d["station_hourly_mean_ppb_lmu_weather_exploratory"] = mass * f_lmu if np.isfinite(f_lmu) else np.nan
            selected_factor = f_lfu if STATION_GAS_CONVERSION_MODE == "lfu_reference" else f_lmu
            d["selected_ppb_per_ugm3"] = selected_factor
            d["station_hourly_mean_ppb"] = mass * selected_factor if np.isfinite(selected_factor) else np.nan
            d["station_hourly_mean_ppm"] = d["station_hourly_mean_ppb"] / 1000 if np.isfinite(d["station_hourly_mean_ppb"]) else np.nan
            d["comparison_conversion_mode"] = STATION_GAS_CONVERSION_MODE
            d["comparison_unit"] = "ppb"
        else:
            d["station_hourly_mean_ppb_lfu_reference"] = np.nan
            d["station_hourly_mean_ppb_lmu_weather_exploratory"] = np.nan
            d["selected_ppb_per_ugm3"] = np.nan
            d["station_hourly_mean_ppb"] = np.nan
            d["station_hourly_mean_ppm"] = np.nan
            d["comparison_conversion_mode"] = "mass_concentration_unchanged"
            d["comparison_unit"] = "ug/m3"
        # Official Lothstrasse screenshot values have no stated hourly
        # uncertainty. Do not invent one from EU data-quality objectives.
        d["station_actual_uncertainty_reported"] = False
        rows.append(d)
    return pd.DataFrame(rows)


def model_gas_mean_in_ppb(value, pollutant, hourly_factor):
    unit = GAS_REFERENCE_UNITS[pollutant]
    if unit == "ppb":
        return value
    if unit == "ppm":
        return value * 1000
    if unit == "ug/m3":
        return value * hourly_factor if np.isfinite(hourly_factor) else np.nan
    if unit == "unknown":
        return np.nan
    raise ValueError("Unsupported Mandria reference unit: " + str(unit))


def model_gas_values_in_ppb(series, pollutant, minute_weather):
    values = series.to_numpy(float)
    unit = GAS_REFERENCE_UNITS[pollutant]
    if unit == "ppb":
        return values
    if unit == "ppm":
        return 1000 * values
    if unit == "unknown":
        return np.full(len(values), np.nan)
    if unit == "ug/m3":
        if STATION_GAS_CONVERSION_MODE == "lfu_reference":
            factor = float(ugm3_to_ppb(1.0, pollutant, LFU_REFERENCE_T_C, LFU_REFERENCE_PRESSURE_HPA))
            return values * factor
        factor = minute_weather[f"ppb_per_ugm3_{pollutant}"].reindex(series.index.floor("min")).to_numpy()
        return values * factor
    raise ValueError("Unsupported Mandria reference unit: " + str(unit))


def train_models(cal, sources):
    """Train on ORIGINAL Mandria data only, with identical code & day splits."""
    origin = {k: cal.read_sensor_binned(sources[k]) for k in INSTRUMENTS}
    origin = cal.attach_meteo(origin)
    gas_ref = cal.read_reference_gases(sources["thermo_reference"])
    pm_ref = cal.read_reference_pm(sources["pm_reference"])
    models = {}
    metrics = []
    provenance = []
    for inst in INSTRUMENTS:
        if inst in GAS_INSTRUMENTS:
            for pol, methods in GAS_MODELS.items():
                table, cov = cal.usable_gas_days(origin[inst], gas_ref, pol, inst)
                if table.empty:
                    raise ValueError(f"No original calibration days for {inst}/{pol}")
                splits = cal.chronological_day_split(table)
                for method in methods:
                    features = list(GAS_INPUTS)
                    tr, va = splits["train"], splits["validation"]
                    predictor, notes = cal.build_neural(
                        tr[features].to_numpy(float), tr.target.to_numpy(float),
                        va[features].to_numpy(float), va.target.to_numpy(float),
                        activation=method.split("_")[1], epochs=NN_EPOCHS, seed=SEED)
                    models[(inst, pol, method)] = (predictor, features)
                    for phase, block in splits.items():
                        m = cal.statistics(block.target.to_numpy(float),
                                           predictor.predict(block[features].to_numpy(float)))
                        metrics.append({"instrument": inst, "pollutant": pol, "model": method,
                                        "split": phase, "parameters": notes, **m})
                    provenance.append({"instrument": inst, "pollutant": pol, "model": method,
                                       "features": features, "parameters": notes,
                                       "training_days": sorted(map(str, tr.day.unique())),
                                       "validation_days": sorted(map(str, va.day.unique())),
                                       "test_days": sorted(map(str, splits["test"].day.unique()))})
                    log(f"[TRAINED] {inst} | {pol} | {method}")
        if inst in PM_INSTRUMENTS:
            pol = "PM2_5"
            table, cov = cal.usable_pm_days(origin[inst], pm_ref, pol, inst)
            if table.empty:
                raise ValueError(f"No PM calibration days for {inst}/{pol}")
            splits = cal.chronological_day_split(table)
            for method in PM_MODELS[pol]:
                features = ["PM_raw"] if method == "LR" else ["PM_raw", "RH"]
                tr, va = splits["train"], splits["validation"]
                predictor, notes = cal.build_linear(method,
                    tr[features].to_numpy(float), tr.target.to_numpy(float),
                    va[features].to_numpy(float), va.target.to_numpy(float))
                models[(inst, pol, method)] = (predictor, features)
                for phase, block in splits.items():
                    m = cal.statistics(block.target.to_numpy(float),
                                       predictor.predict(block[features].to_numpy(float)))
                    metrics.append({"instrument": inst, "pollutant": pol, "model": method,
                                    "split": phase, "parameters": notes, **m})
                provenance.append({"instrument": inst, "pollutant": pol, "model": method,
                                   "features": features, "parameters": notes,
                                   "training_days": sorted(map(str, tr.day.unique())),
                                   "validation_days": sorted(map(str, va.day.unique())),
                                   "test_days": sorted(map(str, splits["test"].day.unique())),
                                   "PM_note": "daily-mean Mandria model applied to 1-second data (exploratory)"})
                log(f"[TRAINED] {inst} | PM2.5 | {method}")
    return models, pd.DataFrame(metrics), provenance


def predict_field(field, models):
    results = {}
    summaries = []
    for inst, data in field.items():
        out = data.copy()
        for (i, pol, method), (predictor, features) in models.items():
            if i != inst:
                continue
            mapped = out.rename(columns={"PM2_5_raw": "PM_raw"}) if pol == "PM2_5" else out
            if any(col not in mapped for col in features):
                raise ValueError(f"Missing {features} in field data for {inst}/{pol}")
            X = mapped[features].replace([np.inf, -np.inf], np.nan)
            valid = X.notna().all(axis=1)
            pred = np.full(len(out), np.nan, dtype=float)
            if valid.any():
                pred[valid.to_numpy()] = predictor.predict(X.loc[valid].to_numpy(float))
            col = f"{pol}__{method}"
            out[col] = pred
            summaries.append({"instrument": inst, "pollutant": pol, "model": method,
                              "prediction_seconds": int(np.isfinite(pred).sum()),
                              "negative_predictions": int(np.sum(pred < 0)),
                              "negative_percent": float(np.mean(pred[np.isfinite(pred)] < 0) * 100)
                                                  if np.isfinite(pred).any() else np.nan,
                              "predicted_mean": float(np.nanmean(pred)) if np.isfinite(pred).any() else np.nan})
        out.insert(0, "time_local", out.index.tz_convert(LOCAL_TZ))
        results[inst] = out
    return results, pd.DataFrame(summaries)


def build_hourly(results, station):
    """One row per instrument/model/hour; station in BOTH ug/m3 and ppb."""
    st = station.set_index(["pollutant", "hour_label_local"])
    campaign_start = pd.Timestamp(START_LOCAL, tz=LOCAL_TZ)
    campaign_end = pd.Timestamp(END_LOCAL, tz=LOCAL_TZ)
    labels = pd.date_range(campaign_start.floor("h") + pd.Timedelta(hours=1),
                           campaign_end.ceil("h"), freq="h", tz=LOCAL_TZ)
    rows=[]
    for inst, frame in results.items():
        for col in [c for c in frame if "__" in c and c.split("__", 1)[0] in ("NO2", "O3", "PM2_5")]:
            pol, model = col.split("__",1)
            for label_end in labels:
                left, right = label_end - pd.Timedelta(hours=1), label_end
                start_utc, end_utc = left.tz_convert("UTC"), right.tz_convert("UTC")
                values = pd.to_numeric(frame.loc[(frame.index >= start_utc) &
                             (frame.index < end_utc),col], errors="coerce")
                observed = values[np.isfinite(values)]
                n = int(len(observed)); coverage = n / 3600
                mean = float(observed.mean()) if n else np.nan
                median = float(observed.median()) if n else np.nan
                std = float(observed.std()) if n > 1 else np.nan
                key = (pol, label_end.strftime("%Y-%m-%d %H:%M"))
                ref = st.loc[key] if key in st.index else None
                station_ug = float(ref.station_value_ug_m3) if ref is not None else np.nan
                station_ppb = float(ref.station_hourly_mean_ppb) if ref is not None else np.nan
                factor = (float(ref["selected_ppb_per_ugm3"]) if ref is not None and
                          pol in ("NO2", "O3") else np.nan)
                if pol in ("NO2", "O3"):
                    mean_ppb = model_gas_mean_in_ppb(mean, pol, factor)
                    mean_ug = (mean if GAS_REFERENCE_UNITS[pol] == "ug/m3" else
                               (mean_ppb / factor if np.isfinite(mean_ppb) and
                                np.isfinite(factor) and factor > 0 else np.nan))
                    comp_model, comp_station, unit = mean_ppb, station_ppb, "ppb"
                    model_unit = GAS_REFERENCE_UNITS[pol]
                else:
                    mean_ppb = np.nan
                    mean_ug = mean
                    comp_model, comp_station, unit = mean_ug, station_ug, "ug/m3"
                    model_unit = "ug/m3"
                # Within-hour standard deviation of predicted 1-second values.
                # This is temporal variability, NOT sensor accuracy or an
                # uncertainty estimate for an individual observation.
                if pol in ("NO2", "O3"):
                    model_std_comp = model_gas_mean_in_ppb(std, pol, factor)
                else:
                    model_std_comp = std
                eligible = bool(n > 0 and coverage >= MIN_HOURLY_COVERAGE
                                and np.isfinite(comp_model) and np.isfinite(comp_station))
                weather_fields={}
                if ref is not None:
                    weather_fields = {key_: ref.get(key_, np.nan) for key_ in
                        ("weather_valid_minutes", "weather_coverage_pct_full_hour",
                         "weather_temperature_30m_C", "weather_station_pressure_hPa",
                         "weather_conversion_valid")}
                rows.append({"instrument":inst,"pollutant":pol,"model":model,
                    "interval_start_local":str(left),"interval_end_local":str(right),
                    "hour_label_local":label_end.strftime("%Y-%m-%d %H:%M"),
                    "n_valid_seconds":n,"coverage_pct_full_hour":100*coverage,
                    "full_hour_comparison_eligible":eligible,
                    "model_source_unit":model_unit, "model_mean_original_units":mean,
                    "model_median_original_units":median,"model_std_original_units":std,
                    "model_min_original_units":float(observed.min()) if n else np.nan,
                    "model_max_original_units":float(observed.max()) if n else np.nan,
                    "negative_predictions":int((observed<0).sum()),
                    "model_hourly_mean_ppb":mean_ppb,
                    "station_hourly_mean_ppb":station_ppb,
                    "model_mean_ug_m3_assuming_declared_units":mean_ug,
                    "station_hourly_mean_ug_m3":station_ug,
                    "comparison_unit":unit,
                    "comparison_model_mean":comp_model,
                    "model_hourly_std_comparison_units": model_std_comp,
                    "model_hourly_sd_type": "within-hour SD of 1-second predictions; not instrument uncertainty",
                    "comparison_station_mean":comp_station,
                    "difference_model_minus_station":(comp_model-comp_station) if eligible else np.nan,
                    "difference_model_minus_station_ug_m3":(mean_ug-station_ug) if eligible else np.nan,
                    "station_source_page":STATION_PAGES[pol],
                    "station_actual_uncertainty_reported": False,
                    **weather_fields})
    return pd.DataFrame(rows)


def create_wide_hourly_overview(hourly, value="comparison_model_mean", reference="comparison_station_mean"):
    """Combined unit overview: NO2/O3 in ppb, PM2.5 in ug/m3."""
    index=["pollutant","hour_label_local"]
    values=hourly.pivot_table(index=index, columns=["instrument","model"],
                              values=value, aggfunc="first")
    values.columns=[f"{inst}__{model}" for inst,model in values.columns]
    ref=hourly.groupby(index,as_index=True)[reference].first()
    joined=pd.concat([ref.rename("official_station"),values],axis=1)
    joined=joined.reset_index().sort_values(index)
    joined.insert(2, "unit", joined.pollutant.map({"NO2":"ppb","O3":"ppb","PM2_5":"ug/m3"})
                  if value == "comparison_model_mean" else "ug/m3")
    return joined


def hourly_summary(hourly):
    """RMSE/MAE/Bias in ppb for gases and ug/m3 for PM, plus original mass metrics."""
    rows=[]
    for (inst,pol,model),group in hourly.groupby(["instrument","pollutant","model"],sort=False):
        paired=group.loc[group.full_hour_comparison_eligible]
        truth=paired.comparison_station_mean.to_numpy(float)
        pred=paired.comparison_model_mean.to_numpy(float)
        err=pred-truth; n=len(paired)
        r=float(np.corrcoef(truth,pred)[0,1]) if n>=3 and np.std(truth)>0 and np.std(pred)>0 else np.nan
        mass_err=(paired.model_mean_ug_m3_assuming_declared_units -
                  paired.station_hourly_mean_ug_m3).to_numpy(float)
        rows.append({"instrument":inst,"pollutant":pol,"model":model,
                     "comparison_unit":"ppb" if pol in ("NO2","O3") else "ug/m3",
                     "hourly_pairs":n,"pearson_r_hourly":r,
                     "RMSE":float(np.sqrt(np.mean(err**2))) if n else np.nan,
                     "MAE":float(np.mean(np.abs(err))) if n else np.nan,
                     "Bias":float(np.mean(err)) if n else np.nan,
                     "mean_station":float(truth.mean()) if n else np.nan,
                     "mean_model":float(pred.mean()) if n else np.nan,
                     "RMSE_ug_m3":float(np.sqrt(np.mean(mass_err**2))) if n else np.nan,
                     "MAE_ug_m3":float(np.mean(np.abs(mass_err))) if n else np.nan,
                     "Bias_ug_m3":float(np.mean(mass_err)) if n else np.nan,
                     "note":"Gas unit comparison requires confirmed Mandria reference units; official station converted using LfU reference conditions. Sensor error bars are +/-1 within-hour SD, not measurement uncertainty. Station has no error bars."})
    return pd.DataFrame(rows)


def plot_hourly(hourly, results, output, met):
    """Visualize paired-hour RMSE and ONLY sensor within-hour variability.

    Lothstrasse station appears as a point/line with NO error bars or bands.
    Model hourly means have +/-1 SD computed from the valid 1-second model
    predictions in that clock hour. SD is temporal variation, NOT certified
    measurement uncertainty. RMSE is computed on eligible complete-hour pairs.
    """
    root = output / "plots"
    root.mkdir(parents=True, exist_ok=True)
    unit_of = lambda p: "ppb" if p in ("NO2", "O3") else "ug/m3"
    stats = hourly_summary(hourly)
    lookup = {(r.instrument, r.pollutant, r.model): r
              for r in stats.itertuples(index=False)}
    notes = []

    def stat_string(inst, pol, model):
        row = lookup.get((inst, pol, model))
        if row is None or not np.isfinite(row.RMSE):
            return "RMSE: n/a (no complete-hour pairs)"
        return f"RMSE: {row.RMSE:.2f} {unit_of(pol)} (n={int(row.hourly_pairs)} h)"

    def figure_note(fig):
        fig.text(0.015, 0.008,
                 "Device bars: +/-1 SD of within-hour 1-second predictions (temporal variability, NOT sensor uncertainty). "
                 "Lothstrasse: no error bars. RMSE: eligible paired hourly means.",
                 ha="left", va="bottom", fontsize=7.1, color="#59616b")

    def reference(block):
        return block.drop_duplicates("hour_label_local").sort_values("hour_label_local")

    def station_hourly(ax, ref):
        valid = ref.loc[ref.comparison_station_mean.notna()]
        if not valid.empty:
            ax.plot(pd.to_datetime(valid.hour_label_local),
                    valid.comparison_station_mean.to_numpy(float),
                    color="black", marker="s", ls="--", lw=2,
                    label="Lothstrasse reference (no uncertainty shown)", zorder=4)

    def station_hourly_on_second_axis(ax, ref):
        from matplotlib.lines import Line2D
        valid = ref.loc[ref.comparison_station_mean.notna()]
        for _, rec in valid.iterrows():
            right = pd.Timestamp(rec.hour_label_local)
            left = right - pd.Timedelta(hours=1)
            ax.hlines(float(rec.comparison_station_mean), left, right,
                      colors="black", linewidth=2, alpha=.9, zorder=3)
        return [Line2D([0], [0], color="black", lw=2,
                       label="Lothstrasse hourly reference (no error bars)")]

    def sensor_errorbars(ax, g, color=None, label=None, zorder=5):
        g = g.sort_values("hour_label_local")
        ok = g.full_hour_comparison_eligible.to_numpy(bool)
        g = g.loc[ok & g.comparison_model_mean.notna()].copy()
        if g.empty:
            return
        x = pd.to_datetime(g.hour_label_local)
        y = g.comparison_model_mean.to_numpy(float)
        sd = g.model_hourly_std_comparison_units.to_numpy(float)
        sd = np.where(np.isfinite(sd) & (sd >= 0), sd, 0.0)
        ax.errorbar(x, y, yerr=sd, fmt="o-", capsize=3.5, elinewidth=1.0,
                    lw=1.8, color=color, markersize=4.8, zorder=zorder,
                    label=label)

    for inst, data in results.items():
        for pol in ("NO2", "O3", "PM2_5"):
            block = hourly[(hourly.instrument == inst) & (hourly.pollutant == pol)]
            if block.empty:
                continue
            ref = reference(block)
            folder = root / inst
            folder.mkdir(parents=True, exist_ok=True)

            fig, ax = plt.subplots(figsize=(12.3, 6.3))
            station_hourly(ax, ref)
            for model, g in block.groupby("model"):
                model_name = model.replace("_", " ")
                sensor_errorbars(ax, g,
                                 label=f"{model_name} | {stat_string(inst, pol, model)}")
                skipped = g.loc[(~g.full_hour_comparison_eligible) & g.comparison_model_mean.notna()]
                if not skipped.empty:
                    ax.scatter(pd.to_datetime(skipped.hour_label_local),
                               skipped.comparison_model_mean, marker="x", s=50,
                               label=f"{model_name} (incomplete, excluded)")
                row = lookup[(inst, pol, model)]
                notes.append({"plot": f"{inst}/{pol}_hourly_vs_station.png",
                              "instrument": inst, "pollutant": pol, "model": model,
                              "RMSE": row.RMSE, "n_complete_hours": row.hourly_pairs})
            ax.set(title=f"{inst} | {pol}: Hourly model and Lothstrasse reference",
                   xlabel="Hour ending (CET; 20:00 = 19:00-20:00)",
                   ylabel=f"Concentration ({unit_of(pol)})")
            ax.grid(alpha=.24)
            ax.legend(fontsize=8, loc="best")
            fig.autofmt_xdate()
            figure_note(fig)
            fig.tight_layout(rect=(0,.04,1,1))
            fig.savefig(folder/f"{pol}_hourly_vs_station.png", dpi=165)
            plt.close(fig)

            fig, ax = plt.subplots(figsize=(12.3, 6.3))
            model_colors = {}
            for name in [c for c in data if c.startswith(pol+"__")]:
                series = data[name]
                valid = series.notna()
                model = name.split("__", 1)[1]
                if valid.any():
                    vals = (model_gas_values_in_ppb(series[valid], pol, met)
                            if pol in ("NO2", "O3") else series[valid].to_numpy(float))
                    plotted, = ax.plot(series.index[valid].tz_convert(LOCAL_TZ).tz_localize(None),
                                       vals, lw=.75, alpha=.6,
                                       label=f"{model.replace('_',' ')} | {stat_string(inst,pol,model)}")
                    model_colors[model] = plotted.get_color()
            # Hourly device error bars (NOT station error bars) over the raw series.
            from matplotlib.lines import Line2D
            extra_handles = station_hourly_on_second_axis(ax, ref)
            for model, g in block.groupby("model"):
                sensor_errorbars(ax, g, color=model_colors.get(model), label=None, zorder=6)
            extra_handles += [Line2D([0],[0], color="gray", marker="o", lw=0,
                                     label="Device hourly mean +/-1 within-hour SD")]
            h,l = ax.get_legend_handles_labels()
            ax.legend(h+extra_handles, l+[hh.get_label() for hh in extra_handles],
                      fontsize=7.6, loc="best")
            ax.set(title=f"{inst} | {pol}: 1-second predictions vs hourly reference",
                   xlabel="Munich local time (CET)",
                   ylabel=f"Concentration ({unit_of(pol)})")
            ax.grid(alpha=.2)
            fig.autofmt_xdate()
            figure_note(fig)
            fig.tight_layout(rect=(0,.04,1,1))
            fig.savefig(folder/f"{pol}_time_series_1s.png", dpi=165)
            plt.close(fig)
            for model in block.model.unique():
                row = lookup[(inst, pol, model)]
                notes.append({"plot": f"{inst}/{pol}_time_series_1s.png",
                              "instrument": inst, "pollutant": pol, "model": model,
                              "RMSE": row.RMSE, "n_complete_hours": row.hourly_pairs})

    for pol in ("NO2", "O3", "PM2_5"):
        block = hourly[hourly.pollutant == pol]
        if block.empty:
            continue
        fig, ax = plt.subplots(figsize=(14, 7.5))
        ref = reference(block)
        station_hourly(ax, ref)
        for (inst, model), g in block.groupby(["instrument", "model"]):
            sensor_errorbars(ax, g,
                             label=f"{inst}: {model.replace('_',' ')} | {stat_string(inst,pol,model)}")
            row = lookup[(inst, pol, model)]
            notes.append({"plot": f"ALL_{pol}_hourly_comparison.png",
                          "instrument": inst, "pollutant": pol, "model": model,
                          "RMSE": row.RMSE, "n_complete_hours": row.hourly_pairs})
        ax.set(title=f"{pol}: Hourly comparison across instruments (RMSE in legend)",
               xlabel="Hour ending (CET; preceding 60 minutes)",
               ylabel=f"Concentration ({unit_of(pol)})")
        ax.grid(alpha=.22)
        ax.legend(fontsize=7.2, ncol=2, loc="best")
        fig.autofmt_xdate()
        figure_note(fig)
        fig.tight_layout(rect=(0,.04,1,1))
        fig.savefig(root/f"ALL_{pol}_hourly_comparison.png", dpi=175)
        plt.close(fig)
    return pd.DataFrame(notes)


def build_station_conversion_scenarios(station_original, field, met):
    """One Lothstrasse mass value, converted under different meteorology choices.

    Sensor meteorology comes from EACH physical device's own measured_T and
    measured_p columns (before any co-location donor matching). Each conversion
    uses mean of its own time-resolved ideal-gas conversion factors; no gap fill.
    2m/30m LMU conditions use the same LMU measured station pressure.
    Values are hypothetical re-expressions of the SAME mass reference value.
    """
    rows = []
    campaign_lo = pd.Timestamp(START_LOCAL, tz=LOCAL_TZ).tz_convert("UTC")
    campaign_hi = pd.Timestamp(END_LOCAL, tz=LOCAL_TZ).tz_convert("UTC")

    for ref in station_original.itertuples(index=False):
        pol = ref.pollutant
        label = ref.hour_label_local
        mass = float(ref.station_value_ug_m3)
        end = pd.Timestamp(label, tz=LOCAL_TZ).tz_convert("UTC")
        start = end - pd.Timedelta(hours=1)
        if pol == "PM2_5":
            rows.append({"pollutant": pol, "hour_label_local": label,
                         "scenario": "Official station (ug/m3)", "scenario_group": "reference",
                         "station_original_ug_m3":mass, "station_converted":mass,
                         "unit":"ug/m3", "temperature_C":np.nan,
                         "pressure_hPa":np.nan,"n_valid_samples":np.nan,
                         "available_window_seconds":3600,
                         "coverage_of_full_hour_pct":100.0,
                         "note":"No gas-phase ppb conversion for particulate matter"})
            continue
        options = [("LfU reference (20 C, 1013 hPa)", "standard", None)]
        for inst in INSTRUMENTS:
            options.append((f"Device meteorology: {inst}", "own_device", inst))
        options.extend((("LMU MIM01 temperature 30m", "LMU_30m", "30m"),
                        ("LMU MIM01 temperature 2m", "LMU_2m", "2m")))
        for name, group, source in options:
            if group == "standard":
                temp, press, n, fraction = LFU_REFERENCE_T_C, LFU_REFERENCE_PRESSURE_HPA, 3600, 100.0
                factor = float(ugm3_to_ppb(1.0, pol, temp, press))
                note = "Official mass concentration reference conditions; not ambient weather"
            else:
                if group == "own_device":
                    source_data = field[source]
                    a = source_data.loc[(source_data.index >= start) & (source_data.index < end)]
                    temperature = pd.to_numeric(a["measured_T"], errors="coerce") if "measured_T" in a else pd.Series(dtype=float)
                    pressure = pd.to_numeric(a["measured_p"], errors="coerce") if "measured_p" in a else pd.Series(dtype=float)
                    samples = pd.DataFrame({"temperature":temperature,"pressure":pressure}).dropna()
                    samples = samples.loc[samples.temperature.between(-40,65) & samples.pressure.between(700,1100)]
                    expected = max(0, (min(end,campaign_hi) - max(start,campaign_lo)).total_seconds())
                    note = "Device T/p recorded during the monitored interval (not a full-hour weather series if partial)"
                else:
                    a = met.loc[(met.index >= start) & (met.index < end)]
                    samples = pd.DataFrame({"temperature":a[f"temperature_{source}_C"], "pressure":a["pressure_hPa"]}).dropna()
                    samples = samples.loc[samples.temperature.between(-50,60) & samples.pressure.between(700,1100)]
                    expected = 3600
                    note = ("LMU MIM01 2m temperature: potential positive bias reported for 2026"
                            if group == "LMU_2m" else
                            "LMU MIM01 30m temperature and station pressure (not Lothstrasse meteorology)")
                n = len(samples)
                temp = float(samples.temperature.mean()) if n else np.nan
                press = float(samples.pressure.mean()) if n else np.nan
                fraction = float(100 * n * (60 if group.startswith("LMU_") else 1)/3600)
                factors = ugm3_to_ppb(np.ones(n), pol,
                                       samples.temperature.to_numpy(float),
                                       samples.pressure.to_numpy(float)) if n else np.array([])
                factor = float(np.nanmean(factors)) if n else np.nan
            rows.append({
                "pollutant":pol,"hour_label_local":label,
                "scenario":name,"scenario_group":group,
                "station_original_ug_m3":mass,
                "station_converted":mass*factor if np.isfinite(factor) else np.nan,
                "unit":"ppb", "temperature_C":temp,"pressure_hPa":press,
                "n_valid_samples":n,"available_window_seconds":3600,
                "coverage_of_full_hour_pct":fraction,
                "note":note
            })
    return pd.DataFrame(rows)


def plot_two_panel_comparisons(hourly, station_scenarios, output):
    """Top: calibrated devices. Bottom: station with multiple gas T/p scenarios.

    Both subplots use IDENTICAL numeric y-axis limits for direct visual comparison.
    NO station uncertainty bars. Device mean +/-1 within-hour standard deviation
    is temporal variability, not instrumental uncertainty or model uncertainty.
    RMSE is calculated against the official/reference-conditions conversion.
    """
    import matplotlib.dates as mdates
    root = output / "plots"
    root.mkdir(parents=True, exist_ok=True)
    metrics = hourly_summary(hourly)
    metric_lookup = {(r.instrument,r.pollutant,r.model):r for r in metrics.itertuples(index=False)}
    output_notes = []
    style_order = ["LfU reference (20 C, 1013 hPa)",
                   "Device meteorology: gas_drone", "Device meteorology: ground_basic",
                   "Device meteorology: ground_screen", "Device meteorology: opc_drone",
                   "LMU MIM01 temperature 30m", "LMU MIM01 temperature 2m"]
    palette = plt.get_cmap("tab10")
    lower_colors = {"LfU reference (20 C, 1013 hPa)":"black",
                    "Device meteorology: gas_drone":"#168a73",
                    "Device meteorology: ground_basic":"#d18b00",
                    "Device meteorology: ground_screen":"#9764bd",
                    "Device meteorology: opc_drone":"#628aab",
                    "LMU MIM01 temperature 30m":"#bf4e4e",
                    "LMU MIM01 temperature 2m":"#cf75a0"}
    # Sensor plot series and corresponding RMSE annotation.
    for pol in ("NO2", "O3", "PM2_5"):
        block = hourly.loc[hourly.pollutant == pol].copy()
        ref = station_scenarios.loc[station_scenarios.pollutant == pol].copy()
        if block.empty or ref.empty:
            continue
        unit = "ppb" if pol in ("NO2","O3") else "ug/m3"
        fig, (top, bottom) = plt.subplots(2, 1, figsize=(15, 10.4), sharex=True, sharey=True,
                                          gridspec_kw={"height_ratios":[1.12,1]})
        fig.suptitle(f"Munich Lothstrasse | {pol.replace('_', '.')} | 14 Nov 2026",
                     fontsize=16, fontweight="bold")
        all_y = []
        for i,((inst,model),group) in enumerate(block.groupby(["instrument","model"],sort=True)):
            group = group.sort_values("hour_label_local")
            eligible = group.loc[group.full_hour_comparison_eligible & group.comparison_model_mean.notna()]
            if eligible.empty:
                continue
            x = pd.to_datetime(eligible.hour_label_local)
            y = eligible.comparison_model_mean.to_numpy(float)
            sd = eligible.model_hourly_std_comparison_units.to_numpy(float)
            sd = np.where(np.isfinite(sd)&(sd>=0),sd,0)
            color = palette(i%10)
            metric = metric_lookup.get((inst,pol,model))
            rlabel = f"RMSE {metric.RMSE:.2f} {unit} (n={metric.hourly_pairs})" if metric is not None and np.isfinite(metric.RMSE) else "RMSE n/a"
            lab = f"{inst} | {model.replace('_',' ')} | {rlabel}"
            top.errorbar(x, y, yerr=sd, fmt="o-", lw=1.6, markersize=4.2,
                         capsize=3, elinewidth=.85, color=color, label=lab)
            all_y.extend((y-sd).tolist()); all_y.extend((y+sd).tolist())
            output_notes.append({"pollutant":pol,"instrument":inst,"model":model,
                                 "RMSE":metric.RMSE if metric is not None else np.nan,
                                 "n_paired_full_hours":metric.hourly_pairs if metric is not None else 0})
        top.set_title("Calibrated device hourly means (+/-1 SD of 1-second predictions)",fontsize=11)
        top.set_ylabel(f"Concentration ({unit})")
        top.grid(alpha=.22)
        top.legend(loc="best",fontsize=7.4,ncol=2,framealpha=.9)
        for name in (["Official station (ug/m3)"] if pol == "PM2_5" else style_order):
            g = ref.loc[(ref.scenario == name) & ref.station_converted.notna()].sort_values("hour_label_local")
            if g.empty:
                continue
            x = pd.to_datetime(g.hour_label_local)
            y = g.station_converted.to_numpy(float)
            standard = (name == "LfU reference (20 C, 1013 hPa)" or name == "Official station (ug/m3)")
            bottom.plot(x,y,marker="s" if standard else "o", markersize=4.6 if standard else 3.5,
                        ls="-" if standard else "--",lw=2.7 if standard else 1.35,
                        alpha=1 if standard else .83, color="black" if standard else lower_colors.get(name),
                        label=name, zorder=4 if standard else 2)
            all_y.extend(y.tolist())
        bottom.set_title(("Official Lothstrasse PM2.5 hourly mass concentration" if pol=="PM2_5" else
                         "One station series re-expressed using different temperature/pressure conditions"), fontsize=11)
        bottom.set_ylabel(f"Concentration ({unit})")
        bottom.set_xlabel("Hour ending (Munich CET); e.g. 20:00 = 19:00-20:00")
        bottom.grid(alpha=.22)
        bottom.legend(loc="best",fontsize=8, ncol=2,framealpha=.9)
        for ax in (top,bottom):
            ax.xaxis.set_major_locator(mdates.HourLocator(interval=1))
            ax.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
        data = np.asarray(all_y,dtype=float)
        data = data[np.isfinite(data)]
        if len(data):
            lo,hi=float(data.min()),float(data.max())
            pad=max(.07*(hi-lo),.5 if pol!="PM2_5" else .75)
            lo,hi=lo-pad,hi+pad
            top.set_ylim(lo,hi)  # sharey=True -> both numeric limits are identical
            bottom.set_ylim(lo,hi)
        fig.text(.02,.035,("Station: no uncertainty bars; multiple lower curves are alternative unit conversions, NOT independent observations. "
                             "Device bars: temporal within-hour SD, not accuracy. RMSE against LfU-reference conversion.")
                 if pol!="PM2_5" else
                 ("Station: no uncertainty bars. Device bars: +/-1 SD of 1-second predictions (temporal variability, not accuracy). "
                  "RMSE uses paired complete-hour means. PM2.5 hourly application of daily-trained models is exploratory."),
                 fontsize=8.2,color="#48525c")
        fig.tight_layout(rect=[.015,.065,.99,.96],h_pad=2.0)
        fig.savefig(root/f"ALL_{pol}_two_panel_station_conditions.png",dpi=180)
        plt.close(fig)
        log(f"[PLOT] ALL_{pol}_two_panel_station_conditions.png")
    return pd.DataFrame(output_notes)


def save_csv(df, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, sep=";", decimal=",", index=False, encoding="utf-8-sig", float_format="%.9g")


def check_only(cal, field_sources):
    OUTPUT.mkdir(parents=True, exist_ok=True)
    station = load_station_reference()
    save_csv(station, OUTPUT / "official_station_hourly_reference_transcribed.csv")
    notes=[]
    for inst, src in field_sources.items():
        f = read_field_second(src, cal)
        counts=f.resample("1h").size()
        for hour, n in counts.items():
            notes.append({"instrument": inst,
                          "hour_ending_utc": str(hour + pd.Timedelta(hours=1)),
                          "hour_ending_local": str((hour + pd.Timedelta(hours=1)).tz_convert(LOCAL_TZ)),
                          "n_seconds_in_resampled_range": n,
                          "n_seconds_with_raw_data": int(f.loc[hour:hour+pd.Timedelta(minutes=59,seconds=59)].notna().any(axis=1).sum())})
    save_csv(pd.DataFrame(notes), OUTPUT / "field_data_availability_preview.csv")
    log("[CHECK COMPLETE] Raw files parsed and station screenshot values exported. No models trained.")


def main():
    global NN_EPOCHS
    parser = argparse.ArgumentParser(description="Lothstrasse, 14 November 2026: hourly model/station comparison")
    parser.add_argument("--check", action="store_true", help="Inspect raw inputs and transcribed reference, no model fitting")
    parser.add_argument("--epochs", type=int, default=NN_EPOCHS, help="Maximum NN epochs (default 100)")
    args, _ = parser.parse_known_args()  # Spyder compatibility
    NN_EPOCHS = args.epochs
    log("[START] Lothstrasse winter comparison, 14 November 2026")
    log(f"[TIME] {START_LOCAL} to {END_LOCAL} (Europe/Berlin, CET UTC+1)")
    log("[UNIT ASSUMPTION] Mandria NO2 and O3 predictions are treated as ppb. Check reference units before publication.")
    log(f"[CONVERSION] Station ug/m3 -> ppb using {STATION_GAS_CONVERSION_MODE}; LfU standardized mass values are referenced to 20 C, 1013 hPa.")
    log("[ERROR BARS] Station: none. Device: +/-1 SD of 1-second values within eligible clock hours. Not measurement accuracy.")
    cal = resolve_cal_module()
    field_sources = discover_field_sources(cal)
    for k, src in field_sources.items():
        log(f"[FIELD SOURCE] {k}: {src.label()}")
    if args.check:
        check_only(cal, field_sources)
        return
    original_sources = discover_mandria_sources(cal)
    for k, src in original_sources.items():
        log(f"[MANDRIA SOURCE] {k}: {src.label()}")
    original_models, metrics, training_prov = train_models(cal, original_sources)
    field = {k: read_field_second(field_sources[k], cal) for k in INSTRUMENTS}
    field = transfer_colocated_meteo(field)
    predicted, prediction_qc = predict_field(field, original_models)
    OUTPUT.mkdir(parents=True, exist_ok=True)
    station_original = load_station_reference()
    weather_minute, weather_source = load_weather_minute()
    hourly_weather = make_hourly_weather(weather_minute)
    station = add_station_converted_units(station_original, hourly_weather)
    scenario_table = build_station_conversion_scenarios(station_original, field, weather_minute)
    hourly = build_hourly(predicted, station)
    summary = hourly_summary(hourly)
    save_csv(station_original, OUTPUT / "official_station_hourly_reference_transcribed.csv")
    save_csv(station, OUTPUT / "station_hourly_reference_with_weather_ppb.csv")
    save_csv(scenario_table, OUTPUT / "station_all_temperature_pressure_scenarios.csv")
    save_csv(hourly_weather, OUTPUT / "LMU_weather_hourly_conversion_factors.csv")
    save_csv(metrics, OUTPUT / "mandria_calibration_metrics.csv")
    save_csv(prediction_qc, OUTPUT / "field_predictions_quality_control.csv")
    save_csv(hourly, OUTPUT / "hourly_comparison_all_instruments.csv")
    wide = create_wide_hourly_overview(hourly)
    mass_wide = create_wide_hourly_overview(hourly, "model_mean_ug_m3_assuming_declared_units", "station_hourly_mean_ug_m3")
    save_csv(wide, OUTPUT / "hourly_comparison_wide.csv")
    save_csv(mass_wide, OUTPUT / "hourly_comparison_wide_ug_m3.csv")
    save_csv(summary, OUTPUT / "station_comparison_summary_metrics.csv")
    try:
        with pd.ExcelWriter(OUTPUT / "Lothstrasse_hourly_comparison.xlsx", engine="openpyxl") as writer:
            for name, table in (("Station reference", station),
                                ("Conversion scenarios", scenario_table),
                                ("Hourly weather factors", hourly_weather),
                                ("Hourly comparison", hourly),
                                ("Wide overview", wide),
                                ("Wide mass units", mass_wide),
                                ("Model ranking", summary),
                                ("Mandria validation", metrics),
                                ("Prediction QC", prediction_qc)):
                table.to_excel(writer, sheet_name=name, index=False)
                worksheet = writer.sheets[name]
                worksheet.freeze_panes = "B2"
                worksheet.auto_filter.ref = worksheet.dimensions
                from openpyxl.styles import Font, PatternFill
                for cell in worksheet[1]:
                    cell.font = Font(bold=True, color="FFFFFF")
                    cell.fill = PatternFill("solid", fgColor="1F4767")
                for col in worksheet.columns:
                    from openpyxl.utils import get_column_letter
                    length = max((len(str(cell.value)) for cell in list(col)[:200] if cell.value is not None), default=8)
                    worksheet.column_dimensions[get_column_letter(col[0].column)].width = min(42, max(12, length + 2))
    except ImportError:
        log("[NOTE] Install openpyxl to also export the optional Excel workbook.")
    for inst, table in predicted.items():
        save_csv(table.reset_index(), OUTPUT / "calibrated_1s" / f"{inst}_calibrated_1s.csv")
    plot_rmse = plot_hourly(hourly, predicted, OUTPUT, weather_minute)
    two_panel_details = plot_two_panel_comparisons(hourly, scenario_table, OUTPUT)
    save_csv(two_panel_details, OUTPUT / "two_panel_models_RMSE.csv")
    save_csv(plot_rmse, OUTPUT / "RMSE_per_plot.csv")
    (OUTPUT / "DEVICE_VARIABILITY_AND_RMSE_README.txt").write_text(
        "Lothstrasse hourly reference comparison\n\n"
        "Official station screenshot values: plotted without uncertainty/error bars.\n"
        "Device error bars: +/- 1 standard deviation of available 1-second\n"
        "calibrated predictions within each eligible clock hour.\n"
        "This indicates short-term temporal variability, NOT sensor accuracy,\n"
        "instrument uncertainty, standard error or a confidence interval.\n\n"
        "RMSE is computed from the paired eligible full-hour model and station means.\n"
        "It is not the error bar on each point.\n"
        "Station gas values in ug/m3 are converted to ppb at LfU reference\n"
        "conditions (20 C, 1013 hPa). LMU-weather alternative is exported only\n"
        "as an exploratory sensitivity analysis.\n"
        f"LfU reference conditions: {LFU_ARCHIVE_SOURCE}\n",
        encoding="utf-8")
    meta = {
        "project": "Munich Lothstrasse winter co-location", "date": MEASUREMENT_DATE,
        "measurement_local_start": START_LOCAL, "measurement_local_end_exclusive": END_LOCAL,
        "timezone": LOCAL_TZ, "station_hour_rule": "H means preceding interval [H-1h, H)",
        "station_source": "Dokumentation.docx pp14-16, screenshots manually transcribed",
        "field_sources": {k: v.label() for k, v in field_sources.items()},
        "original_mandria_sources": {k: v.label() for k, v in original_sources.items()},
        "calibration_models": training_prov,
        "meteo_source": {"gas_drone":"own", "ground_basic":"own", **METEO_PROVIDER},
        "minimum_full_hour_coverage": MIN_HOURLY_COVERAGE,
        "neural_max_epochs": NN_EPOCHS, "random_seed": SEED,
        "original_mandria_gas_reference_unit_ASSUMPTION": GAS_REFERENCE_UNITS,
        "meteorology_source": str(weather_source),
        "station_gas_conversion_default": STATION_GAS_CONVERSION_MODE,
        "lfu_mass_concentration_reference_conditions": {"temperature_C":LFU_REFERENCE_T_C,
                                                        "pressure_hPa":LFU_REFERENCE_PRESSURE_HPA,
                                                        "source": LFU_ARCHIVE_SOURCE},
        "reference_uncertainty": "No site-specific hourly uncertainty reported; NO station error bars plotted",
        "device_error_bars": "+/-1 within-hour SD of valid 1-second model predictions (eligible hours only); temporal variability, NOT instrumental uncertainty",
        "rmse_definition": "sqrt(mean((sensor hourly mean minus station hourly mean)^2)) over eligible full-hour pairs; displayed even on 1s plots",
        "meteorology_source_station": "MIM01, Meteorological Institute, LMU Munich; Theresienstrasse 37",
        "meteorology_temperature": "Measured 30 m air temperature, Celsius converted to Kelvin",
        "meteorology_pressure": "Measured station pressure in hPa converted to Pa; NOT sea-level pressure",
        "meteorology_minimum_full_hour_coverage": MIN_WEATHER_COVERAGE,
        "conversion_formula": "c_ppb = c_ug_m3 * 1000 * R * T_K / (M_g_mol * p_Pa)",
        "hourly_conversion_method": "LfU reference 20 C/1013 hPa for main RMSE comparison; exploratory sensitivity: per-device recorded meteorology and measured LMU 2m/30m temperature with station pressure",
        "additional_two_panel_plots": "ALL_NO2_two_panel_station_conditions.png, ALL_O3_two_panel_station_conditions.png, ALL_PM2_5_two_panel_station_conditions.png",
        "two_panel_y_scale": "Identical y-axis limits for top sensor and bottom station panels",
        "lmu_2m_temperature_note": "Possible positive bias in 2026 according to LMU Meteorological Institute",
        "model_comparison_units": {"NO2": "ppb", "O3": "ppb", "PM2_5": "ug/m3"},
        "partial_hours_excluded_from_error_comparison": True,
        "PM_station_reference_20_00": "NOT PRESENT in screenshot: not estimated",
        "PM_calibration_resolution": "trained daily, applied exploratory to 1-second observations",
        "gas_calibration_resolution": "trained on 30-second averages, applied exploratory to 1-second observations",
        "negative_prediction_policy": "never clipped to zero",
        "cross_sensitivity": "gas sensors are cross-sensitive, not individual selective analyzers",
        "cautions": ["confirm original gas reference units before physical comparison",
                     "weather is from LMU MIM01, not the Lothstrasse station itself",
                     "original 2026 LMU 2m temperature has known warm bias; 30m used",
                     "conversion assumes dry air ideal gas and minute T/p apply to concentration hour average",
                     "November raw environmental and GPS time rows with invalid 2080 dates excluded",
                     "sensor and official station may not sample exactly the same air"],
    }
    (OUTPUT / "methods_and_provenance.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    log("\n[RESULTS] Station comparisons (eligible complete-hour pairs only):")
    cols = ["instrument", "pollutant", "model", "comparison_unit", "hourly_pairs", "mean_model", "mean_station", "RMSE", "pearson_r_hourly"]
    log(summary[cols].round(3).to_string(index=False))
    log(f"[DONE] Outputs: {OUTPUT}")


if __name__ == "__main__":
    main()
