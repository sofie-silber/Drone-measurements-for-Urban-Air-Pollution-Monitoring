#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Munich, 21 Oct 2026: drone vs LP-DOAS vs DCS (researchers + raw fits).

Run in Spyder (F5). Put this script and selected_calibrated_log009_1s.csv
beside the THREE original files in DATA_DIR. No network access is needed.

Models: NO2 NN Tanh WITHOUT pressure, CO NN ReLU without pressure,
O3 NN GELU and NN Tanh without pressure. All are previously fitted
100-epoch Mandria models, evaluated at the recorded drone seconds.
This program loads their predictions and DOES NOT retrain any network.

All timestamps displayed are Munich CEST for 21 October 2026.
Drone GPS timestamps are UTC; naive LP-DOAS/DCS times are ASSUMED CEST.
DCS fit-parameter zero is NOT certified to be NO2 in molecules/cm3.
Researchers' DCS NO2 statistics are a separate, already processed ppb dataset:
we do NOT convert the unverified raw fit parameter to ppb.

Uncertainty: drone = held-out TEST RMSE for the matching gas_drone NO2
NN_tanh_without_pressure model, read from calibration metrics (if available);
LP-DOAS = reported mean only, with NO uncertainty/error column;
researchers' DCS NO2 = the reported SD of each interval, except the first
flight combined SD, which is recalculated from the two subintervals.
The optional raw Voigt fit parameters are in UNVERIFIED units.
A calibration test RMSE is NOT a flight-specific measurement uncertainty.
RMSE cannot be derived from predictions with no matching reference values.
"""
from __future__ import annotations

import datetime as dt
import importlib
import io
import json
import math
import pickle
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

# --------------------------------------------------------------------
# SETTINGS: EDIT ONLY IF YOUR FILES ARE STORED ELSEWHERE
# --------------------------------------------------------------------
DATA_DIR = Path(r"C:\Users\xy-84\Desktop\Master\Thesis\Background_Data_Paris\Graz Campaign")
OUTPUT_DIR = DATA_DIR / "results_two_flights_DOAS_DCS"
PREDICTIONS_NAME = "selected_calibrated_log009_1s.csv"
LOCAL_TZ = "Europe/Berlin"
# The CSV and NPZ contain timezone-naive reference timestamps. Ask TU Graz
# to confirm their timezone before drawing final quantitative conclusions.
LPDOAS_NAIVE_TZ = "Europe/Berlin"
DCS_NAIVE_TZ = "Europe/Berlin"

# Units MUST be verified against Mandria original reference documentation.
DRONE_NO2_UNIT = "unconfirmed"   # "ppb", "ug/m3" or "unconfirmed"
# This file is written by calibration_paris_english.py after calibration.
# The calibration code alone does not contain the numerical RMSE result.
CALIBRATION_METRICS_CSV = DATA_DIR.parent / "results_calibration" / "all_model_metrics.csv"
CALIBRATION_INSTRUMENT = "gas_drone"
CALIBRATION_POLLUTANT = "NO2"
CALIBRATION_MODEL = "NN_tanh_without_pressure"
CALIBRATION_PHASE = "test"  # Held-out test data; NEVER substitute train/validation.
# Optional verified test RMSE override; leave None to auto-load the file.
DRONE_NO2_MODEL_RMSE_ORIGINAL_UNITS = None
# Keep False until TU Graz confirms that Voigt results[:,0] is
# NO2 number density in molecules per cm3.
DCS_PARAM0_CONFIRMED_MOLEC_CM3 = False
# Values from the NPZ filename; apply only if the above is confirmed.
DCS_FIT_T_K = 293.0
DCS_FIT_P_HPA = 1000.0

DAY = "2026-10-21"
# User-supplied GPS-estimated windows. Half-open intervals [start, end).
WINDOWS = [
    ("Flight 1", "Outbound", "07:50:00", "07:52:55", True),
    ("Flight 1", "Return", "07:52:55", "07:55:05", True),
    ("Flight 2", "Outbound", "07:59:15", "08:01:20", True),
    ("Flight 2", "Return", "08:01:20", "08:03:00", False),
]
# Already processed DCS NO2 summaries supplied by the scientists, in ppb.
# The full 07:50-07:55 result is an OVERALL summary, NOT another
# independent time interval; exclude it from overlap calculations/plots.
# Its SD is recomputed using the pooled sample-variance formula.
# Interval times are minute-precision boundaries as supplied, [start, end).
DCS_SCIENTISTS_REPORTED = [
    {"start": "07:50:00", "end": "07:53:00", "n": 180,
     "mean_ppb": 11.99, "sd_ppb": 0.64, "kind": "part"},
    {"start": "07:53:00", "end": "07:55:00", "n": 121,
     "mean_ppb": 9.96, "sd_ppb": 0.81, "kind": "part"},
    {"start": "07:50:00", "end": "07:55:00", "n": 301,
     "mean_ppb": 11.17, "sd_ppb": None, "kind": "recalculated_combined"},
    {"start": "07:59:00", "end": "08:01:00", "n": 120,
     "mean_ppb": 8.61, "sd_ppb": 0.77, "kind": "part"},
]

def pooled_sample_sd(*blocks: dict) -> float:
    """Combine interval sample SDs, including the between-block mean shift.

    The formula uses (n-1)*SD^2 within blocks and the between-block mean
    squared deviations; a simple arithmetic average of SDs would be wrong.
    """
    n_total = sum(int(b["n"]) for b in blocks)
    weighted_mean = sum(int(b["n"]) * float(b["mean_ppb"]) for b in blocks) / n_total
    ss_total = sum((int(b["n"]) - 1) * float(b["sd_ppb"])**2
                   + int(b["n"]) * (float(b["mean_ppb"]) - weighted_mean)**2
                   for b in blocks)
    return math.sqrt(ss_total / (n_total - 1))


DCS_COMBINED_SD_PPB = pooled_sample_sd(*DCS_SCIENTISTS_REPORTED[:2])
DCS_SCIENTISTS_REPORTED[2]["sd_ppb"] = DCS_COMBINED_SD_PPB
DCS_ORIGINAL_COMBINED_SD_PPB = 0.51  # Original note; superseded for this analysis.

MODEL_COLUMNS = {
    "NO2 - NN Tanh (no pressure)": "NO2__NN_tanh_without_pressure",
    "CO - NN ReLU (no pressure)": "CO__NN_relu_without_pressure",
    "O3 - NN GELU (no pressure)": "O3__NN_gelu_without_pressure",
    "O3 - NN Tanh (no pressure)": "O3__NN_tanh_without_pressure",
}
R_D = 287.05
G = 9.80665
BOLTZMANN = 1.380649e-23


def source_file(folder: Path, term: str, suffix: str) -> Path:
    matches = [p for p in folder.iterdir()
               if p.is_file() and p.suffix.lower() == suffix and term.lower() in p.stem.lower()]
    if len(matches) != 1:
        raise FileNotFoundError(
            f"Expected exactly one {suffix} file containing '{term}' in {folder}. "
            f"Found: {[p.name for p in matches]}")
    return matches[0]


def local_window(clock: str) -> pd.Timestamp:
    return pd.Timestamp(f"{DAY} {clock}").tz_localize(LOCAL_TZ)


def local_times(series: pd.Series, naive_tz: str) -> pd.Series:
    parsed = pd.to_datetime(series, errors="coerce", format="mixed")
    if isinstance(parsed.dtype, pd.DatetimeTZDtype):
        return parsed.dt.tz_convert(LOCAL_TZ)
    if not pd.api.types.is_datetime64_any_dtype(parsed.dtype):
        raise ValueError("Mixed timezone-aware and naive reference timestamps")
    return parsed.dt.tz_localize(naive_tz, ambiguous="NaT", nonexistent="NaT").dt.tz_convert(LOCAL_TZ)


def read_drone(folder: Path) -> tuple[pd.DataFrame, Path]:
    file = source_file(folder, "raw_data_drone", ".csv")
    raw = pd.read_csv(file, encoding="utf-8-sig", low_memory=False)
    raw.columns = raw.columns.str.strip().str.lower()
    needed = {"gps_date", "gps_time_utc", "gps_fix", "gps_lat", "gps_lon",
              "pressure_hpa", "temp_c"}
    if missing := needed - set(raw.columns):
        raise ValueError(f"Missing drone columns: {sorted(missing)}")
    timestamps = pd.to_datetime(
        raw.gps_date.astype(str).str.strip() + " " + raw.gps_time_utc.astype(str).str.strip(),
        errors="coerce", utc=True, format="mixed")
    raw["time_utc"] = timestamps
    for column in ("gps_fix", "gps_lat", "gps_lon", "gps_alt_m", "gps_speed_kmh",
                   "gps_hdop", "pressure_hpa", "temp_c", "humidity_percent"):
        if column in raw:
            raw[column] = pd.to_numeric(raw[column], errors="coerce")
    raw = raw.loc[
        raw.time_utc.dt.strftime("%Y-%m-%d").eq(DAY).fillna(False)
        & raw.gps_fix.eq(1)
        & raw.gps_lat.between(-90, 90)
        & raw.gps_lon.between(-180, 180)
    ].sort_values("time_utc").copy()
    raw["time_local"] = raw.time_utc.dt.tz_convert(LOCAL_TZ)
    raw["time_sec_utc"] = raw.time_utc.dt.floor("s")
    duplicate_count = int(raw.time_sec_utc.duplicated().sum())
    if duplicate_count:
        print(f"[NOTE] Dropping {duplicate_count} duplicate 1-second timestamp(s).")
        raw = raw.drop_duplicates("time_sec_utc", keep="first")
    if len(raw) < 100:
        raise ValueError(f"Too few GPS-valid drone records: {len(raw)}")
    return raw, file


def attach_calibrated_models(drone: pd.DataFrame, folder: Path) -> pd.DataFrame:
    file = folder / PREDICTIONS_NAME
    if not file.is_file():
        raise FileNotFoundError(
            f"Missing calibrated prediction file: {file}\n"
            "Place 'selected_calibrated_log009_1s.csv' from the supplied package here. "
            "The raw drone sensors do not contain neural-network weights.")
    p = pd.read_csv(file, sep=";", decimal=",", encoding="utf-8-sig")
    required = {"time_utc", *MODEL_COLUMNS.values()}
    if missing := required - set(p.columns):
        raise ValueError(f"Missing model prediction columns: {sorted(missing)}")
    p["time_sec_utc"] = pd.to_datetime(p.time_utc, errors="coerce", utc=True).dt.floor("s")
    p = p.drop(columns=["time_utc"]).drop_duplicates("time_sec_utc")
    for c in MODEL_COLUMNS.values():
        p[c] = pd.to_numeric(p[c], errors="coerce")
    out = drone.merge(p[["time_sec_utc", *MODEL_COLUMNS.values()]],
                      on="time_sec_utc", how="left", validate="one_to_one")
    out["time_local"] = out.time_sec_utc.dt.tz_convert(LOCAL_TZ)
    missing = out[list(MODEL_COLUMNS.values())].isna().all(axis=1).sum()
    print(f"[DRONE] {len(out)} observed GPS seconds; {missing} without model predictions")
    return out.sort_values("time_sec_utc").reset_index(drop=True)


def read_doas(folder: Path) -> tuple[pd.DataFrame, Path]:
    file = source_file(folder, "LPDOAS Church", ".csv")
    raw = pd.read_csv(file, encoding="utf-8-sig")
    raw.columns = raw.columns.str.strip().str.lower()
    if not {"time", "no2_church_ppb"}.issubset(raw):
        raise ValueError("Expected DOAS columns time, no2_church_ppb")
    df = pd.DataFrame({"time_local": local_times(raw.time, LPDOAS_NAIVE_TZ)})
    cleaned = raw.no2_church_ppb.astype(str).str.replace(
        r"\s*ppb\s*", "", regex=True, case=False).str.strip()
    df["LPDOAS_NO2_ppb"] = pd.to_numeric(cleaned, errors="coerce")
    df["time_utc"] = df.time_local.dt.tz_convert("UTC")
    return df.dropna(subset=["time_local"]).sort_values("time_local"), file


class _TimeArrayUnpickler(pickle.Unpickler):
    """Restrict legacy NPZ object timestamp deserialization."""
    def find_class(self, module, name):
        module_name = "numpy._core.multiarray" if int(np.__version__.split(".")[0]) >= 2 else "numpy.core.multiarray"
        multiarray = importlib.import_module(module_name)
        safe = {
            ("numpy._core.multiarray", "_reconstruct"): multiarray._reconstruct,
            ("numpy.core.multiarray", "_reconstruct"): multiarray._reconstruct,
            ("numpy", "ndarray"): np.ndarray,
            ("numpy", "dtype"): np.dtype,
            ("datetime", "datetime"): dt.datetime,
        }
        if (module, name) not in safe:
            raise pickle.UnpicklingError(f"Unexpected object in DCS time array: {module}.{name}")
        return safe[(module, name)]


def load_dcs_time_npy(blob: bytes) -> np.ndarray:
    from numpy.lib import format as fmt
    stream = io.BytesIO(blob)
    version = fmt.read_magic(stream)
    if version == (1, 0):
        shape, _, dtype = fmt.read_array_header_1_0(stream)
    elif version == (2, 0):
        shape, _, dtype = fmt.read_array_header_2_0(stream)
    else:
        raise ValueError(f"Unsupported DCS .npy timestamp format: {version}")
    stream.seek(0)
    if not dtype.hasobject:
        return np.load(stream, allow_pickle=False)
    # NPY payload follows header. Use a tightly restricted unpickler here.
    stream = io.BytesIO(blob)
    _ = fmt.read_magic(stream)
    if version == (1, 0):
        fmt.read_array_header_1_0(stream)
    else:
        fmt.read_array_header_2_0(stream)
    time_values = _TimeArrayUnpickler(stream).load()
    if not isinstance(time_values, np.ndarray) or time_values.shape != shape:
        raise ValueError("Invalid DCS time array")
    if len(time_values) and not isinstance(time_values.flat[0], dt.datetime):
        raise ValueError("Expected datetime values in DCS time array")
    return time_values


def read_dcs(folder: Path) -> tuple[pd.DataFrame, Path]:
    file = source_file(folder, "NO2_Voigt", ".npz")
    with zipfile.ZipFile(file) as archive:
        stamp = load_dcs_time_npy(archive.read("time.npy"))
        fits = np.load(io.BytesIO(archive.read("results.npy")), allow_pickle=False)
        power = np.load(io.BytesIO(archive.read("power.npy")), allow_pickle=False)
        stretch = np.load(io.BytesIO(archive.read("stretch.npy")), allow_pickle=False)
    if fits.ndim != 2 or len(stamp) != len(fits) or len(power) != len(fits):
        raise ValueError("Unexpected DCS result dimensions")
    ts = local_times(pd.Series(stamp), DCS_NAIVE_TZ)
    dcs = pd.DataFrame({"time_local": ts,
                        "time_utc": ts.dt.tz_convert("UTC"),
                        "DCS_power_raw": power,
                        "DCS_stretch_raw": stretch})
    for i in range(fits.shape[1]):
        dcs[f"DCS_Voigt_fit_parameter_{i}_unverified"] = pd.to_numeric(fits[:, i], errors="coerce")
    if DCS_PARAM0_CONFIRMED_MOLEC_CM3:
        # molecules/cm3 -> ppb: 1e9 * density / ambient molecules/cm3
        air_number_density_cm3 = DCS_FIT_P_HPA * 100.0 / (BOLTZMANN * DCS_FIT_T_K) / 1e6
        dcs["DCS_NO2_ppb_assuming_confirmed_density"] = (
            dcs["DCS_Voigt_fit_parameter_0_unverified"] * 1e9 / air_number_density_cm3)
    return dcs.dropna(subset=["time_local"]).sort_values("time_local"), file


def window_slice(df: pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp) -> pd.DataFrame:
    return df.loc[(df.time_local >= start) & (df.time_local < end)].copy()


def stats(series: pd.Series) -> dict:
    s = pd.to_numeric(series, errors="coerce")
    s = s[np.isfinite(s)]
    return dict(n=int(len(s)), mean=float(s.mean()) if len(s) else np.nan,
                median=float(s.median()) if len(s) else np.nan,
                std=float(s.std(ddof=1)) if len(s) > 1 else np.nan,
                min=float(s.min()) if len(s) else np.nan,
                max=float(s.max()) if len(s) else np.nan,
                negatives=int((s < 0).sum()))


def annotate_segments(drone: pd.DataFrame) -> pd.DataFrame:
    out = drone.copy()
    out["flight"] = "Outside flight"
    out["leg"] = "Not classified"
    out["return_complete"] = pd.NA
    for flight, leg, st, en, complete in WINDOWS:
        mask = (out.time_local >= local_window(st)) & (out.time_local < local_window(en))
        out.loc[mask, "flight"] = flight
        out.loc[mask, "leg"] = leg
        out.loc[mask, "return_complete"] = complete
    return out


def no2_to_ppb(df: pd.DataFrame) -> pd.Series:
    x = pd.to_numeric(df[MODEL_COLUMNS["NO2 - NN Tanh (no pressure)"]], errors="coerce")
    if DRONE_NO2_UNIT == "ppb":
        return x
    if DRONE_NO2_UNIT == "ug/m3":
        # NO2 molecular weight 46.0055 g/mol, pressure from drone.
        T = pd.to_numeric(df.temp_c, errors="coerce") + 273.15
        P = pd.to_numeric(df.pressure_hpa, errors="coerce") * 100
        return x * 1000 * 8.314462618 * T / (46.0055 * P)
    return pd.Series(np.nan, index=df.index, dtype=float)


def dcs_scientists_summary_table() -> pd.DataFrame:
    """Scientists' time blocks, using recomputed pooled SD for Flight 1 total."""
    rows = []
    for rec in DCS_SCIENTISTS_REPORTED:
        rows.append({
            "date": DAY,
            "start_CEST": rec["start"], "end_CEST": rec["end"],
            "time_window_CEST": f'{rec["start"][:5]}-{rec["end"][:5]}',
            "n_reported": rec["n"],
            "DCS_scientists_NO2_mean_ppb": rec["mean_ppb"],
            "DCS_scientists_NO2_SD_ppb": rec["sd_ppb"],
            "kind": rec["kind"],
            "SD_method": ("Pooled sample SD from two reported subintervals"
                          if rec["kind"] == "recalculated_combined" else
                          "Researchers' reported interval sample SD"),
            "original_combined_SD_ppb_not_used": (
                DCS_ORIGINAL_COMBINED_SD_PPB
                if rec["kind"] == "recalculated_combined" else np.nan),
            "note": ("Combined SD recalculated from n=180 and n=121 "
                     "and the between-block mean difference"
                     if rec["kind"] == "recalculated_combined" else "")
        })
    return pd.DataFrame(rows)


def dcs_scientists_overlap(start: pd.Timestamp, end: pd.Timestamp) -> dict:
    """Map reported DCS blocks onto segment windows conservatively.

    The overlap-weighted mean is a *proxy*, assuming each reported block mean
    represents its entire block. It is NOT a measured mean from matching raw
    timestamps. A source SD is only displayed if one single source block is
    involved; it remains that full source block's SD, NOT a segment-specific SD.
    """
    overlaps = []
    for item in DCS_SCIENTISTS_REPORTED:
        if item["kind"] != "part":
            continue
        lo = max(start, local_window(item["start"]))
        hi = min(end, local_window(item["end"]))
        seconds = max(0.0, (hi - lo).total_seconds())
        if seconds > 0:
            overlaps.append((item, seconds))
    observed_s = sum(seconds for item, seconds in overlaps)
    window_s = (end - start).total_seconds()
    approx_mean = (sum(item["mean_ppb"] * seconds for item, seconds in overlaps) / observed_s
                   if observed_s else np.nan)
    sd_single_source = overlaps[0][0]["sd_ppb"] if len(overlaps) == 1 else np.nan
    original_windows = ", ".join(
        f'{item["start"][:5]}-{item["end"][:5]}' for item, _ in overlaps
    )
    return {
        "DCS_scientists_NO2_overlap_proxy_mean_ppb": approx_mean,
        "DCS_scientists_SD_ppb_source_window_only": sd_single_source,
        "DCS_scientists_overlap_seconds": observed_s,
        "DCS_scientists_segment_seconds": window_s,
        "DCS_scientists_coverage_fraction": observed_s / window_s if window_s else np.nan,
        "DCS_scientists_source_windows_CEST": original_windows,
        "DCS_scientists_overlap_method": (
            "no DCS scientists data for this segment" if not overlaps else
            "single source block: mean/SD belong to full source block, not exact leg" if len(overlaps) == 1 else
            "overlap-weighted approximation; segment-specific SD unavailable"
        ),
    }


def dcs_scientists_overlap_details() -> pd.DataFrame:
    rows = []
    for flight, leg, st, en, complete in WINDOWS:
        t0, t1 = local_window(st), local_window(en)
        for item in DCS_SCIENTISTS_REPORTED:
            if item["kind"] != "part":
                continue
            seconds = max(0.0, (min(t1, local_window(item["end"])) -
                                 max(t0, local_window(item["start"]))).total_seconds())
            if seconds:
                rows.append({
                    "segment": f"{flight} - {leg}",
                    "segment_start_CEST": st, "segment_end_CEST": en,
                    "DCS_source_start_CEST": item["start"],
                    "DCS_source_end_CEST": item["end"],
                    "DCS_source_n": item["n"],
                    "DCS_source_mean_ppb": item["mean_ppb"],
                    "DCS_source_SD_ppb": item["sd_ppb"],
                    "overlap_seconds": seconds,
                    "fraction_of_segment": seconds / (t1-t0).total_seconds(),
                    "note": "Source statistics are for full source block, not overlap samples"
                })
    return pd.DataFrame(rows)


def load_drone_no2_rmse() -> tuple[float | None, str]:
    """Get the matching held-out test RMSE from the calibration output file.

    An RMSE from any other instrument, gas, architecture or data split is
    deliberately rejected. Original target/model units are retained.
    """
    if DRONE_NO2_MODEL_RMSE_ORIGINAL_UNITS is not None:
        value = safe_uncertainty(DRONE_NO2_MODEL_RMSE_ORIGINAL_UNITS)
        return value, "Manually verified model test RMSE override"
    candidates = [CALIBRATION_METRICS_CSV,
                  DATA_DIR / "results_calibration" / "all_model_metrics.csv"]
    matches = [p for p in candidates if p.is_file()]
    if not matches:
        return None, ("Calibration metrics not found. First run calibration_paris_english.py "
                      "for gas_drone / NO2 / NN_tanh_without_pressure; "
                      "output: results_calibration/all_model_metrics.csv")
    path = matches[0]
    metrics = pd.read_csv(path, sep=";", decimal=",", encoding="utf-8-sig")
    filters = {"instrument": CALIBRATION_INSTRUMENT,
               "pollutant": CALIBRATION_POLLUTANT,
               "model": CALIBRATION_MODEL,
               "phase": CALIBRATION_PHASE}
    required = set(filters) | {"RMSE"}
    if not required.issubset(metrics.columns):
        raise ValueError(f"Metrics file {path} is missing: {sorted(required - set(metrics))}")
    selected = metrics.copy()
    for column, expected in filters.items():
        selected = selected.loc[selected[column].astype(str).str.strip().eq(expected)]
    if len(selected) != 1:
        return None, (f"Found {len(selected)} exact test metric rows in {path}; "
                      "expected one (gas_drone/NO2/NN_tanh_without_pressure/test).")
    rmse = pd.to_numeric(selected.iloc[0]["RMSE"], errors="coerce")
    if not np.isfinite(rmse) or rmse < 0:
        return None, f"Matching RMSE is missing or invalid in {path}"
    return float(rmse), f"{path} | gas_drone/NO2/NN_tanh_without_pressure/test"


def safe_uncertainty(val) -> float:
    """Validate an optional externally supplied RMSE in model output units."""
    if val is None:
        return np.nan
    value = float(val)
    if not np.isfinite(value) or value < 0:
        raise ValueError("DRONE_NO2_MODEL_RMSE_ORIGINAL_UNITS must be finite and >= 0")
    return value


def describe_flights(drone: pd.DataFrame, doas: pd.DataFrame,
                     dcs: pd.DataFrame, drone_rmse: float | None = None,
                     rmse_source: str = "not available") -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    gas_rows, comparisons, dcs_fits = [], [], []
    selected = [(a, b, c, d, e) for a, b, c, d, e in WINDOWS]
    for flight in ("Flight 1", "Flight 2"):
        parts = [entry for entry in selected if entry[0] == flight]
        start = local_window(parts[0][2]); end = local_window(parts[-1][3])
        groups = [(flight + " - Outbound", local_window(parts[0][2]), local_window(parts[0][3])),
                  (flight + " - Return", local_window(parts[1][2]), local_window(parts[1][3])),
                  (flight + " - Combined", start, end)]
        for group_name, t0, t1 in groups:
            d = window_slice(drone, t0, t1)
            ref = window_slice(doas, t0, t1)
            v = window_slice(dcs, t0, t1)
            full = not (flight == "Flight 2" and ("Return" in group_name or "Combined" in group_name))
            for model_label, col in MODEL_COLUMNS.items():
                st = stats(d[col]); gas_rows.append({
                    "segment": group_name, "flight_complete": full, "model": model_label,
                    "unit": "original calibration reference units (not verified)",
                    "start_local_CEST": t0.isoformat(), "end_exclusive_local_CEST": t1.isoformat(),
                    "window_duration_s": int((t1-t0).total_seconds()),
                    "available_drone_seconds": len(d), **st})
            # LP-DOAS: compute only the arithmetic mean and the observation count.
            # No standard deviation, RMSE, or error estimate is calculated.
            lpdoas_valid = pd.to_numeric(ref.LPDOAS_NO2_ppb, errors="coerce")
            lpdoas_valid = lpdoas_valid[np.isfinite(lpdoas_valid)]
            lpdoas_mean = float(lpdoas_valid.mean()) if len(lpdoas_valid) else np.nan
            lpdoas_n = len(lpdoas_valid)
            drone_s = stats(d[MODEL_COLUMNS["NO2 - NN Tanh (no pressure)"]])
            v_s = stats(v.DCS_Voigt_fit_parameter_0_unverified)
            ppb_s = stats(no2_to_ppb(d))
            record = {
                "segment": group_name, "flight_complete": full,
                "start_local_CEST": t0.isoformat(), "end_exclusive_local_CEST": t1.isoformat(),
                "drone_NO2_NN_Tanh_mean_original_units": drone_s["mean"],
                "drone_NO2_model_test_RMSE_original_units": safe_uncertainty(drone_rmse),
                "drone_NO2_model_RMSE_source": rmse_source,
                "drone_NO2_error_type": "gas_drone held-out test RMSE; not flight-specific",
                "drone_NO2_valid_seconds": drone_s["n"],
                "drone_NO2_confirmed_unit": DRONE_NO2_UNIT,
                "drone_NO2_mean_ppb_if_confirmed": ppb_s["mean"],
                "LPDOAS_NO2_mean_ppb": lpdoas_mean,
                "LPDOAS_valid_measurements": lpdoas_n,
                "DCS_Voigt_fit_parameter_0_mean_unverified": v_s["mean"],
                "DCS_Voigt_fit_parameter_0_SD_unverified": v_s["std"],
                "DCS_Voigt_valid_measurements": v_s["n"],
                "DCS_fit_parameter_units_confirmed": DCS_PARAM0_CONFIRMED_MOLEC_CM3,
                **dcs_scientists_overlap(t0, t1),
                # The reported 07:50-07:55 block is a separate, overlapping
                # summary, and ends 5 s before Flight 1 officially ends.
                "DCS_scientists_F1_combined_mean_ppb": (11.17 if group_name == "Flight 1 - Combined" else np.nan),
                "DCS_scientists_F1_combined_SD_pooled_ppb": (
                    DCS_COMBINED_SD_PPB if group_name == "Flight 1 - Combined" else np.nan),
                "DCS_scientists_F1_combined_n": (301 if group_name == "Flight 1 - Combined" else np.nan),
            }
            if np.isfinite(ppb_s["mean"]) and np.isfinite(lpdoas_mean):
                record["Drone_minus_LPDOAS_ppb"] = ppb_s["mean"] - lpdoas_mean
                record["Drone_minus_LPDOAS_percent"] = 100 * (ppb_s["mean"]-lpdoas_mean)/lpdoas_mean if lpdoas_mean else np.nan
            else:
                record["Drone_minus_LPDOAS_ppb"] = np.nan
                record["Drone_minus_LPDOAS_percent"] = np.nan
            if DCS_PARAM0_CONFIRMED_MOLEC_CM3:
                record["DCS_NO2_mean_ppb_if_confirmed"] = stats(v.DCS_NO2_ppb_assuming_confirmed_density)["mean"]
            comparisons.append(record)
            for col in (c for c in v if c.startswith("DCS_Voigt_fit_parameter_") or c in ("DCS_power_raw", "DCS_stretch_raw")):
                dcs_fits.append({"segment": group_name, "parameter": col,
                                 "unit": "unverified raw fit parameter", **stats(v[col])})
    return pd.DataFrame(gas_rows), pd.DataFrame(comparisons), pd.DataFrame(dcs_fits)


def plot_time_series(drone: pd.DataFrame, doas: pd.DataFrame,
                     dcs: pd.DataFrame, output: Path) -> None:
    plt.rcParams.update({"font.size": 10})
    for flight in ("Flight 1", "Flight 2"):
        segment = drone.loc[drone.flight.eq(flight)].copy()
        if segment.empty:
            continue
        begin, end = segment.time_local.min(), segment.time_local.max() + pd.Timedelta(seconds=1)
        doas_seg = window_slice(doas, begin, end)
        dcs_seg = window_slice(dcs, begin, end)
        turn_time = local_window("07:52:55" if flight == "Flight 1" else "08:01:20")
        fig, axes = plt.subplots(3, 1, figsize=(12, 10), sharex=True)
        no2 = MODEL_COLUMNS["NO2 - NN Tanh (no pressure)"]
        axes[0].plot(segment.time_local, segment[no2], lw=1.4, label="Gas box for drone")
        ax_ref = axes[0].twinx()
        ax_ref.scatter(doas_seg.time_local, doas_seg.LPDOAS_NO2_ppb, marker="o",
                       s=34, color="tab:red", label="LP-DOAS", zorder=4)
        # Scientists' processed DCS NO2 ppb: horizontal block means and +-SD bands.
        # Do NOT display the overlapping 07:50-07:55 combined report as another block.
        first_researcher_block = True
        for src in (item for item in DCS_SCIENTISTS_REPORTED if item["kind"] == "part"):
            s0, s1 = local_window(src["start"]), local_window(src["end"])
            if min(end, s1) <= max(begin, s0):
                continue
            xs = [max(begin, s0), min(end, s1)]
            ax_ref.plot(xs, [src["mean_ppb"]]*2, lw=2.2, color="tab:blue",
                        label="SP DCS (mean ± SD)" if first_researcher_block else "_nolegend_", zorder=3)
            ax_ref.fill_between(xs, [src["mean_ppb"]-src["sd_ppb"]]*2,
                                [src["mean_ppb"]+src["sd_ppb"]]*2,
                                color="tab:blue", alpha=.13,
                                label="_nolegend_" if first_researcher_block else "_nolegend_")
            first_researcher_block = False
        axes[0].set_ylabel("Drone NO2 (units unconfirmed)")
        ax_ref.set_ylabel("LP-DOAS NO2 (ppb)", color="tab:red")
        h1, l1 = axes[0].get_legend_handles_labels()
        h2, l2 = ax_ref.get_legend_handles_labels()
        axes[0].legend(h1+h2, l1+l2, loc="upper left", fontsize=8)
        axes[1].plot(dcs_seg.time_local, dcs_seg.DCS_Voigt_fit_parameter_0_unverified,
                     lw=0.95, color="tab:purple", label="Voigt/DCS fit parameter 0 (unit unverified)")
        axes[1].set_ylabel("Raw Voigt fit parameter 0")
        axes[1].legend(loc="upper left", fontsize=8)
        for k, label in [("CO - NN ReLU (no pressure)", "CO - ReLU"),
                         ("O3 - NN GELU (no pressure)", "O3 - GELU"),
                         ("O3 - NN Tanh (no pressure)", "O3 - Tanh")]:
            y = segment[MODEL_COLUMNS[k]].astype(float)
            # CO is a different original concentration scale, so use separate axis.
            target = axes[2].twinx() if k.startswith("CO") else axes[2]
            if k.startswith("CO"):
                target.plot(segment.time_local, y, color="tab:green", lw=1.0, alpha=.85, label=label)
                target.set_ylabel("CO (original units)", color="tab:green")
            else:
                target.plot(segment.time_local, y, lw=1.2, label=label)
        axes[2].set_ylabel("O3 (original units)")
        axes[2].legend(loc="upper left", fontsize=8)
        for ax in axes:
            ax.axvline(turn_time, color="gray", ls="--", lw=1)
            ax.grid(alpha=0.22)
        axes[-1].xaxis.set_major_formatter(mdates.DateFormatter("%H:%M:%S", tz=segment.time_local.dt.tz))
        axes[-1].set_xlabel("Local time in Munich (CEST, UTC+2)")
        status = "complete" if flight == "Flight 1" else "incomplete return (crash)"
        fig.suptitle(f"Munich | {flight} ({status}) - calibrated drone and optical NO2")
        fig.tight_layout()
        name = flight.lower().replace(" ", "_")
        fig.savefig(output / f"{name}_time_series.png", dpi=170)
        plt.close(fig)



def plot_no2_comparison_single_panel(drone: pd.DataFrame, doas: pd.DataFrame,
                                     output: Path,
                                     drone_rmse: float | None = None) -> None:
    """Slide-ready one-panel flight plot with shortened legend and no footer.

    This ADDITIONAL plot does not change any measurements, calibrations, or
    summary calculations. Display-only LP-DOAS +/-1 ppb is inherited from
    the original comparison figure; it is ASSIGNED, not source uncertainty.
    A calibration TEST RMSE is diagnostic, not a flight-specific confidence
    interval. Scientists' processed DCS block statistics are used (not raw fits).
    """
    no2_col = MODEL_COLUMNS["NO2 - NN Tanh (no pressure)"]
    for flight in ("Flight 1", "Flight 2"):
        legs = [row for row in WINDOWS if row[0] == flight]
        segment = drone.loc[drone.flight.eq(flight)].sort_values("time_local")
        if segment.empty:
            continue
        begin, end = local_window(legs[0][2]), local_window(legs[-1][3])
        turn = local_window(legs[0][3])
        df_doas = window_slice(doas, begin, end)
        fig, ax = plt.subplots(figsize=(15.5, 6.3))
        ax.plot(segment.time_local, segment[no2_col], color="forestgreen",
                linewidth=1.55, label="Gas box for drone", zorder=3)
        ax.axvline(turn, color="#777777", linestyle="--", linewidth=1.0,
                   label="Turnaround", zorder=1)

        # Measured variation within each moving-drone leg.
        sample_label_done = False
        rmse_label_done = False
        for _, leg, start_time, end_time, _ in legs:
            subset = window_slice(segment, local_window(start_time), local_window(end_time))
            values = pd.to_numeric(subset[no2_col], errors="coerce").dropna()
            if values.empty:
                continue
            midpoint = local_window(start_time) + (local_window(end_time) - local_window(start_time)) / 2
            mean = float(values.mean())
            sd = float(values.std(ddof=1)) if len(values) > 1 else 0.0
            ax.errorbar(midpoint, mean, yerr=sd, fmt="o", color="#00694c",
                        capsize=4, markersize=6, linewidth=1.5, zorder=6,
                        label="Gas box: leg mean ± sample SD" if not sample_label_done else "_nolegend_")
            sample_label_done = True
            if drone_rmse is not None and np.isfinite(drone_rmse):
                # Held-out Mandria TEST RMSE; not an error on the flight mean.
                ax.errorbar(midpoint + pd.Timedelta(seconds=18), mean,
                            yerr=float(drone_rmse), fmt="s", mfc="white", mec="#73b784",
                            ecolor="#73b784", capsize=4, markersize=6,
                            linewidth=1.5, zorder=5,
                            label=(f"Gas box: leg mean ± test RMSE ({drone_rmse:.2f})"
                                   if not rmse_label_done else "_nolegend_"))
                rmse_label_done = True

        # LP-DOAS points: +/-1 ppb is ONLY a display assignment from the
        # earlier graphic. The input file does not provide uncertainties.
        valid_doas = df_doas.loc[np.isfinite(pd.to_numeric(df_doas.LPDOAS_NO2_ppb, errors="coerce"))]
        if not valid_doas.empty:
            ax.errorbar(valid_doas.time_local, valid_doas.LPDOAS_NO2_ppb,
                        yerr=np.ones(len(valid_doas)), fmt="o", color="tab:red",
                        ecolor="tab:red", capsize=3, markersize=5,
                        linewidth=1.0, linestyle="none", label="LP-DOAS", zorder=6)

        # Spectroscopy: processed NO2 summaries in ppb supplied by TU Graz.
        sp_label_done = False
        for rec in DCS_SCIENTISTS_REPORTED:
            if rec["kind"] != "part":
                continue
            st, en = local_window(rec["start"]), local_window(rec["end"])
            if min(end, en) <= max(begin, st):
                continue
            midpoint = max(begin, st) + (min(end, en) - max(begin, st)) / 2
            ax.errorbar(midpoint, rec["mean_ppb"], yerr=rec["sd_ppb"],
                        fmt="D", markersize=6, color="tab:blue", capsize=4,
                        linewidth=1.7, label="SP DCS (mean ± SD)" if not sp_label_done else "_nolegend_",
                        zorder=7)
            sp_label_done = True

        status = "complete" if flight == "Flight 1" else "incomplete return"
        ax.set_title(f"NO₂ Comparison | Munich | 21 October 2026 | {flight} ({status})",
                     fontsize=15, pad=78)
        ax.set_ylabel("NO₂ concentration (ppb)")
        ax.set_xlabel("Munich local time (CEST, UTC+2)")
        ax.grid(alpha=.22)
        ax.set_xlim(begin, end)
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M:%S", tz=LOCAL_TZ))
        ax.legend(loc="lower center", bbox_to_anchor=(.5, 1.01), ncol=3,
                  frameon=True, fontsize=9)
        ax.spines[["top", "right"]].set_visible(False)
        # No fig.text or other footer: the grey explanatory line is omitted.
        fig.tight_layout()
        filename = flight.lower().replace(" ", "_") + "_NO2_comparison_clean.png"
        fig.savefig(output / filename, dpi=220, bbox_inches="tight")
        plt.close(fig)
        print(f"[PLOT] Clean NO2 comparison: {output / filename}")


def plot_spatial_3d(drone: pd.DataFrame, output: Path) -> None:
    for flight in ("Flight 1", "Flight 2"):
        df = drone.loc[drone.flight.eq(flight)].copy()
        if df.empty: continue
        lat0, lon0 = float(df.gps_lat.iloc[0]), float(df.gps_lon.iloc[0])
        x = (df.gps_lon.to_numpy()-lon0)*np.pi/180*6371008.8*np.cos(lat0*np.pi/180)
        y = (df.gps_lat.to_numpy()-lat0)*np.pi/180*6371008.8
        p0 = float(df.pressure_hpa.iloc[0])
        t0 = float(df.temp_c.iloc[0])+273.15
        T = df.temp_c.to_numpy(float)+273.15
        pres = df.pressure_hpa.to_numpy(float)
        z = np.where((pres>0) & np.isfinite(pres) & np.isfinite(T),
                     R_D/G*(t0+T)/2*np.log(p0/pres), np.nan)
        no2 = pd.to_numeric(df[MODEL_COLUMNS["NO2 - NN Tanh (no pressure)"]],errors="coerce").to_numpy()
        mask = np.isfinite(x)&np.isfinite(y)&np.isfinite(z)&np.isfinite(no2)
        fig = plt.figure(figsize=(11,7.5))
        ax=fig.add_subplot(111,projection="3d")
        ax.plot(x[mask],y[mask],z[mask],color="gray",alpha=.45,lw=.8)
        points=ax.scatter(x[mask],y[mask],z[mask],c=no2[mask],cmap="viridis",s=12)
        ax.set(xlabel="East (m)",ylabel="North (m)",zlabel="Relative pressure-derived height (m)")
        fig.colorbar(points,ax=ax,shrink=.67,pad=.08,label="Drone NO2 - NN Tanh (original units)")
        ax.set_title(f"Munich {flight} | NO2 spatial profile (3D + concentration color)")
        fig.tight_layout()
        fig.savefig(output/(flight.lower().replace(" ","_")+"_NO2_4D_preview.png"),dpi=160)
        plt.close(fig)


def create_offline_4d_html(drone: pd.DataFrame, output: Path) -> None:
    """Offline browser animation: east/north/relative pressure height + color, time playback."""
    from plotly.offline import get_plotlyjs
    plotly_js = get_plotlyjs()
    for flight in ("Flight 1", "Flight 2"):
        sub = drone.loc[drone.flight.eq(flight)].copy().sort_values("time_local")
        if sub.empty: continue
        origin_lat,origin_lon=float(sub.gps_lat.iloc[0]),float(sub.gps_lon.iloc[0])
        x=(sub.gps_lon.to_numpy(float)-origin_lon)*np.pi/180*6371008.8*np.cos(origin_lat*np.pi/180)
        y=(sub.gps_lat.to_numpy(float)-origin_lat)*np.pi/180*6371008.8
        T=sub.temp_c.to_numpy(float)+273.15
        p=sub.pressure_hpa.to_numpy(float)
        z=R_D/G*(T[0]+T)/2*np.log(p[0]/p)
        model_data={
            "x": x.round(3).tolist(), "y": y.round(3).tolist(), "z": z.round(3).tolist(),
            "time":sub.time_local.dt.strftime("%H:%M:%S").tolist(),
            "leg":sub.leg.tolist(),
            "NO2":sub[MODEL_COLUMNS["NO2 - NN Tanh (no pressure)"]].round(7).replace({np.nan:None}).tolist(),
            "CO":sub[MODEL_COLUMNS["CO - NN ReLU (no pressure)"]].round(7).replace({np.nan:None}).tolist(),
            "O3_GELU":sub[MODEL_COLUMNS["O3 - NN GELU (no pressure)"]].round(7).replace({np.nan:None}).tolist(),
            "O3_TANH":sub[MODEL_COLUMNS["O3 - NN Tanh (no pressure)"]].round(7).replace({np.nan:None}).tolist(),
        }
        # Replace any nonfinite float with null, since JSON forbids NaN.
        for key,val in model_data.items():
            if key in {"x","y","z"}:
                model_data[key]=[None if not np.isfinite(v) else v for v in val]
        title = "Munich " + flight + (" - complete" if flight == "Flight 1" else " - incomplete return (crash)")
        template = r'''<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>__TITLE__ | Interactive 4D flight</title>
<style>
body{background:#0c1524;color:#ebf3ff;font:14px system-ui,Arial;margin:0}
header{padding:20px 24px;border-bottom:1px solid #304761}
h1{font-size:22px;margin:0 0 8px}.meta{color:#b0c3d7}
.controls{display:flex;flex-wrap:wrap;gap:12px;align-items:end;padding:18px 24px;background:#14243b}
.controls>label{display:flex;flex-direction:column;gap:5px}button,select{background:#1d3a55;color:white;border:1px solid #617a9b;border-radius:7px;padding:8px 14px;cursor:pointer}
input[type=range]{min-width:200px;flex:1;accent-color:#36c6bd}
main{padding:12px 18px;display:grid;grid-template-columns:3fr 1fr;gap:16px}
#plot{height:74vh;min-height:440px}.side{background:#14243b;border:1px solid #304761;padding:15px;border-radius:12px}
#profile{height:300px}.note{line-height:1.55;color:#b0c3d7}
@media(max-width:900px){main{grid-template-columns:1fr}}
</style></head><body><header><h1>__TITLE__ | Interactive 4D drone profile</h1>
<div class="meta">East / North / pressure-derived relative height + concentration color; observed seconds only, no interpolation.</div></header>
<div class="controls">
<label>Pollutant / model<select id="gas"><option value="NO2">NO2 - NN Tanh, no pressure</option><option value="CO">CO - NN ReLU, no pressure</option><option value="O3_GELU">O3 - NN GELU, no pressure</option><option value="O3_TANH">O3 - NN Tanh, no pressure</option></select></label>
<button id="play">Play</button><button id="all">Show entire flight</button>
<input id="timeline" type="range" min="1" max="__N__" value="__N__" step="1" aria-label="Time cursor">
<span id="status"></span><label>Playback speed<select id="speed"><option value="1">1x</option><option value="10">10x</option><option value="20" selected>20x</option><option value="40">40x</option><option value="80">80x</option></select></label></div>
<main><section id="plot"></section><aside class="side"><b>NO2 model: NN Tanh WITHOUT pressure</b>
<p id="sample">Click a point in the 3D plot for its timestamp and concentration.</p>
<div id="profile"></div><p class="note">Flight 2 ends at the user-estimated stop before/at the crash. Relative height is calculated from sensor pressure and temperature using the hypsometric approximation and referenced to the first displayed flight point, not ground elevation.</p>
<p class="note">Important: NN predictions are exploratory outside the original calibration domain. Drone concentration units and DCS fit parameter units must be verified separately; this HTML contains only drone measurements.</p></aside></main>
<script>__PLOTLY__</script><script>
const D=__DATA__;
let end=D.time.length,timer=null;
const q=id=>document.getElementById(id);
function valList(name,ids){return ids.map(i=>D[name][i]);}
function render(){const gas=q('gas').value;const ids=Array.from({length:end},(_,i)=>i);
let v=valList(gas,ids),finite=D[gas].filter(x=>x!==null&&Number.isFinite(x));
let low=Math.min(...finite),high=Math.max(...finite);
const pts={type:'scatter3d',mode:'markers',x:valList('x',ids),y:valList('y',ids),z:valList('z',ids),customdata:ids,
marker:{size:4,color:v,colorscale:'Viridis',cmin:low,cmax:high,showscale:true,colorbar:{title:{text:gas+' (original units)'}}},
hovertemplate:'East %{x:.1f} m<br>North %{y:.1f} m<br>Relative height %{z:.1f} m<br>Concentration %{marker.color:.3f}<extra></extra>'};
const route={type:'scatter3d',mode:'lines',x:valList('x',ids),y:valList('y',ids),z:valList('z',ids),line:{color:'#a0b2c9',width:2},hoverinfo:'skip',showlegend:false};
const layout={paper_bgcolor:'#0c1524',font:{color:'#eaf0fb'},margin:{l:2,r:2,b:0,t:0},
scene:{xaxis:{title:'East (m)'},yaxis:{title:'North (m)'},zaxis:{title:'Relative pressure height (m)'},aspectmode:'data'},uirevision:'samecamera'};
Plotly.react('plot',[route,pts],layout,{responsive:true,scrollZoom:true,displaylogo:false});
const profile={type:'scattergl',mode:'markers',x:v,y:valList('z',ids),marker:{size:5,color:v,colorscale:'Viridis',showscale:false},hovertemplate:gas+': %{x:.3f}<br>Height: %{y:.1f} m<extra></extra>'};
Plotly.react('profile',[profile],{paper_bgcolor:'#14243b',plot_bgcolor:'#14243b',font:{color:'#eaf0fb'},margin:{l:50,r:8,b:50,t:25},xaxis:{title:gas+' (original units)'},yaxis:{title:'Relative height (m)'}},{responsive:true,displaylogo:false});
q('status').textContent=end+'/'+D.time.length+' | '+D.time[end-1]+' CEST | '+D.leg[end-1];
const plot=q('plot');if(!plot._listenerDone){plot.on('plotly_click',e=>{const pt=e.points.find(p=>p.curveNumber===1);if(!pt)return;let i=pt.customdata;
q('sample').textContent='Time: '+D.time[i]+' CEST | '+D.leg[i]+' | '+gas+': '+D[gas][i]+' (original units)';});plot._listenerDone=true;}}
q('gas').onchange=render;
q('timeline').oninput=()=>{end=Number(q('timeline').value);render()};
q('all').onclick=()=>{stop();end=D.time.length;q('timeline').value=end;render()};
function stop(){if(timer!==null){clearInterval(timer);timer=null}q('play').textContent='Play'}
q('play').onclick=()=>{if(timer!==null){stop();return}if(end>=D.time.length){end=1;q('timeline').value=end}q('play').textContent='Pause';
timer=setInterval(()=>{end=Math.min(D.time.length,end+Number(q('speed').value));q('timeline').value=end;render();if(end>=D.time.length)stop()},200)};
render();
</script></body></html>'''
        content = template.replace("__TITLE__", title).replace("__N__",str(len(sub)))
        content = content.replace("__PLOTLY__",plotly_js).replace("__DATA__",json.dumps(model_data,allow_nan=False,separators=(",",":")))
        (output/(flight.lower().replace(" ","_")+"_interactive_4D.html")).write_text(content,encoding="utf-8")


def fmt_value_and_error(mean, error, decimals=2, scientific=False):
    if not np.isfinite(mean):
        return "n.a."
    formatting = f"{{:.2e}}" if scientific else f"{{:.{decimals}f}}"
    m = formatting.format(mean)
    return m + (" +/- " + formatting.format(error) if np.isfinite(error) else " (error n.a.)")


def show_segment_summary(comp: pd.DataFrame, output: Path) -> pd.DataFrame:
    """Human-readable plot-table: errors are explicitly typed, never conflated."""
    data = []
    for _, x in comp.loc[~comp.segment.str.endswith("Combined")].iterrows():
        if np.isfinite(x.DCS_scientists_NO2_overlap_proxy_mean_ppb):
            dcs = f'~{x.DCS_scientists_NO2_overlap_proxy_mean_ppb:.2f}'
            if np.isfinite(x.DCS_scientists_SD_ppb_source_window_only):
                dcs += f' (source SD {x.DCS_scientists_SD_ppb_source_window_only:.2f})'
            else:
                dcs += ' (source SD n.a.)'
            dcs += " [" + f'{x.DCS_scientists_coverage_fraction:.0%}' + "]"
        else:
            dcs = "n.a."
        data.append({
            "Segment": x.segment,
            "Start (CEST)": x.start_local_CEST[11:19],
            "End (CEST)": x.end_exclusive_local_CEST[11:19],
            "Drone NO2 (mean +/- RMSE, model units)": fmt_value_and_error(
                x.drone_NO2_NN_Tanh_mean_original_units, x.drone_NO2_model_test_RMSE_original_units,
                decimals=3),
            "LP-DOAS NO2 (mean only, ppb)": (
                f"{x.LPDOAS_NO2_mean_ppb:.3f}" if np.isfinite(x.LPDOAS_NO2_mean_ppb)
                else "n.a."),
            "DCS scientists NO2 (ppb, block proxy)": dcs,
            "Voigt raw parameter 0 (mean +/- SD, unverified)": fmt_value_and_error(
                x.DCS_Voigt_fit_parameter_0_mean_unverified,
                x.DCS_Voigt_fit_parameter_0_SD_unverified, scientific=True),
            "DCS block source windows": x.DCS_scientists_source_windows_CEST,
            "DCS source coverage": x.DCS_scientists_coverage_fraction,
        })
    tab = pd.DataFrame(data)
    export_csv(tab, output / "NO2_comparison_readable_with_errors.csv")
    # A compact figure stays legible in a thesis/report.
    cols = ["Segment", "Time (CEST)", "Drone mean +/- test RMSE", "LP-DOAS mean only",
            "DCS scientists (overlap proxy)", "Voigt raw +/- SD"]
    cells = []
    for _, r in tab.iterrows():
        cells.append([r["Segment"], r["Start (CEST)"] + " - " + r["End (CEST)"],
                      r["Drone NO2 (mean +/- RMSE, model units)"],
                      r["LP-DOAS NO2 (mean only, ppb)"],
                      r["DCS scientists NO2 (ppb, block proxy)"],
                      r["Voigt raw parameter 0 (mean +/- SD, unverified)"]])
    fig, ax = plt.subplots(figsize=(21, 4.6))
    ax.axis("off")
    table = ax.table(cellText=cells, colLabels=cols, cellLoc="left", colLoc="left",
                     loc="center", colWidths=[.14, .17, .15, .13, .20, .21])
    table.auto_set_font_size(False)
    table.set_fontsize(9.5)
    table.scale(1, 2.3)
    for (row, col), cell in table.get_celld().items():
        cell.set_edgecolor("#d6d9dd")
        if row == 0:
            cell.set_facecolor("#e8eff8")
            cell.set_text_props(weight="bold")
        elif row % 2 == 0:
            cell.set_facecolor("#f6f8fa")
    fig.suptitle("NO2 comparison by drone leg | 21 October 2026 | Munich (CEST)", fontsize=14, y=.99)
    fig.text(.02, .065, "Drone: held-out gas_drone NN test RMSE, if metrics exist. LP-DOAS: mean only (no error). DCS: source-block SD.", fontsize=10)
    fig.text(.02, .023, "~DCS: overlap-weighted block-mean proxy, NOT exact leg statistics; source SD is the ORIGINAL block SD. [%] = coverage.", fontsize=9)
    fig.savefig(output / "NO2_comparison_readable_with_errors.png", dpi=160, bbox_inches="tight")
    plt.close(fig)
    return tab


def export_csv(df: pd.DataFrame, path: Path):
    df.to_csv(path,sep=";",decimal=",",index=False,encoding="utf-8-sig",float_format="%.10g")


def main():
    if not DATA_DIR.is_dir():
        raise FileNotFoundError(f"Change DATA_DIR to your folder. Not found: {DATA_DIR}")
    OUTPUT_DIR.mkdir(exist_ok=True,parents=True)
    drone, raw_file = read_drone(DATA_DIR)
    drone=attach_calibrated_models(drone,DATA_DIR)
    drone=annotate_segments(drone)
    doas, doas_file=read_doas(DATA_DIR)
    dcs, dcs_file=read_dcs(DATA_DIR)
    print("[INPUT] Drone:",raw_file.name)
    print("[INPUT] LP-DOAS:",doas_file.name)
    print("[INPUT] Voigt/DCS:",dcs_file.name)
    print("[INPUT] Selected NN predictions:",PREDICTIONS_NAME)
    print("[TIME] Drone UTC converted to Munich CEST (Europe/Berlin, UTC+2 on this date)")
    print(f"[TIME ASSUMPTION] DOAS naive timezone: {LPDOAS_NAIVE_TZ}; DCS: {DCS_NAIVE_TZ}")
    rmse, rmse_source = load_drone_no2_rmse()
    print(f"[CALIBRATION RMSE] {rmse if rmse is not None else 'n.a.'} | {rmse_source}")
    gas,comp,fit=describe_flights(drone,doas,dcs,rmse,rmse_source)
    flight_only=drone.loc[drone.flight.ne("Outside flight")].copy()
    export_csv(flight_only,OUTPUT_DIR/"drone_flights_1s_calibrated.csv")
    export_csv(gas,OUTPUT_DIR/"drone_gas_statistics_by_flight_and_leg.csv")
    export_csv(comp,OUTPUT_DIR/"NO2_drone_vs_LPDOAS_vs_DCS_means.csv")
    export_csv(comp,OUTPUT_DIR/"NO2_comparison_with_errors_by_segment.csv")
    dcs_summary = dcs_scientists_summary_table()
    export_csv(dcs_summary, OUTPUT_DIR/"DCS_researchers_NO2_interval_summary.csv")
    export_csv(dcs_scientists_overlap_details(),
               OUTPUT_DIR/"DCS_scientists_segment_window_overlap.csv")
    printable = show_segment_summary(comp, OUTPUT_DIR)
    print("\n[NO2] Flight segments: mean and DIFFERENT uncertainty metrics:")
    print(printable[["Segment", "Drone NO2 (mean +/- RMSE, model units)",
                    "LP-DOAS NO2 (mean only, ppb)",
                    "DCS scientists NO2 (ppb, block proxy)"]].to_string(index=False))
    print("\n[DCS] Scientists' source intervals and recomputed combined SD:")
    print(dcs_summary[["time_window_CEST", "n_reported", "DCS_scientists_NO2_mean_ppb",
                       "DCS_scientists_NO2_SD_ppb", "SD_method"]].to_string(index=False))
    export_csv(fit,OUTPUT_DIR/"DCS_Voigt_all_fit_parameter_statistics.csv")
    full_start=local_window(WINDOWS[0][2]);full_end=local_window(WINDOWS[-1][3])
    export_csv(window_slice(doas,full_start,full_end),OUTPUT_DIR/"LPDOAS_flight_observations.csv")
    export_csv(window_slice(dcs,full_start,full_end),OUTPUT_DIR/"DCS_Voigt_flight_observations.csv")
    plot_time_series(drone,doas,dcs,OUTPUT_DIR)
    plot_no2_comparison_single_panel(drone,doas,OUTPUT_DIR,rmse)
    plot_spatial_3d(drone,OUTPUT_DIR)
    try:
        create_offline_4d_html(drone,OUTPUT_DIR)
    except ImportError as exc:
        print("[WARNING] Interactive HTML requires plotly: python -m pip install plotly")
        print(f"[WARNING] Detail: {exc}")
    settings={"campaign_date":DAY,"local_timezone":LOCAL_TZ,"DOAS_naive_time_assumption":LPDOAS_NAIVE_TZ,
              "DCS_naive_time_assumption":DCS_NAIVE_TZ,"drone_no2_unit":DRONE_NO2_UNIT,
              "DCS_param0_confirmed_molec_cm3":DCS_PARAM0_CONFIRMED_MOLEC_CM3,
              "flight_windows_half_open":WINDOWS,
              "drone_NO2_model_test_RMSE_original_units":rmse,
              "drone_RMSE_source":rmse_source,
              "drone_RMSE_warning":"Test RMSE is global calibration-model performance, not a per-flight uncertainty; confirm same model and target units before direct use.",
              "DCS_researchers_summary_with_recomputed_SD":DCS_SCIENTISTS_REPORTED,
              "DCS_researchers_overlap_warning":"An approximate block-mean proxy is NOT a direct segment-specific measurement. Source SD is not segment-specific.",
              "DCS_researchers_combined_SD_pooled_ppb":DCS_COMBINED_SD_PPB,
              "DCS_researchers_original_SD_ppb_not_used":DCS_ORIGINAL_COMBINED_SD_PPB,
              "DCS_researchers_combined_SD_method":"Pooled sample variance from n, mean, sample SD in two source blocks; approx 1.23 ppb.",
              "LPDOAS_uncertainty":"Not calculated, shown, or exported, as requested.",
              "model_columns":MODEL_COLUMNS,
              "provenance":{"raw_drone":str(raw_file),"DOAS":str(doas_file),
                            "Voigt_DCS":str(dcs_file),"calibrated_predictions":str(DATA_DIR/PREDICTIONS_NAME)},
              "scientific_warning":"Moving drone point samples and path-averaged optical measurements are not equivalent; check calibration units, optical path, measurement clock conventions, and DCS fit semantics."}
    (OUTPUT_DIR/"analysis_metadata.json").write_text(json.dumps(settings,ensure_ascii=False,indent=2),encoding="utf-8")
    sel=comp.loc[comp.segment.str.endswith("Combined"),
                 ["segment","drone_NO2_NN_Tanh_mean_original_units", "LPDOAS_NO2_mean_ppb",
                  "DCS_Voigt_fit_parameter_0_mean_unverified", "drone_NO2_valid_seconds",
                  "LPDOAS_valid_measurements","DCS_Voigt_valid_measurements"]]
    print("\n[NO2] Whole-flight comparison (mean; DCS units and drone units UNCONFIRMED):")
    print(sel.to_string(index=False,float_format=lambda x:f"{x:.5g}"))
    print("\n[OTHER GASES] Whole-flight calibrated means:")
    print(gas.loc[gas.segment.str.endswith("Combined"),["segment","model","mean","n"]].to_string(index=False,float_format=lambda x:f"{x:.5g}"))
    print("\n[CAUTION] The second flight return is incomplete (crash). Do not claim both flights have matching route coverage.")
    print("[CAUTION] Raw Voigt/DCS parameter 0 is NOT confirmed as NO2 concentration or density. No default ppb conversion.")
    print("[CAUTION] DCS scientists' processed NO2 reports (ppb) are distinct from raw Voigt fit parameter 0.")
    print("[CAUTION] Scientist reports are coarse time blocks; individual flight legs do not match those boundaries exactly.")
    print(f"[METHOD] Recalculated Flight 1 DCS combined sample SD: {DCS_COMBINED_SD_PPB:.4f} ppb (rounds to 1.23 ppb).")
    print("[METHOD] LP-DOAS: average only, with NO SD or error values anywhere in the comparison outputs.")
    if rmse is None:
        print("[MISSING] Run the calibration script and place all_model_metrics.csv in results_calibration to populate drone test RMSE.")
    print("[DONE] Tables and figures:",OUTPUT_DIR)


if __name__ == "__main__":
    main()
