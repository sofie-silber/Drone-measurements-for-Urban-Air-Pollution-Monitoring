#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Train the FOUR explicitly selected Mandria gas NNs and apply them to raw drone data.

This file is designed for Spyder (Run/F5). It does NOT consume a precomputed
selected_calibrated_log009_1s.csv: it CREATES that CSV from actual raw data.

Selected models (gas_drone, 30-second calibration / 1-second exploratory transfer):
  CO  -> NN_relu_without_pressure
  NO2 -> NN_tanh_without_pressure
  O3  -> NN_gelu_without_pressure AND NN_tanh_without_pressure

Training: original Mandria gas_drone and thermo_reference measurements, chronological
whole-day train/validation/test split, same 100-epoch + seed-42 algorithm as
calibration_paris_english.py. No flight measurements are used for fitting.

Optional: automatically run the existing TWO-FLIGHT NO2 vs LP-DOAS/DCS analysis after
exporting the calibrated predictions, without a manually prepared prediction file.

CAUTION: The 1-second transfer is exploratory and may be out of calibration domain.
Predictions are NOT truncated to zero; unknown reference concentration units are
NOT silently converted to ppb.
"""
from __future__ import annotations

import json
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

try:
    import calibration_paris_english as cal
except ImportError as exc:
    raise ImportError(
        "Put calibration_paris_english.py in the same folder as this script."
    ) from exc

# ============================================================================
# EDITABLE SETTINGS
# ============================================================================
DATA_ROOT = Path(r"C:\Users\xy-84\Desktop\Master\Thesis\Background_Data_Paris")
DRONE_ROOT = DATA_ROOT / "Graz Campaign"
DRONE_FILE = DRONE_ROOT / "raw_data_drone.csv"   # case-insensitive lookup on Windows
RESULTS_ROOT = DRONE_ROOT / "results_selected_NNs"

# You may explicitly set the original MANDRIA archive here, e.g.:
# MANDRIA_ZIP = DATA_ROOT / "original_mandria_data.zip"
# Leave None when the original Mandria CSV files are already extracted.
MANDRIA_ZIP = None

EPOCHS = 100
SEED = 42
CAMPAIGN_DATE = "2026-10-21"
LOCAL_TIMEZONE = "Europe/Berlin"  # Munich is CEST (UTC+02:00) on 21 October 2026
RUN_TWO_FLIGHT_COMPARISON = True

MODEL_SELECTION = [
    ("CO", "NN_relu_without_pressure", "CO__NN_relu_without_pressure"),
    ("NO2", "NN_tanh_without_pressure", "NO2__NN_tanh_without_pressure"),
    ("O3", "NN_gelu_without_pressure", "O3__NN_gelu_without_pressure"),
    ("O3", "NN_tanh_without_pressure", "O3__NN_tanh_without_pressure"),
]
MODEL_FEATURES = ["CO_raw", "NO2_raw", "O3_raw", "T", "RH"]
SENSOR_INPUT_MAP = {
    "mics_reducing_ohm": "CO_raw",
    "mics_oxidising_ohm": "NO2_raw",
    "mq131_raw": "O3_raw",
    "temp_c": "T",
    "humidity_percent": "RH",
    "pressure_hpa": "p",              # preserve in outputs, NEVER feed into the NNs
    "gps_fix": "gps_fix",
    "gps_lat": "gps_lat",
    "gps_lon": "gps_lon",
    "gps_alt_m": "gps_alt_m",
    "gps_speed_kmh": "gps_speed_kmh",
    "gps_hdop": "gps_hdop",
    "gps_satellites": "gps_satellites",
}


def locate_drone_file() -> Path:
    if DRONE_FILE.is_file():
        return DRONE_FILE
    matches = [p for p in DRONE_ROOT.iterdir() if p.is_file() and p.name.lower()
               in ("raw_data_drone.csv", "log009.csv")]
    preferred = [p for p in matches if p.stem.lower() == "raw_data_drone"]
    if preferred:
        return sorted(preferred)[0]
    if matches:
        return sorted(matches)[0]
    raise FileNotFoundError(
        f"Could not locate raw_data_drone.csv or LOG009.CSV in {DRONE_ROOT}. "
        "The model must be applied to actual raw drone data."
    )


def find_gas_calibration_sources():
    """Get the original Mandria gas_drone + thermo_reference files (CSV only).

    The calibration script's normal finder also requires PM input files. This
    gas-only task does not require a PM reference, so use a targeted discovery.
    Prefer extracted CSVs over archives; exclude the Graz mission directory.
    """
    types = ("gas_drone", "thermo_reference")
    found = {}
    if not DATA_ROOT.is_dir():
        raise FileNotFoundError(f"Missing calibration directory: {DATA_ROOT}")
    if MANDRIA_ZIP is not None:
        archives = [Path(MANDRIA_ZIP)]
    else:
        for f in sorted(DATA_ROOT.rglob("*.csv")):
            if DRONE_ROOT in f.parents or any(part.lower().startswith("results_") for part in f.parts):
                continue
            kind = cal.classify(f.name)
            if kind in types and kind not in found:
                found[kind] = cal.Source(str(f))
        archives = sorted(DATA_ROOT.rglob("*.zip"))
    for archive in archives:
        if not archive.is_file():
            raise FileNotFoundError(f"Calibration ZIP not found: {archive}")
        with zipfile.ZipFile(archive) as z:
            for member in z.namelist():
                kind = cal.classify(member)
                if kind in types and (MANDRIA_ZIP is not None or kind not in found):
                    found[kind] = cal.Source(member, archive)
    missing = [item for item in types if item not in found]
    if missing:
        raise FileNotFoundError(
            "Missing original Mandria calibration CSV sources: " + ", ".join(missing) + "\n"
            "Expected a gas_drone CSV and thermo_reference CSV under " + str(DATA_ROOT) + ".\n"
            "Do NOT use LP-DOAS or the Munich drone as training reference."
        )
    print("[CALIBRATION SOURCES]")
    for kind in types:
        print(f"  {kind}: {found[kind].label()}")
    return found


def train_selected_models():
    sources = find_gas_calibration_sources()
    calibration_gas = cal.read_sensor_binned(sources["gas_drone"])
    reference_gas = cal.read_reference_gases(sources["thermo_reference"])
    models = {}
    metric_rows = []
    details = {
        "calibration_gas_file": sources["gas_drone"].label(),
        "calibration_reference_file": sources["thermo_reference"].label(),
        "training_epochs_max": EPOCHS,
        "random_seed": SEED,
        "calibration_time_bin_seconds": cal.SAMPLE_SECONDS,
        "calibration_days": "Chronological whole calendar days, 60/20/20 approximately",
        "flight_time_bin_seconds": 1,
        "input_features": MODEL_FEATURES,
        "pressure_is_an_input": False,
        "models": [],
    }
    datasets = {}
    for pollutant, method, output_name in MODEL_SELECTION:
        if pollutant not in datasets:
            joined, coverage = cal.usable_gas_days(
                calibration_gas, reference_gas, pollutant, "gas_drone"
            )
            if joined.empty:
                raise ValueError(f"No complete calibration days for {pollutant}")
            datasets[pollutant] = cal.chronological_day_split(joined)
        splits = datasets[pollutant]
        features = next(
            (f for candidate, f in cal.model_specs(pollutant, "gas") if candidate == method),
            None,
        )
        if features != MODEL_FEATURES:
            raise ValueError(f"Unexpected features for {method}: {features}")
        tr, va, te = (splits[k] for k in ("train", "validation", "test"))
        model, notes = cal.build_neural(
            tr[features].to_numpy(float), tr.target.to_numpy(float),
            va[features].to_numpy(float), va.target.to_numpy(float),
            activation=method.split("_")[1], epochs=EPOCHS, seed=SEED,
        )
        models[output_name] = model
        metrics = {}
        for phase, block in splits.items():
            stats = cal.statistics(
                block.target.to_numpy(float),
                model.predict(block[features].to_numpy(float)),
            )
            metrics[phase] = stats
            metric_rows.append({"pollutant": pollutant, "model": method,
                                "phase": phase, "features": "|".join(features), **stats})
        details["models"].append({
            "pollutant": pollutant, "method": method, "output_column": output_name,
            "features": features, "fit_notes": notes,
            "train_days": sorted(map(str, tr.day.unique())),
            "validation_days": sorted(map(str, va.day.unique())),
            "test_days": sorted(map(str, te.day.unique())),
            "calibration_train_01_quantile": tr[features].quantile(0.01).to_dict(),
            "calibration_train_99_quantile": tr[features].quantile(0.99).to_dict(),
            "model_metrics": metrics,
        })
        print(f"[TRAINED] {pollutant}: {method} | "
              f"validation R2={metrics['validation']['R2']:.3f}, "
              f"test R2={metrics['test']['R2']:.3f}, "
              f"test RMSE={metrics['test']['RMSE']:.3f}")
    return models, pd.DataFrame(metric_rows), details


def load_drone_1s():
    path = locate_drone_file()
    raw = pd.read_csv(path, encoding="utf-8-sig", low_memory=False)
    raw.columns = raw.columns.str.strip().str.lower()
    # Model feature keys do not occur verbatim in raw log: check source names.
    needed_raw = {"gps_date", "gps_time_utc", "mics_reducing_ohm",
                  "mics_oxidising_ohm", "mq131_raw", "temp_c", "humidity_percent"}
    missing = needed_raw - set(raw.columns)
    if missing:
        raise ValueError(f"Raw drone file is missing sensor columns: {sorted(missing)}")
    ts = pd.to_datetime(
        raw["gps_date"].astype("string").str.strip() + " " +
        raw["gps_time_utc"].astype("string").str.strip(),
        errors="coerce", utc=True, format="mixed",
    )
    good = ts.dt.strftime("%Y-%m-%d").eq(CAMPAIGN_DATE).fillna(False)
    data = pd.DataFrame(index=pd.DatetimeIndex(ts[good], name="time_utc"))
    trimmed = raw.loc[good]
    for old, new in SENSOR_INPUT_MAP.items():
        if old in trimmed.columns:
            data[new] = pd.to_numeric(trimmed[old].to_numpy(), errors="coerce")
    if data.empty:
        raise ValueError(f"No GPS timestamps dated {CAMPAIGN_DATE} in {path}")
    # Same QC as the original calibration/flight-transfer scripts.
    data["T"] = data["T"].where(data["T"].between(-40, 65))
    data["RH"] = data["RH"].where(data["RH"].between(0, 100))
    if "p" in data:
        data["p"] = data["p"].where(data["p"].between(870, 1085))
    data["O3_raw"] = data["O3_raw"].where(data["O3_raw"].between(1, 4094))
    for key in ("CO_raw", "NO2_raw"):
        data[key] = data[key].where(data[key] >= 0)
    numeric_cols = data.select_dtypes(include="number").columns
    # Mean within each UTC second; no interpolation of absent samples.
    one_s = data[numeric_cols].sort_index().resample("1s").mean()
    if "gps_fix" in one_s:
        fixed = data["gps_fix"].sort_index().resample("1s").max()
        one_s["gps_fix"] = fixed
        for col in ("gps_lat", "gps_lon", "gps_alt_m", "gps_hdop"):
            if col in one_s:
                one_s[col] = one_s[col].where(one_s.gps_fix == 1)
    one_s["time_local"] = one_s.index.tz_convert(LOCAL_TIMEZONE)
    duplicates = int(good.sum() - data.index.nunique())
    print(f"[DRONE INPUT] {path.name}: {good.sum()} dated observations, "
          f"{duplicates} duplicate second/sample timestamps, "
          f"{one_s[MODEL_FEATURES].notna().all(axis=1).sum()} valid model-input seconds")
    return one_s, path


def make_predictions(drone, models, metadata):
    out = drone.copy()
    full = out[MODEL_FEATURES].replace([np.inf, -np.inf], np.nan)
    valid = full.notna().all(axis=1)
    count = int(valid.sum())
    if count == 0:
        raise ValueError("No drone seconds have all five required inputs.")
    x = full.loc[valid, MODEL_FEATURES].to_numpy(float)
    per_model = []
    for _, method, output_name in MODEL_SELECTION:
        predicted = np.full(len(out), np.nan)
        predicted[np.flatnonzero(valid.to_numpy())] = models[output_name].predict(x)
        out[output_name] = predicted
        nneg = int(np.sum(predicted < 0))
        reference = next(v for v in metadata["models"] if v["output_column"] == output_name)
        lower, upper = (reference["calibration_train_01_quantile"],
                        reference["calibration_train_99_quantile"])
        ood = np.zeros(len(out), dtype=bool)
        for f in MODEL_FEATURES:
            a = full[f].to_numpy(float)
            ood |= (a < lower[f]) | (a > upper[f])
        per_model.append({"model": method, "output_column": output_name,
                          "predicted_seconds": int(np.isfinite(predicted).sum()),
                          "negative_predictions": nneg,
                          "percent_seconds_outside_train_p01_p99":
                          round(float(100 * (ood & valid.to_numpy()).sum() / count), 3),
                          "mean": round(float(np.nanmean(predicted)), 6),
                          "minimum": round(float(np.nanmin(predicted)), 6),
                          "maximum": round(float(np.nanmax(predicted)), 6)})
        print(f"[FLIGHT PREDICTION] {method}: {count} seconds, "
              f"negative={nneg}, mean={np.nanmean(predicted):.4f}")
    metadata["flight_predictions"] = per_model
    return out


def save_results(out, metrics, metadata, source_path):
    RESULTS_ROOT.mkdir(parents=True, exist_ok=True)
    out = out.copy()
    out.index.name = "time_utc"
    # This file is intentionally identical in structure to the previously
    # supplied predictions, allowing the old DOAS/DCS script to read it.
    calibrated = out[[x[2] for x in MODEL_SELECTION]].reset_index()
    legacy_path = DRONE_ROOT / "selected_calibrated_log009_1s.csv"
    calibrated.to_csv(legacy_path, sep=";", decimal=",", index=False,
                      encoding="utf-8-sig", float_format="%.10g")
    full_path = RESULTS_ROOT / "raw_data_drone_calibrated_1s.csv"
    out.reset_index().to_csv(full_path, sep=";", decimal=",", index=False,
                             encoding="utf-8-sig", float_format="%.10g")
    metrics.to_csv(RESULTS_ROOT / "selected_nn_calibration_metrics.csv",
                   sep=";", decimal=",", index=False, encoding="utf-8-sig")
    metadata["flight_raw_file"] = str(source_path)
    metadata["prediction_file"] = str(legacy_path)
    metadata["note"] = (
        "Models refitted from original Mandria calibration data. "
        "1-second application to field sensor rows is exploratory; no interpolation, "
        "no negative-value clipping, and no assumption about concentration units."
    )
    (RESULTS_ROOT / "selected_nn_provenance.json").write_text(
        json.dumps(metadata, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    print(f"[SAVED] {legacy_path}")
    print(f"[SAVED] {full_path}")
    print(f"[SAVED] {RESULTS_ROOT / 'selected_nn_calibration_metrics.csv'}")


def maybe_run_comparison():
    if not RUN_TWO_FLIGHT_COMPARISON:
        return
    try:
        import munich_two_flights_no2_doas_dcs as compare
    except ImportError:
        print("[NOTE] Two-flight comparison script not beside this script; "
              "selected NN prediction files were still created successfully.")
        return
    required = [p for p in DRONE_ROOT.iterdir()
                if p.is_file() and ("LPDOAS Church".lower() in p.name.lower() or
                                    (p.name.lower().startswith("no2_voigt") and p.suffix.lower() == ".npz"))]
    if len(required) < 2:
        print("[NOTE] LP-DOAS and Voigt/DCS reference files are not both present; "
              "skipping optical comparison.")
        return
    compare.DATA_DIR = DRONE_ROOT
    compare.OUTPUT_DIR = DRONE_ROOT / "results_two_flights_DOAS_DCS"
    compare.PREDICTIONS_NAME = "selected_calibrated_log009_1s.csv"
    print("\n[COMPARISON] Running flight 1 + flight 2 vs LP-DOAS and Voigt/DCS")
    compare.main()


def main():
    print("[START] Training four selected gas models on Mandria reference data")
    print(f"[SETTINGS] EPOCHS={EPOCHS}; SEED={SEED}; no pressure in any network")
    models, metrics, metadata = train_selected_models()
    print("[PROCESSING] Loading original drone measurements; grouping at 1 second")
    drone, file = load_drone_1s()
    predictions = make_predictions(drone, models, metadata)
    save_results(predictions, metrics, metadata, file)
    maybe_run_comparison()
    print("[DONE] Selected NNs applied directly to raw_data_drone.csv")


if __name__ == "__main__":
    main()
